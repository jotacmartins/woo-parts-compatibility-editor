<?php
/**
 * Installation Based Hooks
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Install {

	/**
	 * Constructor
	 */
	public function __construct () {
		
	}
	
	/**
	 * Quick Links to Plugin's List Page
	 */
	public static function quick_links ( $links ) {
		array_unshift ( $links, '<a href="edit.php?post_type=wpce&page=wpce-settings">' . __( 'Settings', 'wpce' ) . '</a>' ); 
		array_unshift ( $links, '<a href="edit.php?post_type=wpce">' . __( 'Manage Finders', 'wpce' ) . '</a>' ); 
		return $links;
	}

	/**
	 * On WPCE Install
	 */
	public static function install () {
		self::create_tables ();
		
		// Create Custom Post-Types / Taxonomies
		WPCE_Post_Types::register_post_types();
		flush_rewrite_rules();
	
		// Create Options
		self::create_options ();
	}
	
	/**
	 * Setup / Create Database Tables
	 */
	public static function create_tables () {
		global $wpdb;
		require_once ( ABSPATH . 'wp-admin/includes/upgrade.php' );
		
		$collate = '';
		if ( $wpdb->has_cap ( 'collation' ) ) {
			$collate = $wpdb->get_charset_collate ();
		}
		
		dbDelta(
			"CREATE TABLE {$wpdb->prefix}wpce_terms (
				term_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				parent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				finder_id BIGINT UNSIGNED NOT NULL,
				title varchar(255) NOT NULL,
				count BIGINT UNSIGNED NOT NULL DEFAULT 0,
				PRIMARY KEY (term_id)
			) $collate;"
		);
		
		dbDelta(
			"CREATE TABLE {$wpdb->prefix}wpce_term_relationships (
				term_id BIGINT UNSIGNED NOT NULL,
				product_id BIGINT UNSIGNED NOT NULL
			) $collate;"
		);
	}
	
	/**
	 * Delete Database Tables
	 */
	public static function drop_tables () {
		global $wpdb;
		
		$wpdb->query ( "DROP TABLE IF EXISTS {$wpdb->prefix}wpce_terms" );
		$wpdb->query ( "DROP TABLE IF EXISTS {$wpdb->prefix}wpce_term_relationships" );
	}
	
	/**
	 * Setup / Create Default Options
	 */
	public static function create_options () {
		include_once dirname ( __FILE__ ) . '/admin/class-wpce-admin-settings.php';
		
		$option_sections = WPCE_Admin_Settings::get_settings ();
		if ( ! empty ( $option_sections ) ) {
			foreach ( $option_sections as $option_section ) {
				if ( isset ( $option_section['options'] ) && ! empty ( $option_section['options'] ) ) {
					foreach ( $option_section['options'] as $option ) {
						if ( isset ( $option['default'] ) && isset ( $option['name'] ) ) {
							$autoload = isset ( $option['autoload'] ) ? ( bool ) $option['autoload'] : true;
							add_option ( $option['name'], $option['default'], '', ( $autoload ? 'yes' : 'no' ) );
						}
					}
				}
			}
		}
	}
	
	/**
	 * Drop Options
	 */
	public static function drop_options () {
		include_once dirname ( __FILE__ ) . '/admin/class-wpce-admin-settings.php';
		
		$option_sections = WPCE_Admin_Settings::get_settings ();
		if ( ! empty ( $option_sections ) ) {
			foreach ( $option_sections as $option_section ) {
				if ( isset ( $option_section['options'] ) && ! empty ( $option_section['options'] ) ) {
					foreach ( $option_section['options'] as $option ) {
						delete_option ( $option['name'] );
					}
				}
			}
		}
	}
}

$GLOBALS['wpce_install'] = new WPCE_Install ();