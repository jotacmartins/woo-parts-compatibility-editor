<?php
/**
 * WooCommerce Search Hooks/Filters
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Search {
	
	/**
	 * @var array $search_term 
	 */
	public static $search_term = array ();
	
	/**
	 * @var boolean $is_search_results_page
	 */
	public static $is_search_results_page = false;
	
	/**
	 * @var array $categories_counts 
	 */
	public static $categories_counts = array ();

	/**
	 * Constructor
	 */
	public function __construct () {
		add_action ( 'pre_get_posts', array ( __CLASS__, 'set_search_term' ), 1 );
		
		add_action ( 'wp', array ( __CLASS__, 'search_template_display_mode' ) );
		add_action ( 'pre_get_posts', array ( __CLASS__, 'search_query' ), apply_filters ( 'wpce_pre_get_posts_priority', 99 ) );
		add_action ( 'template_redirect', array ( __CLASS__, 'redirect_single_search_result' ) );
		add_filter ( 'woocommerce_page_title', array ( __CLASS__, 'search_results_page_title' ) );
		
		//add_filter ( 'woocommerce_is_filtered', array ( __CLASS__, 'search_template_display_mode' ) );
		//add_filter ( 'posts_join', array ( __CLASS__, 'search_query_join' ), 10, 2 );
		//add_filter ( 'posts_where', array ( __CLASS__, 'search_query_where' ) );
		//add_filter ( 'posts_groupby', array ( __CLASS__, 'search_query_groupby' ) );
	}
	
	/**
	 * Set Search in WordPress Query
	 */
	public static function set_search_term ( $query ) {
		if ( is_admin () ) {
			return;
		}
		
		if ( ! $query->is_main_query () ) {
			return;
		}
		
		$search_term			= is_wpce_search ();
		
		if ( $search_term && ! empty ( $search_term ) ) {
			self::$search_term	= $search_term;
			self::$is_search_results_page	= true;
			
			// Remember Search
			$remember_search	= get_post_meta ( self::$search_term->finder_id, 'wpce_remember_search', true );
			if ( $remember_search == 'yes' ) {
				wpce_set_cookie ( self::$search_term->finder_id, 'search_term_id', self::$search_term->term_id );
			}
			
			// Save User Search History
			$save_user_searches	= get_post_meta ( self::$search_term->finder_id, 'wpce_save_user_searches', true );
			if ( $save_user_searches == 'yes' ) {
				wpce_save_user_search_history ( self::$search_term->finder_id, self::$search_term->term_id );
			}
		} else {
			$finders			= wpce_get_finders ();
	
			if ( ! empty ( $finders ) ) {
				foreach ( $finders as $finder ) {
					$remember_search				= get_post_meta ( $finder->ID, 'wpce_remember_search', true );
					
					if ( $remember_search == 'yes' ) {
						$search_term_id				= wpce_get_cookie ( $finder->ID, 'search_term_id' );
						
						if ( ! empty ( $search_term_id ) ) {
							$is_search_on			= false;
							$remember_search_on		= get_post_meta ( $finder->ID, 'wpce_remember_search_on', true );
							
							if ( $remember_search_on == 'categories' ) {
								if ( is_product_category () ) {
									$category				= get_queried_object ();
									if ( isset ( $category->term_id ) && $category->term_id > 0 ) {
										$categories_to_include	= get_post_meta ( $finder->ID, 'wpce_categories_to_include', true );
										$categories_to_exclude	= get_post_meta ( $finder->ID, 'wpce_categories_to_exclude', true );
										
										if ( ! empty ( $categories_to_exclude ) && in_array ( $category->term_id, $categories_to_exclude ) ) {
											//$is_search_on		= false;
										} else if ( ! empty ( $categories_to_include ) ) {
											if ( in_array ( $category->term_id, $categories_to_include ) ) {
												$is_search_on	= true;
											}
										} else {
											$is_search_on		= true;
										}
									}
								}
							} else {
								$is_search_on		= true;
							}
							
							if ( $is_search_on ) {
								$search_term		= wpce_get_term ( $search_term_id );
								self::$search_term	= $search_term;
							}
						}
					}
				}
			}
		}
	}
	
	/**
	 * Show Products or Categories based on Search Page Display Mode
	 */
	public static function search_template_display_mode () {
		if ( ! empty ( self::$search_term ) ) {
			$display_mode	= get_post_meta ( self::$search_term->finder_id, 'wpce_search_results_display_mode', true );
			
			if ( $display_mode == 'shop' ) {
				$shop_page_display_mode	= get_option ( 'woocommerce_shop_page_display', '' );
				
				if ( $shop_page_display_mode == 'subcategories' || $shop_page_display_mode == 'both' ) {
					add_action ( 'wp_head', array ( __CLASS__, 'delete_product_categories_cache' ) );
					add_action ( 'wp_footer', array ( __CLASS__, 'delete_product_categories_cache' ) );
					add_filter ( 'woocommerce_product_subcategories_args', array ( __CLASS__, 'exclude_empty_categories' ), 99 );
					add_filter ( 'woocommerce_subcategory_count_html', array ( __CLASS__, 'category_count_html' ), 99, 2 );
					add_action ( 'woocommerce_before_subcategory', array ( __CLASS__, 'add_search_term_to_categories_link' ), 1 );
					add_action ( 'woocommerce_after_subcategory', array ( __CLASS__, 'remove_search_term_from_categories_link' ), 99 );
				}
			} else { // 'products'
				add_filter ( 'woocommerce_is_filtered', array ( __CLASS__, 'search_template_display_mode_products' ) );
			}
		}
	}
	
	/**
	 * Display Mode ( Categories ): Delete Categories Cache to Perform a Fresh Search
	 */
	public static function delete_product_categories_cache () {
		if ( is_product_category () ) {
			$parent_id = get_queried_object_id ();
		} else {
			$parent_id = 0;
		}
		
		wp_cache_delete ( 'product-category-hierarchy-' . $parent_id, 'product_cat' );
	}
	
	/**
	 * Display Mode ( Categories ): Exclude Empty Categories
	 */
	public static function exclude_empty_categories ( $args ) {
		if ( apply_filters ( 'woocommerce_product_subcategories_hide_empty', true ) ) {
			if ( ! empty ( self::$search_term ) ) {
				$product_categories = get_categories ( array_merge ( $args, array ( 'hide_empty' => true ) ) );
				
				if ( ! empty ( $product_categories ) ) {
					$exclude_ids = array ();
					
					$categories_to_include	= get_post_meta ( self::$search_term->finder_id, 'wpce_categories_to_include', true );
					$categories_to_exclude	= get_post_meta ( self::$search_term->finder_id, 'wpce_categories_to_exclude', true );
					
					$product_ids	= wpce_get_term_relationships_including_universal ( self::$search_term->term_id, self::$search_term->finder_id );
					foreach ( $product_categories as $product_category ) {
						
						$products = get_posts (
							array (
								'post_type'					=> 'product',
								'numberposts'				=> -1,
								'post__in'					=> $product_ids,
								'tax_query'					=> array (
									array (
										'taxonomy'			=> $product_category->taxonomy,
										'field'				=> 'term_id',
										'terms'				=> array ( $product_category->term_id ),
										'operator'			=> 'IN',
										'include_children'	=> true
									)
								)
							)
						);
					
						if ( ! empty ( $products ) ) {
							self::$categories_counts[ $product_category->term_id ] = count ( $products );
						}
						
						if ( ! empty ( $categories_to_exclude ) && in_array ( $product_category->term_id, $categories_to_exclude ) ) {
							$exclude_ids[] = $product_category->term_id;
						} else if ( ! empty ( $categories_to_include ) && ! in_array ( $product_category->term_id, $categories_to_include ) ) {
							$exclude_ids[] = $product_category->term_id;
						} else if ( empty ( $products ) ) {
							$exclude_ids[] = $product_category->term_id;
						}
					}
					
					if ( ! empty ( $exclude_ids ) ) {
						if ( isset ( $args['exclude'] ) && ! empty ( $args['exclude'] ) ) {
							$args['exclude'] 	= array_merge ( $args['exclude'], $exclude_ids );
						} else {
							$args['exclude'] 	= $exclude_ids;
						}
						
						if ( isset ( $args['include'] ) && ! empty ( $args['include'] ) ) {
							$include_ids		= $args['include'];
						   
							if ( ! is_array ( $include_ids ) ) {
								$include_ids	= explode ( ',', $args['include'] );
							}
						   
							foreach ( $exclude_ids as $exclude_id ) {
								if ( in_array ( $exclude_id, $include_ids ) ) {
									unset ( $include_ids[ array_search ( $exclude_id, $include_ids ) ] );
								}
							}
						   
							$args['include']	= $include_ids;
						}
					}
				}
			}
		}
		
		return $args;
	}
	
	/**
	 * Display Mode ( Categories ): Update Categories Count
	 */
	public static function category_count_html ( $html, $category ) {
		if ( ! empty ( self::$categories_counts ) && isset ( self::$categories_counts[ $category->term_id ] ) ) {
			$html = apply_filters ( 'wpce_category_count_html', ' <mark class="count">(' . esc_html ( self::$categories_counts[ $category->term_id ] ) . ')</mark>', $category );
		}
		
		return $html;
	}
	
	/**
	 * Display Mode ( Categories ): Add Searched Term to Categories Link
	 */
	public static function add_search_term_to_categories_link () {
		add_filter ( 'term_link', array ( __CLASS__, 'add_search_term_to_categories_link_callback' ), 10, 3 );
	}
	
	/**
	 * Display Mode ( Categories ): Add Searched Term to Categories Link Callback
	 */
	public static function add_search_term_to_categories_link_callback ( $termlink, $term, $taxonomy ) {
		if ( $taxonomy == 'product_cat' && self::$is_search_results_page ) {
			if ( isset ( $_GET['wpce_search'] ) ) {
				$termlink = add_query_arg ( 'wpce_search', $_GET['wpce_search'], $termlink );
			}
			
			/*if ( isset ( $_GET['post_type'] ) ) {
				$termlink = add_query_arg ( 'post_type', $_GET['post_type'], $termlink );
			}*/
		}
		
		return $termlink;
	}
	
	/**
	 * Display Mode ( Categories ): Add Searched Term to Categories Link
	 */
	public static function remove_search_term_from_categories_link () {
		//remove_action ( 'woocommerce_before_subcategory', array ( __CLASS__, 'add_search_term_to_categories_link' ), 1 );
		remove_filter ( 'term_link', array ( __CLASS__, 'add_search_term_to_categories_link_callback' ), 10, 3 );
	}
	
	/**
	 * Display Mode ( Products ): Set Search Template as PRODUCTS LIST using 'is_filtered' Check from 'woocommerce_get_loop_display_mode' Function
	 */
	public static function search_template_display_mode_products ( $is_filtered ) {
		return true;
	}
	
	/**
	 * Set Search in WordPress Query
	 */
	public static function search_query ( $query ) {
		if ( is_admin () ) {
			return;
		}
		
		if ( ! $query->is_main_query () ) {
			return;
		}
		
		if ( empty ( self::$search_term ) ) {
			return;
		}
		
		$is_product_archive			= false;
		
		if ( is_product_category () || is_product_tag () || is_post_type_archive ( 'product' ) ) {
			$is_product_archive		= true;
		} else if ( isset ( $query->query_vars['post_type'] ) ) {
			$post_types				= $query->query_vars['post_type'];
			
			if ( ! is_array ( $post_types ) ) {
				$post_types			= array ( $post_types );
			}
			
			if ( ! empty ( $post_types ) && in_array ( 'product', $post_types ) && ! is_singular () ) { // ! is_singlular = ! is_product () because is_product () didn't work here
				$is_product_archive	= true;
			}
		}
		
		if ( ! $is_product_archive ) {
			return;
		}
		
		// Posts Query
		$post__in		= array ();
		
		if ( isset ( $query->query_vars['post__in'] ) ) {
			$post__in	= $query->query_vars['post__in'];
		}
		
		$product_ids	= wpce_get_term_relationships_including_universal ( self::$search_term->term_id, self::$search_term->finder_id );
		if ( empty ( $post__in ) ) {
			$post__in	= $product_ids;
		} else {
			$post__in	= array_intersect ( $post__in, $product_ids );
		}
		
		if ( empty ( $post__in ) ) {
			$post__in	= array ( -1 );
		}
		
		$query->set ( 'post__in', $post__in );
		
		// Tax Query
		$tax_query		= $query->get ( 'tax_query' );
		
		if ( empty ( $tax_query ) ) {
			$tax_query	= array ();
		}
		
		if ( isset ( self::$search_term->category_id ) && self::$search_term->category_id > 0 ) {
			$tax_query[]			= array (
				'taxonomy'			=> 'product_cat',
				'field'				=> 'term_id',
				'terms'				=> array ( self::$search_term->category_id ),
				'include_children'	=> false,
				'operator'			=> 'IN'
			);
		} else {
			$categories_to_include	= get_post_meta ( self::$search_term->finder_id, 'wpce_categories_to_include', true );
			if ( ! empty ( $categories_to_include ) ) {
				$tax_query[]			= array (
					'taxonomy'			=> 'product_cat',
					'field'				=> 'term_id',
					'terms'				=> $categories_to_include,
					'include_children'	=> false,
					'operator'			=> 'IN'
				);
			}
			
			$categories_to_exclude	= get_post_meta ( self::$search_term->finder_id, 'wpce_categories_to_exclude', true );
			if ( ! empty ( $categories_to_exclude ) ) {
				$tax_query[]			= array (
					'taxonomy'			=> 'product_cat',
					'field'				=> 'term_id',
					'terms'				=> $categories_to_exclude,
					'include_children'	=> false,
					'operator'			=> 'NOT IN'
				);
			}
		}
		
		$query->set ( 'tax_query', $tax_query );
	}
	
	/**
	 * Redirect to Product Details Page if Single Search Result
	 */
	public static function redirect_single_search_result () {
		if ( self::$is_search_results_page && ! empty ( self::$search_term ) ) {
			$redirect_single_search	= get_post_meta ( self::$search_term->finder_id, 'wpce_redirect_single_search', true );
			
			if ( $redirect_single_search == 'yes' ) {
				global $wp_query;
				
				if ( 1 === absint ( $wp_query->found_posts ) ) {
					$product = wc_get_product ( $wp_query->post );
					
					if ( $product && $product->is_visible () ) {
						wp_safe_redirect ( get_permalink ( $product->get_id () ), 302 );
						exit;
					}
				}
			}
		}
	}
	
	/**
	 * Set Search Result Page Title
	 */
	public static function search_results_page_title ( $title ) {
		if ( self::$is_search_results_page && self::wpce_override_search_results_page_title () ) {
			$search_results_title					= get_post_meta ( self::$search_term->finder_id, 'wpce_search_results_title', true );
			
			if ( ! empty ( $search_results_title ) ) {
				$search_ancestors					= wpce_get_term_ancestors ( self::$search_term->term_id );
				
				if ( ! empty ( $search_ancestors ) ) {
					
					if ( strstr ( $search_results_title, '{SEPARATOR}' ) !== false ) {
						$search_results_title		= explode ( '{SEPARATOR}', $search_results_title );
					} else {
						$search_results_title		= array ( $search_results_title );
					}
					
					$levels							= wpce_get_levels ( self::$search_term->finder_id );
					$search_ancestors				= array_reverse ( $search_ancestors );
						
					foreach ( $search_results_title as $key => $level_title ) {
						
						// Category Title
						$term_label					= '';
						$term_title					= '';
						
						if ( strstr ( $level_title, '{CATEGORY_NAME}' ) !== false ) {
							if ( isset ( self::$search_term->category_id ) && self::$search_term->category_id > 0 ) {
								$term_title			= self::$search_term->category_name;
								
								if ( strstr ( $level_title, '{CATEGORY_LABEL}' ) !== false ) {
									$term_label		= __( 'Category', 'wpce' );
								}
							}
							
							if ( ! empty ( $term_title ) ) {
								$level_title		= str_replace ( '{CATEGORY_LABEL}', $term_label, $level_title );
								$level_title		= str_replace ( '{CATEGORY_NAME}', $term_title, $level_title );
								
								$search_results_title[ $key ]	= $level_title;
							} else {
								unset ( $search_results_title[ $key ] );
							}
						}
						
						// Terms Title
						for ( $index = 0; $index < count ( $search_ancestors ) + 5; $index ++ ) {
							$term_label				= '';
							$term_title				= '';
							
							if ( strstr ( $level_title, '{LEVEL' . ( $index + 1 ) . '_NAME}' ) !== false ) {
								if ( isset ( $search_ancestors[ $index ] ) ) {
									$term_title		= $search_ancestors[ $index ]->title;
									
									if ( isset ( $levels[ $index ] ) && strstr ( $level_title, '{LEVEL' . ( $index + 1 ) . '_LABEL}' ) !== false ) {
										$term_label	= $levels[ $index ]['title'];
									}
								}
								
								if ( ! empty ( $term_title ) ) {
									$level_title	= str_replace ( '{LEVEL' . ( $index + 1 ) . '_LABEL}', $term_label, $level_title );
									$level_title	= str_replace ( '{LEVEL' . ( $index + 1 ) . '_NAME}', $term_title, $level_title );
									
									$search_results_title[ $key ]	= $level_title;
								} else {
									unset ( $search_results_title[ $key ] );
								}
							}
						}
					}
					
					$search_results_title			= implode ( '{SEPARATOR}', $search_results_title );
					
					if ( strstr ( $search_results_title, '{SEPARATOR}' ) !== false ) {
						$search_results_title_separator	= get_post_meta ( self::$search_term->finder_id, 'wpce_search_results_title_separator', true );
						$search_results_title		= str_replace ( '{SEPARATOR}', $search_results_title_separator, $search_results_title );
					}
				}
				
				$title								= apply_filters ( 'wpce_search_results_page_title', $search_results_title, self::$search_term );
			}
		}
		
		return $title;
	}
	
	/**
	 * Override Search Result Page Title?
	 */
	public static function wpce_override_search_results_page_title () {
		$override_search_results_page_title		= true;
		
		if ( is_product_category () || is_product_tag () ) {
			$override_search_results_page_title	= false;
		}
		
		return apply_filters ( 'wpce_override_search_results_page_title', $override_search_results_page_title );
	}
	
	/**
	 * Set Search in WordPress Query
	 *
	public static function search_query_join ( $join, $query ) {
		if ( is_admin () ) {
			return;
		}
		
		if ( ! $query->is_main_query () ) {
			return;
		}
		
		
		if ( isset ( $query->query_vars['wpce_term_id'] ) ) {
			global $wpdb;
			$join .= " LEFT JOIN {$wpdb->prefix}wpce_term_relationships wtr ON ( {$wpdb->posts}.ID = wtr.product_id )";
		}
		
		return $join;
	}*/
}

$GLOBALS['wpce_search'] = new WPCE_Search ();