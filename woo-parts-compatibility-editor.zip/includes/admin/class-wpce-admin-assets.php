<?php
/**
 * Enqueue CSS/JS Files
 */
 
defined ( 'ABSPATH' ) || exit;

class WPCE_Admin_Assets {

	/**
	 * Constructor
	 */
	public function __construct () {
		add_action ( 'admin_enqueue_scripts', array ( __CLASS__, 'load_assets' ) );
	}

	/**
	 * Register/Enqueue Assets
	 */
	public static function load_assets () {
		$screen			= get_current_screen ();
		$screen_id		= $screen ? $screen->id : '';
	
		// Register Scripts
		wp_register_style ( 'wpce-main-style', WPCE_PLUGIN_URL . '/assets/css/admin/style.css', array(), WPCE_PLUGIN_VERSION );
		
		wp_register_script ( 'wpce-terms-metabox-script', WPCE_PLUGIN_URL . '/assets/js/admin/terms-metabox.js', array ( 'jquery' ), WPCE_PLUGIN_VERSION );
		wp_register_script ( 'wpce-main-script', WPCE_PLUGIN_URL . '/assets/js/admin/scripts.js', array ( 'jquery' ), WPCE_PLUGIN_VERSION );
		
		// Localize Vars
		wp_localize_script ( 'wpce-main-script', 'wpce', array(
			'ajax_url'					=> admin_url ('admin-ajax.php'),
			'msg_delete_item'			=> __( 'Are you sure you want to delete this item?', 'wpce' ),
			'msg_refresh_terms_count'	=> __( 'This might take several minutes. Do you still want to proceed?', 'wpce' ),
		) );
		
		// Enqueue Scripts
		if ( in_array ( $screen_id, array ( 'wpce', 'edit-wpce', 'wpce_page_wpce_manage_terms', 'wpce_page_wpce_import_terms', 'wpce_page_wpce-settings', 'shop_order' ) ) ) {
			wp_enqueue_style ( 'wp-color-picker' );
			wp_enqueue_script ( 'wp-color-picker' );
			
			wp_enqueue_style ( 'wpce-main-style' );
			wp_enqueue_script ( 'wpce-main-script' );
		} else if ( in_array ( $screen_id, array ( 'product', 'edit-product' ) ) ) {
			wp_enqueue_style ( 'wpce-main-style' );
			wp_enqueue_script ( 'wpce-terms-metabox-script' );
			
			// Localize Vars
			wp_localize_script( 'wpce-terms-metabox-script', 'wpce_tm', array(
				'ajax_url'					=> admin_url ('admin-ajax.php'),
				'msg_delete_row'			=> __( 'Are you sure you want to delete this row?', 'wpce' ),
				'msg_delete_all_rows'		=> __( 'Are you sure you want to delete all rows?', 'wpce' ),
				'preloader_finder_terms'	=> wpce_get_preloader_finder_terms ( array ( 'json' => true, 'show_empty' => true ) ),
			) );
		}
	}
}

new WPCE_Admin_Assets ();