<?php defined ( 'ABSPATH' ) || exit; ?>

<?php
if ( ! class_exists ( 'WP_List_Table' ) ) {
	require_once ( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class WPCE_Admin_Terms_List_Table extends WP_List_Table {
	
	/**
	 * Post Type
	 */
	protected $post_type = '';
	
	/**
	 * Page
	 */
	protected $page = '';
	
	/**
	 * Finder ID
	 */
	protected $finder_id = '';
	
	/**
	 * Parent ID
	 */
	protected $parent_id = '';
	
	/**
	 * Term Ancestors
	 */
	protected $ancestors = '';
	
	/**
	 * Term Ancestor Labels
	 */
	protected $ancestor_labels = array ();
	
	/**
	 * All Levels
	 */
	protected $levels = array ();
	
	/**
	 * Current Level
	 */
	protected $current_level = '';
	
	function __construct () {
		parent::__construct ( array (
			'singular'			=> 'wpce_term',
			'plural'			=> 'wpce_terms'
		) );
		
		$this->post_type		= isset ( $_REQUEST['post_type'] ) ? $_REQUEST['post_type'] : '';
		$this->page				= isset ( $_REQUEST['page'] ) ? $_REQUEST['page'] : '';
		$this->finder_id		= isset ( $_REQUEST['finder_id'] ) ? absint ( $_REQUEST['finder_id'] ) : 0;
		$this->parent_id		= isset ( $_REQUEST['parent_id'] ) ? absint ( $_REQUEST['parent_id'] ) : 0;
		
		$levels					= wpce_get_levels ( $this->finder_id );
		if ( ! empty ( $levels ) ) {
			$i = 0;
			foreach ( $levels as $level ) {
				$i = $i + 1;
				$this->levels[ $i ]	= $level['title'];
			}
		}
		
		$this->ancestors		= wpce_get_term_ancestors ( $this->parent_id );
		if ( ! empty ( $this->ancestors ) ) {
			$this->ancestors	= array_reverse ( $this->ancestors );
		}
		
		$this->current_level	= ( ! empty ( $this->ancestors ) ? count ( $this->ancestors ) : 0 ) + 1;
	}
	
	function column_default ( $item, $column_name ) {
		switch ( $column_name ) {
			case 'count':
				return '<a href="edit.php?post_type=product&wpce_id=' . $item['term_id'] . '">' . $item[ $column_name ] . '</a>';
				break;
				
			default:
				if ( strstr ( $column_name, 'wpce_level_' ) !== false ) {
					$key = str_replace ( 'wpce_level_', '', $column_name );
					return $this->ancestor_labels[ $key ];
				}
				
				return $item[ $column_name ];
		}
	}
	
	function column_title ( $item ) {
		$actions = array ();
		
		$actions['edit']			= sprintf ( '<a href="#" data-id="%s" data-title="%s">%s</a>', $item['term_id'], htmlspecialchars ( $item['title'] ), __( 'Edit', 'wpce' ) );
		
		if ( isset ( $this->levels[ $this->current_level + 1 ] ) ) {
			$actions['children']	= sprintf ( '<a href="?post_type=%s&page=%s&finder_id=%s&parent_id=%s">%s</a>', $this->post_type, $this->page, $this->finder_id, $item['term_id'], sprintf ( __( 'View %s Terms', 'wpce' ), $this->levels[ $this->current_level + 1 ] ) );
		}
		
		$actions['delete']			= sprintf ( '<a href="?post_type=%s&page=%s&finder_id=%s&parent_id=%s&id=%s&action=%s">%s</a>', $this->post_type, $this->page, $this->finder_id, $this->parent_id, $item['term_id'], 'delete', __( 'Delete', 'wpce' ) );
		
		return sprintf ( '%s %s', $item['title'], $this->row_actions ( $actions ) );
	}
	
	function column_cb ( $item ) {
		return sprintf ( '<input type="checkbox" name="id[]" value="%s" />', $item['term_id'] );
	}
	
	function get_columns () {
		$columns			= array ();
		$columns['cb']		= '<input type="checkbox" />';
		
		for ( $i=1; $i<$this->current_level; $i++ ) {
			$key								= sanitize_title ( $this->levels[ $i ] );
			$this->ancestor_labels[ $key ]		= $this->ancestors[ $i-1 ]->title;
			$columns[ 'wpce_level_' . $key ]	= $this->levels[ $i ];
		}
		
		$columns['title']	= $this->levels[ $this->current_level ];
		$columns['count']	= __( 'Count', 'wpce' );
		
		return $columns;
	}
	
	function get_sortable_columns () {
		$sortable_columns	= array(
			'title'			=> array ( 'title', true ),
			'count'			=> array ( 'count', false ),
		);
		
		return $sortable_columns;
	}
	
	function get_bulk_actions () {
		$actions = array(
			'delete'		=> __( 'Delete', 'wpce' ),
		);
		
		return $actions;
	}
	
	function process_bulk_action () {
		if ( 'delete' === $this->current_action () ) {
			$ids = isset ( $_REQUEST['id'] ) ? $_REQUEST['id'] : array();
			
			if ( ! empty ( $ids ) ) {
				wpce_delete_terms ( $ids );
			}
		}
	}
	
	function prepare_items () {
		global $wpdb;
		
		$table_name				= $wpdb->prefix . 'wpce_terms';
		$per_page				= 20;
		$columns				= $this->get_columns ();
		$hidden					= array ();
		$sortable				= $this->get_sortable_columns ();
		$this->_column_headers	= array ( $columns, $hidden, $sortable );
		$this->process_bulk_action ();
		
		$where					= '';
		$where					.= " AND finder_id='{$this->finder_id}' AND parent_id='{$this->parent_id}'";
		if ( isset ( $_REQUEST['s'] ) ) {
			$s					= esc_sql ( $_REQUEST['s'] );
			if ( ! empty ( $s ) ) {
				$where			.= " AND title LIKE '%{$s}%'";
			}
		}
		
		$total_items			= $wpdb->get_var ( "SELECT COUNT(term_id) FROM $table_name WHERE 1 $where" );
		$paged					= isset ( $_REQUEST['paged'] ) ? max ( 0, intval ( $_REQUEST['paged'] ) - 1 ) : 0;
		$orderby				= ( isset ( $_REQUEST['orderby'] ) && in_array ( $_REQUEST['orderby'], array_keys( $this->get_sortable_columns () ) ) ) ? $_REQUEST['orderby'] : 'title';
		$order					= ( isset ( $_REQUEST['order'] ) && in_array ( $_REQUEST['order'], array ( 'asc', 'desc' ) ) ) ? $_REQUEST['order'] : 'asc';
		$this->items			= $wpdb->get_results ( $wpdb->prepare ( "SELECT * FROM $table_name WHERE 1 $where ORDER BY $orderby $order LIMIT %d OFFSET %d", $per_page, ( $paged * $per_page ) ), ARRAY_A );
		
		$this->set_pagination_args ( array (
			'total_items'		=> $total_items,
			'per_page'			=> $per_page,
			'total_pages'		=> ceil ( $total_items / $per_page )
		) );
	}
}

$table = new WPCE_Admin_Terms_List_Table ();
$table->prepare_items ();

$message = '';
if ( 'delete' === $table->current_action() ) {
	if ( isset ( $_REQUEST['id'] ) && ! empty ( $_REQUEST['id'] ) ) {
		if ( is_array ( $_REQUEST['id'] ) ) {
			$_counter	= count ( $_REQUEST['id'] );
		} else {
			$_counter	= 1;
		}
		
		$message = sprintf ( __( 'Terms deleted: %d', 'wpce' ), $_counter );
	}
}

if ( ! empty ( $message ) ) {
	$message = '
		<div class="updated below-h2" id="message">
			<p>' . $message . '</p>
		</div>
	';
}
?>

<?php
	$finder_id		= isset ( $_REQUEST['finder_id'] ) ? absint ( $_REQUEST['finder_id'] ) : 0;
	$parent_id		= isset ( $_REQUEST['parent_id'] ) ? absint ( $_REQUEST['parent_id'] ) : 0;
	$finder_title	= get_the_title ( $finder_id );
?>

<div class="wrap woocommerce">
	<h1 class="wp-heading-inline"><?php printf ( __( '%s - Manage Terms', 'wpce' ), $finder_title ); ?></h1>
	
	<a href="post.php?post=<?php echo $finder_id; ?>&action=edit" class="page-title-action"><?php _e( 'Edit Finder', 'wpce' ); ?></a>
	
	<a href="#" class="page-title-action wpce-refresh-terms-count" data-finder-id="<?php echo $finder_id; ?>"><?php _e( 'Refresh Terms Count', 'wpce' ); ?></a>
	
	<?php
		if ( $parent_id > 0 ) {
			?><a href="edit.php?post_type=<?php echo $_GET['post_type']; ?>&page=wpce_manage_terms&finder_id=<?php echo $finder_id; ?>" class="page-title-action"><?php _e( 'Manage Terms', 'wpce' ); ?></a><?php
		}
	?>
	
	<a href="edit.php?post_type=<?php echo $_GET['post_type']; ?>&page=wpce_import_terms&finder_id=<?php echo $finder_id; ?>" class="page-title-action"><?php _e( 'Import Terms', 'wpce' ); ?></a>
	
	<a href="admin.php?import=wpce_universal_products_importer&finder_id=<?php echo $finder_id; ?>" class="page-title-action"><?php _e( 'Import Universal Products', 'wpce' ); ?></a>
	
	<?php echo $message; ?>
	<hr class="wp-header-end" />
	
	<form id="wpce-list-table">
		<input type="hidden" name="post_type" value="<?php echo $_REQUEST['post_type'] ?>" />
		<input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
		<input type="hidden" name="finder_id" value="<?php echo $_REQUEST['finder_id'] ?>" />
		
		<?php
			if ( $parent_id > 0 ) {
				?><input type="hidden" name="parent_id" value="<?php echo $parent_id; ?>" /><?php
			}
		?>

		<div class="wpce-forms">
			<p class="term-box">
				<label class="screen-reader-text label-add"><?php _e( 'Add Term:', 'wpce' ); ?></label>
				<label class="screen-reader-text label-edit hidden"><?php _e( 'Edit Term:', 'wpce' ); ?> <a href="#" class="cancel"><?php _e( 'Cancel', 'wpce' ); ?></a></label>
				
				<input type="text" name="term_title" value="" />
				<input type="hidden" name="term_id" value="" />
				
				<input type="button" id="term-submit" class="button" value="<?php _e( 'Submit', 'wpce' ); ?>" />
			</p>
			
			<?php $table->search_box ( __( 'Search', 'wpce' ), 'search_id' ); ?>
			
			<div class="clear"></div>
		</div>
		
		<?php $table->display (); ?>
	</form>
</div>