<?php
/**
 * Terms Importer
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Admin_Importers {

	/**
	 * Constructor
	 */
	public function __construct () {
		add_action ( 'init', array( __CLASS__, 'init' ) );
	}
	
	public static function init () {
		if ( ! self::import_allowed () ) {
			return;
		}
		
		if ( ! function_exists ( 'WC' ) ) {
			return;
		}
		
		add_filter ( 'post_row_actions', array ( __CLASS__, 'add_row_action' ), 10, 2 );
		add_action ( 'admin_menu', array ( __CLASS__, 'add_admin_menu' ) );
		
		add_action ( 'admin_init', array ( __CLASS__, 'register_importer' ) );
		add_action ( 'admin_enqueue_scripts', array ( __CLASS__, 'admin_scripts' ) );
		add_action ( 'wp_ajax_wpce_import', array ( __CLASS__, 'do_ajax_import' ) );
	}

	/**
	 * Checks if imports are allowed for current user
	 */
	protected static function import_allowed () {
		return current_user_can ( 'manage_woocommerce' );
	}
	
	/**
	 * Quick Link: Import Finder Terms
	 */
	public static function add_row_action ( $actions, $post ) {
		if ( $post->post_type == 'wpce' /* && $post->post_status == 'publish' */ ) {
			
			if ( isset ( $actions['edit'] ) ) {
				$trash		= '';
				if ( isset ( $actions['trash'] ) ) {
					$trash	= $actions['trash'];
					unset ( $actions['trash'] );
				}
				
				$actions['import_terms'] = sprintf ( '<a href="%1$s">%2$s</a>', esc_url ( admin_url ( 'edit.php?post_type=wpce&page=wpce_import_terms&finder_id=' . $post->ID ) ), esc_html ( __( 'Import Terms', 'wpce' ) ) );
				
				$actions['import_universal_products'] = sprintf ( '<a href="%1$s">%2$s</a>', esc_url ( admin_url ( 'admin.php?import=wpce_universal_products_importer&finder_id=' . $post->ID ) ), esc_html ( __( 'Import Universal Products', 'wpce' ) ) );
				
				if ( $trash != '' ) {
					$actions['trash'] = $trash;
				}
			}
		}
		
		return $actions;
	}

	/**
	 * New Page Link: Import Finder Terms
	 */
	public static function add_admin_menu () {
		add_submenu_page ( '', __( 'Import Terms', 'wpce' ), __( 'Import Terms', 'wpce' ), 'manage_woocommerce', 'wpce_import_terms', array ( __CLASS__, 'terms_importer' ) );
	}
	
	/**
	 * Register Importer
	 */
	public static function register_importer () {
		if ( defined( 'WP_LOAD_IMPORTERS' ) ) {
			register_importer ( 'wpce_terms_csv', __( 'WPCE Finder Terms (CSV)', 'wpce' ), __( 'Import <strong>WPCE Finder Terms</strong> to your store via a csv file.', 'wpce' ), array ( __CLASS__, 'terms_importer' ) );
			
			register_importer ( 'wpce_universal_products_importer', __( 'WPCE Universal Products (CSV)', 'wpce' ), __( 'Import <strong>Universal Products</strong> to your store via a csv file.', 'wpce' ), array ( __CLASS__, 'universal_products_importer' ) );
		}
	}
	
	/**
	 * New Page: Import Finder Universal Products
	 */
	public static function universal_products_importer () {
		require_once ABSPATH . 'wp-admin/includes/import.php';

		if ( ! class_exists( 'WP_Importer' ) ) {
			$class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';

			if ( file_exists( $class_wp_importer ) ) {
				require $class_wp_importer;
			}
		}
		
		require WPCE_PLUGIN_PATH . '/includes/admin/importers/class-wpce-universal-products-importer.php';

		$importer = new WPCE_Universal_Products_Importer ();
		$importer->dispatch ();
	}
	
	/**
	 * New Page: Import Finder Terms
	 */
	public static function terms_importer () {
		include_once ( WPCE_PLUGIN_PATH . '/includes/admin/importers/class-wpce-csv-importer.php' );
		include_once ( WPCE_PLUGIN_PATH . '/includes/admin/importers/class-wpce-csv-importer-controller.php' );

		$importer = new WPCE_CSV_Importer_Controller ();
		$importer->dispatch ();
	}

	/**
	 * Register Assets
	 */
	public static function admin_scripts () {
		wp_register_script ( 'wpce-import', WPCE_PLUGIN_URL . '/assets/js/admin/wpce-import.js', array ( 'jquery' ), WC_VERSION );
		wp_localize_script ( 'wpce-import', 'wpce_import', array(
			'msg_error'	=> __( 'Oops, something went wrong! Please try again.', 'wpce' ),
		) );
		
		wp_register_style ( 'woocommerce_admin_styles', WC ()->plugin_url () . '/assets/css/admin.css', array (), WC_VERSION );
		wp_enqueue_style ( 'woocommerce_admin_styles' );
	}

	/**
	 * Ajax callback for importing one batch of products from a CSV.
	 */
	public static function do_ajax_import () {
		check_ajax_referer( 'wpce-import', 'security' );

		if ( ! self::import_allowed () || ! isset ( $_POST['file'] ) ) {
			wp_send_json_error ( array( 'message' => __( 'Insufficient privileges to import products.', 'wpce' ) ) );
		}

		include_once ( WPCE_PLUGIN_PATH . '/includes/admin/importers/class-wpce-csv-importer.php' );
		include_once ( WPCE_PLUGIN_PATH . '/includes/admin/importers/class-wpce-csv-importer-controller.php' );
		
		$file				= wc_clean ( wp_unslash( $_POST['file'] ) );
		$finder_id			= isset ( $_POST['finder_id'] ) ? absint ( $_POST['finder_id'] ) : 0;
		$delete_existing	= isset ( $_POST['delete_existing'] ) ? ( bool ) $_POST['delete_existing'] : false;
		
		$params = array (
			'finder_id'			=> $finder_id,
			'delimiter'			=> ! empty ( $_POST['delimiter'] ) ? wc_clean ( wp_unslash ( $_POST['delimiter'] ) ) : ',',
			'start_pos'			=> isset ( $_POST['position'] ) ? absint ( $_POST['position'] ) : 0,
			'mapping'			=> isset ( $_POST['mapping'] ) ? ( array ) wc_clean ( wp_unslash( $_POST['mapping'] ) ) : array (),
			'delete_existing'	=> $delete_existing,
			'lines'				=> apply_filters ( 'wpce_import_batch_size', 30 ),
			'parse'				=> true,
		);

		// Log failures
		if ( 0 !== $params['start_pos'] ) {
			$error_log = array_filter ( ( array ) get_user_option ( 'wpce_import_error_log' ) );
		} else {
			$error_log = array ();
		}
		
		if ( 0 === $params['start_pos'] ) {
			// Delete existing terms
			if ( $delete_existing ) {
				$term_ids = wpce_get_terms ( array (
					'finder_id'	=> $finder_id,
					'fields'	=> 'term_id'
				) );
				
				if ( ! empty ( $term_ids ) ) {
					wpce_delete_terms ( $term_ids );
				}
			}
			
			// Setup Session
			if ( ! session_id () ) {
				session_start ();
			}
			
			$_SESSION['wpce_imported_terms'] = array ();
			$_SESSION['wpce_imported_term_relationships'] = array ();
		}

		$importer			= WPCE_CSV_Importer_Controller::get_importer ( $file, $params );
		$results			= $importer->import ();
		$percent_complete	= $importer->get_percent_complete ();
		$error_log			= array_merge ( $error_log, $results['failed'], $results['skipped'] );

		update_user_option ( get_current_user_id (), 'wpce_import_error_log', $error_log );

		if ( 100 === $percent_complete ) {
			// Clear Session
			if ( isset ( $_SESSION['wpce_imported_terms'] ) ) {
				unset ( $_SESSION['wpce_imported_terms'] );
			}
			
			if ( isset ( $_SESSION['wpce_imported_term_relationships'] ) ) {
				unset ( $_SESSION['wpce_imported_term_relationships'] );
			}
			
			wpce_refresh_terms_count ( $finder_id );
			
			// Send success
			wp_send_json_success (
				array (
					'position'		=> 'done',
					'percentage'	=> 100,
					'url'			=> add_query_arg ( array ( 'nonce' => wp_create_nonce ( 'product-csv' ) ), admin_url ( 'edit.php?post_type=wpce&page=wpce_import_terms&finder_id=' . $finder_id . '&step=done' ) ),
					'imported'		=> count ( $results['imported'] ),
					'failed'		=> count ( $results['failed'] ),
					'skipped'		=> count ( $results['skipped'] ),
				)
			);
		} else {
			wp_send_json_success (
				array (
					'position'		=> $importer->get_file_position (),
					'percentage'	=> $percent_complete,
					'imported'		=> count ( $results['imported'] ),
					'failed'		=> count ( $results['failed'] ),
					'skipped'		=> count ( $results['skipped'] ),
				)
			);
		}
	}
}

new WPCE_Admin_Importers ();