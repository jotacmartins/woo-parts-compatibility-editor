<?php
/**
 * Settings Panel
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Admin_Settings {

	/**
	 * Constructor
	 */
	public function __construct () {
		add_action ( 'admin_menu', array ( $this, 'add_settings_menu' ) );
		add_action ( 'admin_init', array ( $this, 'save_settings' ) );
	}

	/**
	 * Add Admin Sub Menu: Settings
	 */
	public function add_settings_menu () {
		add_submenu_page ( 'edit.php?post_type=wpce', __( 'WPCE Settings', 'wpce' ), __( 'Settings', 'wpce' ), 'manage_woocommerce', 'wpce-settings', array ( $this, 'add_settings' ) );
	}
	
	/**
	 * Add Settings Menu Form
	 */
	public function add_settings () {
		$option_sections = self::get_settings ();
		
		// Add Settings Form
		if ( ! empty ( $option_sections ) ) {
			?><div class="wrap woocommerce">
				<h1><?php _e( 'WPCE Settings', 'wpce' ); ?></h1>
				
				<form method="post" action="">
					<table class="form-table">
						<tbody>
							<?php
								foreach ( $option_sections as $option_section ) {
									if ( isset ( $option_section['options'] ) && ! empty ( $option_section['options'] ) ) {
										/* ?><tr class="wpce-table-block-heading">
											<th colspan="2" scope="row"><?php echo $option_section['heading']; ?></th>
										</tr><?php */
										
										foreach ( $option_section['options'] as $option ) {
											$option = wp_parse_args ( $option, array (
												'type'				=> 'text',
												'label'				=> '',
												'desc'				=> '',
												'placeholder'		=> '',
												'opts'				=> array (),
												'default'			=> '',
												'custom_attributes'	=> array ()
											) );
								
											// Option Value
											$value = get_option ( $option['name'] );
											if ( $value === false ) {
												$value = $option['default'];
											}
									
											// Custom Attribute Handling
											$custom_attributes = array ();
									
											if ( ! empty ( $option['custom_attributes'] ) && is_array ( $option['custom_attributes'] ) ) {
												foreach ( $option['custom_attributes'] as $attribute => $attribute_value ) {
													$custom_attributes[] = esc_attr ( $attribute ) . '="' . esc_attr ( $attribute_value ) . '"';
												}
											}
									
											$custom_attributes = implode ( ' ', $custom_attributes );
									
											// Option Row
											?><tr class="field_<?php echo $option['type']; ?>">
												<th scope="row"><label for="<?php echo $option['name']; ?>"><?php echo $option['label']; ?></label></th>
												<td><?php wpce_form_field ( $option, $value, $custom_attributes ); ?></td>
											</tr><?php
										}
									}
									
								}
							?>
						</tbody>
					</table>
					
					<input type="hidden" name="action" value="wpce_settings" />
					<?php submit_button (); ?>
				</form>
			</div><?php
		}
	}
	
	/**
	 * Save Settings Menu Form
	 */
	public function save_settings () {
		if ( empty ( $_POST ) ) {
			return false;
		}
		
		if ( isset ( $_POST['action'] ) && $_POST['action'] == 'wpce_settings' ) {
			// Options to Update will be Stored Here and Saved Later
			$update_options = array ();
			
			$option_sections = self::get_settings ();
			if ( ! empty ( $option_sections ) ) {
				foreach ( $option_sections as $option_section ) {
					if ( isset ( $option_section['options'] ) && ! empty ( $option_section['options'] ) ) {
						foreach ( $option_section['options'] as $option ) {
							if ( ! isset ( $option['name'] ) || ! isset ( $option['type'] ) ) {
								continue;
							}
					
							list ( $option_name, $setting_name, $value ) = wpce_format_form_field ( $option );
							
							// Check if Option is an Array and Handle That Differently to Single Values
							if ( $option_name && $setting_name ) {
								if ( ! isset ( $update_options[ $option_name ] ) ) {
									$update_options[ $option_name ] = get_option ( $option_name, array () );
								}
								
								if ( ! is_array ( $update_options[ $option_name ] ) ) {
									$update_options[ $option_name ] = array ();
								}
								
								$update_options[ $option_name ][ $setting_name ] = $value;
							} else {
								$update_options[ $option_name ] = $value;
							}
						}
					}
					
				}
				
				// Save All Options in Our Array
				foreach ( $update_options as $name => $value ) {
					update_option ( $name, $value );
				}

				return true;
			}
		}
	}
	
	/**
	 * Setting Options
	 */
	public static function get_settings () {
		$option_sections = array (
			'section_labels'							=> array (
				'heading'								=> __( 'General Options', 'wpce' ),
				'options'								=> array (
					array (
						'name'							=> 'wpce_clear_data_on_uninstall',
						'label'							=> __( 'Remove Data on Uninstall?', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'Enable this checkbox if you want to completely remove all the data ( includes options, settings, custom post types and database tables, everything added by this plugin ) when you uninstall this plugin. A plugin is considered uninstalled when you deactivate a plugin first, and then click on delete link within the WordPress Admin.', 'wpce' )
					)
				)
			)
		);
		
		return apply_filters ( 'wpce_settings', $option_sections );
	}
}

new WPCE_Admin_Settings ();