<?php
/**
 * Terms List
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Admin_Terms_List {

	/**
	 * Constructor
	 */
	public function __construct () {
		add_filter ( 'post_row_actions', array ( __CLASS__, 'add_row_action' ), 10, 2 );
		add_action ( 'admin_menu', array ( __CLASS__, 'add_admin_menu' ) );
	}
	
	/**
	 * Quick Link: Manage Finder Terms
	 */
	public static function add_row_action ( $actions, $post ) {
		if ( $post->post_type == 'wpce' /* && $post->post_status == 'publish' */ ) {
			
			if ( isset ( $actions['edit'] ) ) {
				if ( isset ( $actions['inline hide-if-no-js'] ) ) {
					unset ( $actions['inline hide-if-no-js'] );
				}
				
				$trash		= '';
				if ( isset ( $actions['trash'] ) ) {
					$trash	= $actions['trash'];
					unset ( $actions['trash'] );
				}
				
				$actions['manage_terms'] = sprintf ( '<a href="%1$s">%2$s</a>', esc_url ( admin_url ( 'edit.php?post_type=wpce&page=wpce_manage_terms&finder_id=' . $post->ID ) ), esc_html ( __( 'Manage Terms', 'wpce' ) ) );
				
				if ( $trash != '' ) {
					$actions['trash'] = $trash;
				}
			}
		}
		
		return $actions;
	}

	/**
	 * New Page Link: Manage Finder Terms
	 */
	public static function add_admin_menu () {
		add_submenu_page ( '', __( 'Manage Terms', 'wpce' ), __( 'Manage Terms', 'wpce' ), 'manage_woocommerce', 'wpce_manage_terms', array ( __CLASS__, 'terms_list' ) );
	}
	
	/**
	 * New Page: Manage Finder Terms
	 */
	public static function terms_list () {
		include_once ( 'class-wpce-admin-terms-list-table.php' );
	}
}

new WPCE_Admin_Terms_List ();