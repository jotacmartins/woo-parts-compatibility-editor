<?php
/**
 * Post Types: Meta Boxes || Listing Columns
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Admin_Post_Types {

	/**
	 * @var array $settings 
	 */
	public static $settings = array ();

	/**
	 * Constructor
	 */
	public function __construct () {
		// Admin notices.
		add_filter ( 'post_updated_messages', array ( __CLASS__, 'finder_updated_messages' ) );
		
		// Custom Meta Boxes
		add_action ( 'add_meta_boxes', array ( __CLASS__, 'add_meta_boxes' ) );
		add_action ( 'save_post', array ( __CLASS__, 'save_meta_boxes' ) );
		
		// Post List Columns
		add_action ( 'manage_wpce_posts_columns', array ( __CLASS__, 'wpce_column_headings' ) );
		add_action ( 'manage_wpce_posts_custom_column', array ( __CLASS__, 'wpce_column_values' ), 10, 2 );
		
		// Add Count Filter on Products Listing
		add_action ( 'pre_get_posts', array ( __CLASS__, 'count_filter' ) );
		
		// Add WooCommerce JS Libraries Support eg: Products Suggestion: wc-product-search
		add_filter ( 'woocommerce_screen_ids', array ( __CLASS__, 'add_screen_id' ) );
		
		// Duplicate a Product, Duplicate its Terms also
		add_action ( 'woocommerce_product_duplicate', array ( __CLASS__, 'duplicate_product_terms' ), 10, 2 );
	}
	
	/**
	 * Change Messages on Finder Update
	 */
	public static function finder_updated_messages ( $messages ) {
		global $post;

		$messages['wpce']	= array (
			0				=> '',
			1				=> __( 'Finder updated.', 'wpce' ),
			2				=> __( 'Custom field updated.', 'wpce' ),
			3				=> __( 'Custom field deleted.', 'wpce' ),
			4				=> __( 'Finder updated.', 'wpce' ),
			5				=> __( 'Revision restored.', 'wpce' ),
			6				=> __( 'Finder published.', 'wpce' ),
			7				=> __( 'Finder saved.', 'wpce' ),
			8				=> __( 'Finder submitted.', 'wpce' ),
			9				=> sprintf ( __( 'Finder scheduled for: %1$s.', 'wpce' ), '<strong>' . date_i18n ( __( 'M j, Y @ G:i', 'wpce' ), strtotime ( $post->post_date ) ) ),
			10				=> sprintf ( __( 'Finder draft updated.', 'wpce' ) ),
		);

		return $messages;
	}

	/**
	 * Add Custom Meta Boxes
	 */
	public static function add_meta_boxes () {
		add_meta_box ( 'meta-box-wpce-levels', __( 'Finder Levels', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'levels' ) );
		
		add_meta_box ( 'meta-box-wpce-categories-level', __( 'Categories Level', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'categories_level' ) );
		
		add_meta_box ( 'meta-box-wpce-search-form', __( 'Search Form', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'search_form' ) );
		
		add_meta_box ( 'meta-box-wpce-search-results-page', __( 'Search Results Page', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'search_results_page' ) );
		
		add_meta_box ( 'meta-box-wpce-products-categories', __( 'Products / Categories', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'products_categories' ) );
		
		add_meta_box ( 'meta-box-wpce-remember', __( 'Remember Search', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'remember' ) );
		
		add_meta_box ( 'meta-box-wpce-user-searches', __( 'Search History & Saved Searches', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'user_searches' ) );
		
		add_meta_box ( 'meta-box-wpce-tab', __( 'Product Tab', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'product_tab' ) );
		
		add_meta_box ( 'meta-box-wpce-product-validator', __( 'Product Validator', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'product_validator' ) );
		
		add_meta_box ( 'meta-box-wpce-searched-terms-to-order', __( 'Display User Searched Terms', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'show_searched_terms_with_order' ) );
		
		//add_meta_box ( 'meta-box-wpce-style', __( 'Custom Style', 'wpce' ), array ( __CLASS__, 'wpce_meta_box' ), 'wpce', 'normal', 'high', array ( 'type' => 'style' ) );
	}
	
	/**
	 * Custom Meta Box Callback - WPCE Custom Options
	 */
	public static function wpce_meta_box ( $post, $callback_args ) {
		$options = self::get_settings ( isset ( $callback_args['args']['type'] ) ? $callback_args['args']['type'] : '' );
		
		if ( empty ( $options ) ) {
			return;
		}
		
		$post_meta_keys = array ();
		if ( $post->ID ) {
			$post_meta_keys = get_post_custom_keys ( $post->ID );
		}
		
		wp_nonce_field ( 'wpce_meta_box', 'wpce_meta_box_nonce' );
		
		?><table class="form-table">
			<tbody>
				<?php
					foreach ( $options as $option ) {
						// Default Args
						$option = wp_parse_args( $option, array (
							'type'				=> 'text',
							'label'				=> '',
							'desc'				=> '',
							'desc_tip'			=> false,
							'placeholder'		=> '',
							'opts'				=> array (),
							'default'			=> '',
							'custom_attributes'	=> array ()
						) );
			
						// Custom Attribute Handling
						$custom_attributes = array ();
				
						if ( ! empty ( $option['custom_attributes'] ) && is_array ( $option['custom_attributes'] ) ) {
							foreach ( $option['custom_attributes'] as $attribute => $attribute_value ) {
								$custom_attributes[] = esc_attr( $attribute ) . '="' . esc_attr( $attribute_value ) . '"';
							}
						}
				
						$custom_attributes = implode( ' ', $custom_attributes );
				
						// Option Row
						if ( $option['type'] == 'heading' || $option['type'] == 'note' ) {
							?><tr class="field-<?php echo $option['type']; ?>">
								<th scope="row" colspan="2"><?php echo $option['label']; ?></th>
							</tr><?php
						} else {
							// Option Value
							$value = get_post_meta ( $post->ID, $option['name'], true );
													
							if ( empty ( $post_meta_keys ) || ! in_array ( $option['name'], $post_meta_keys ) ) {
								$value = $option['default'];
							}
							
							?><tr class="field-<?php echo $option['type']; ?>"><?php
								if ( $option['type'] != 'levels' ) {
									?><th scope="row"><label for="<?php echo $option['name']; ?>"><?php echo $option['label']; ?></label></th><?php
								}
								
								?><td <?php if ( $option['type'] == 'levels' ) { echo 'colspan="2"'; } ?>><?php wpce_form_field ( $option, $value, $custom_attributes ); ?></td><?php
							?></tr><?php
						}
					}
				?>
			</tbody>
		</table><?php
	}
	
	/**
	 * Save Custom Meta Boxes
	 */
	public static function save_meta_boxes ( $post_id ) {
		if ( ! isset ( $_POST['wpce_meta_box_nonce'] ) ) {
			return $post_id;
		}

		if ( ! wp_verify_nonce( $_POST['wpce_meta_box_nonce'], 'wpce_meta_box' ) ) {
			return $post_id;
		}

		if ( defined ( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		if ( 'page' == $_POST['post_type'] ) {
			if ( ! current_user_can ( 'edit_page', $post_id ) ) {
				return $post_id;
			}
		} else {
			if ( ! current_user_can ( 'edit_post', $post_id ) ) {
				return $post_id;
			}
		}
		
		// Options to Update will be Stored Here and Saved Later
		$update_options = array ();
		
		$option_types = self::get_settings ();
		if ( ! empty ( $option_types ) ) {
			foreach ( $option_types as $options ) {
				if ( ! empty ( $options ) ) {
					foreach ( $options as $option ) {
						if ( ! isset ( $option['name'] ) || ! isset ( $option['type'] ) ) {
							continue;
						}
						
						list ( $option_name, $setting_name, $value ) = wpce_format_form_field ( $option );
						
						/*if ( $option_name == 'post_name' ) {
							echo $value;
							exit;
						}*/
						
						if ( $option['type'] == 'multiselect' ) {
							if ( is_array ( $value ) ) {
								$raw_value = array_filter ( $value );
								
								if ( empty ( $raw_value ) ) {
									$value = '';
								}
							}
						}
		
						// Check if Option is an Array and Handle That Differently to Single Values
						if ( $option_name && $setting_name ) {
							if ( ! isset ( $update_options[ $option_name ] ) ) {
								$update_options[ $option_name ] = get_option( $option_name, array () );
							}
							if ( ! is_array ( $update_options[ $option_name ] ) ) {
								$update_options[ $option_name ] = array ();
							}
							$update_options[ $option_name ][ $setting_name ] = $value;
						} else {
							$update_options[ $option_name ] = $value;
						}
					}
				}
			}
		}
		
		// Save All Options in Our Array
		foreach ( $update_options as $name => $value ) {
			update_post_meta ( $post_id, $name, $value );
		}
	}
	
	/**
	 * Setting Options
	 */
	public static function get_settings ( $type='' ) {
		if ( empty ( self::$settings ) ) {
			$categories = self::get_categories();
			
			$options = array (
				'levels'								=> array (
					array (
						'name'							=> 'wpce_number_of_levels',
						'label'							=> __( 'Number of Levels', 'wpce' ),
						'type'							=> 'number',
						'desc'							=> __( 'Enter number of dropdowns you want for this finder.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_levels',
						'label'							=> __( 'Level #', 'wpce' ),
						'type'							=> 'levels'
					),
				),
				
				'categories_level'						=> array (
					array (
						'name'							=> 'wpce_categories_level',
						'label'							=> __( 'Enable', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'This option allows you to add categories dropdown among other dropdowns in this finder.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_categories_level_position',
						'label'							=> __( 'Position', 'wpce' ),
						'type'							=> 'select',
						'opts'							=> array (
							''							=> __( '-- Select --', 'wpce' ),
							'first'						=> __( 'First - Before all dropdowns', 'wpce' ),
							'last'						=> __( 'Last - After all dropdowns', 'wpce' ),
						),
						'desc'							=> __( 'This option allows you to set a position of categories dropdown.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_categories_level_dropdown_label',
						'label'							=> __( 'Dropdown Label', 'wpce' ),
						'type'							=> 'text',
						'default'						=> __( 'Select Category', 'wpce' ),
						'desc'							=> __( 'This label shows before/above dropdown based on the selected template. eg: Select Category.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_categories_level_dropdown_title',
						'label'							=> __( 'Dropdown Title', 'wpce' ),
						'type'							=> 'text',
						'default'						=> __( '-- Select Category --', 'wpce' ),
						'desc'							=> __( 'This option allows you to set a title for first option from dropdown. eg: -- Select Category --.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_categories_level_required',
						'label'							=> __( 'Required', 'wpce' ),
						'type'							=> 'select',
						'opts'							=> array (
							'no'						=> __( 'No', 'wpce' ),
							'yes'						=> __( 'Yes', 'wpce' )
						),
						'desc'							=> __( 'This option makes it compulsory for users to select a category before search.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_categories_level_required_message',
						'label'							=> __( 'Required Message', 'wpce' ),
						'type'							=> 'text',
						'desc'							=> __( 'A prompt message which shows if one tries to submit a search without selecting a category.', 'wpce' ),
					)
				),
				
				'search_form'								=> array (
					/* array (
						'name'							=> 'post_name',
						'label'							=> __( 'Slug', 'wpce' ),
						'type'							=> 'text',
						'desc'							=> __( "A slug is a bit of text that appears in the URL of a search results page. Essentially, it's the part of URL that differentiates every finder. If you are not sure about what to type in this field then leave it empty and it will auto generate a slug in such case.", 'wpce' )
					), */
					
					array (
						'name'							=> 'wpce_terms_load_method',
						'label'							=> __( 'Terms Load Method', 'wpce' ),
						'type'							=> 'select',
						'opts'							=> array (
							''							=> __( '-- Select --', 'wpce' ),
							'ajax'						=> __( 'AJAX - Load terms on request in runtime', 'wpce' ),
							'json'						=> __( 'JSON - Preload all terms in advance', 'wpce' ),
						),
						'default'						=> 'ajax',
						'desc'							=> __( "Sometimes you want the next dropdown to load instantly after one selects a term from current dropdown. That's when you might need <strong>JSON</strong> method. <strong>JSON</strong> method is much quicker to load terms as compared to <strong>AJAX</strong> but there is one limitation of using this method. This method works perfectly with small amount of data, but can hang/crash your browser when there is a huge list of terms. In that case, you can go with the <strong>AJAX</strong> method. It is better to give a try to both methods before you choose one.", 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_user_friendly_dropdowns',
						'label'							=> __( 'User Friendly Dropdowns', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'This option not only restyles the default dropdowns to much more user friendly dropdowns but extends its functionality too such as searching and highlighting.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_show_empty_terms',
						'label'							=> __( 'Show Empty Terms', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( "By default, this plugin doesn't show empty terms in dropdowns. So, if you have created a term but haven't associated any product to it, the dropdowns wouldn't display this term. This option tells your system to show empty terms too.", 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_disable_dependent_dropdowns',
						'label'							=> __( 'Disable Dependent Dropdowns', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'This option prevents the access of next dropdown until chooses current dropdown.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_submit_label',
						'label'							=> __( 'Submit Button Label', 'wpce' ),
						'type'							=> 'text',
						'default'						=> __( 'Submit', 'wpce' ),
						'desc'							=> __( 'This option helps you to change the label of submit button.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_auto_submit',
						'label'							=> __( 'Auto Submit', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'Enable this option will submit the form automatically when user selects an option from last dropdown.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_hide_submit_button',
						'label'							=> __( 'Hide Submit Button', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( "Enable <strong>Auto Submit</strong> and you don't want to show submit button anymore, this option will allow you to hide submit button.", 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_validation_border',
						'label'							=> __( 'Validation Border', 'wpce' ),
						'type'							=> 'checkbox',
						'default'						=> 'yes',
						'desc'							=> __( "This option will change the border color of a dropdown to red which doesn't validate according to the level's settings.", 'wpce' )
					)
				),
				
				'search_results_page'					=> array (
					array (
						'name'							=> 'wpce_search_results_title',
						'label'							=> __( 'Page Title', 'wpce' ),
						'type'							=> 'text',
						'default'						=> sprintf ( __( 'Search Result for: %s%s %s%s %s', 'wpce' ), '{LEVEL1_LABEL}: {LEVEL1_NAME}', '{SEPARATOR}', '{LEVEL2_LABEL}: {LEVEL2_NAME}', '{SEPARATOR}', '{LEVEL3_LABEL}: {LEVEL3_NAME}' ),
						'class'							=> 'large-text',
						'desc'							=> sprintf ( __( 'This options allows you to customize the title on search results page. There are few constants which helps you to use dynamic values in title. EG:<br/><strong>%s</strong> : Reads value from next option <strong>%s</strong><br/><strong>%s</strong> : Label of category<br/><strong>%s</strong> : Title of selected category from dropdown<br/><strong>%s</strong> : Label of first dropdown<br/><strong>%s</strong> : Title of selected term from first dropdown<br/><strong>%s</strong> : Label of second dropdown<br/><strong>%s</strong> : Title of selected term from second dropdown<br/>.....', 'wpce' ), '{SEPARATOR}', __( 'Search Results Title Separator', 'wpce' ), '{CATEGORY_LABEL}', '{CATEGORY_NAME}', '{LEVEL1_LABEL}', '{LEVEL1_NAME}', '{LEVEL2_LABEL}', '{LEVEL2_NAME}' ),
					),
					
					array (
						'name'							=> 'wpce_search_results_title_separator',
						'label'							=> __( 'Page Title Separator', 'wpce' ),
						'type'							=> 'text',
						'default'						=> ',',
						'class'							=> 'small-text',
						'desc'							=> sprintf ( __( 'This option allows you to set a separator for previous option <strong>%s</strong>.' ), __( 'Search Results Title', 'wpce' ) ),
					),
					
					array (
						'name'							=> 'wpce_search_results_display_mode',
						'label'							=> __( 'Display Mode', 'wpce' ),
						'type'							=> 'select',
						'opts'							=> array (
							''							=> __( '-- Select --', 'wpce' ),
							'products'					=> __( 'Show Products', 'wpce' ),
							'shop'						=> __( 'Main Shop Page Display Mode', 'wpce' ),
						),
						'default'						=> 'products',
						'desc'							=> sprintf ( __( 'In WooCommerce, you can change the display mode for main shop page through this <a href="%s" target="_blank">settings panel</a>. If you want search results page to follow the same display mode, you can choose this option as <strong>Main Shop Page Display Mode</strong>. This option helps you to show products or categories based on what you have selected for main shop page.', 'wpce' ), esc_url ( add_query_arg ( array ( 'autofocus' => array ( 'panel' => 'woocommerce' ), 'url' => wc_get_page_permalink ( 'shop' ) ), admin_url ( 'customize.php' ) ) ) ),
					),
					
					array (
						'name'							=> 'wpce_custom_url',
						'label'							=> __( 'Custom Destination URL', 'wpce' ),
						'type'							=> 'text',
						'class'							=> 'large-text',
						'desc'							=> sprintf ( __( "Currently search form takes users to its own archive page after submittion. Few times you want to redirect them to a special page eg: category page or shop page. This option does it by allowing you to set a custom URL.<br/>Please don't include <strong>%s</strong> in URL. EG: If you want to set <strong>%s</strong> as custom URL, then fill it as <strong>%s</strong> only.", 'wpce' ), home_url (), home_url () . '/product-category/my-custom-cat/', '/product-category/my-custom-cat/' )
					),
					
					array (
						'name'							=> 'wpce_redirect_single_search',
						'label'							=> __( 'Redirect Single Search Result', 'wpce' ),
						'type'							=> 'checkbox',
						'default'						=> 'yes',
						'desc'							=> __( 'In WooCommerce if you search for a product and there is only one search result then WooCommerce will directly redirect you to product details page. This option allows you to manage redirection to product details page in case if there is only one search result.', 'wpce' )
					),
				),
				
				'products_categories'					=> array (
					array (
						'name'							=> 'wpce_universal_products',
						'label'							=> __( 'Universal Products', 'wpce' ),
						'type'							=> 'products',
						'desc'							=> __( 'In case you want few products to list always in search results page even when those are not associated to user selected terms, this option allows you to select those products rather you manually associate all terms to those products.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_categories_to_include',
						'label'							=> __( 'Categories to Include', 'wpce' ),
						'type'							=> 'multiselect',
						'custom_attributes'				=> array ( 'size' => 10 ),
						'opts'							=> apply_filters ( 'wpce_setting_categories_to_include', array ( '' => __( 'All Categories', 'wpce' ) ) + $categories ),
						'desc'							=> __( "In case you have multiple finders and each finder is supposed to show search results from different categories. Choose categories specific to this finder and it will search results only from these categories. Use <strong>Ctrl</strong> / <strong>Shift</strong> keys to select multiple items.<br/>Remember if you have selected <strong>All Categories</strong>, then it wouldn't allow you to select specific categories.", 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_categories_to_exclude',
						'label'							=> __( 'Categories to Exclude', 'wpce' ),
						'type'							=> 'multiselect',
						'custom_attributes'				=> array ( 'size' => 10 ),
						'opts'							=> apply_filters( 'wpce_setting_categories_to_exclude', array ( '' => __( 'Select Categories', 'wpce' ) ) + $categories ),
						'desc'							=> __( 'Choose categories which you want to exclude from search. Use <strong>Ctrl</strong> / <strong>Shift</strong> keys to select multiple items.', 'wpce' )
					),
				),
				
				'remember'								=> array (
					array (
						'name'							=> 'wpce_remember_search',
						'label'							=> __( 'Enable', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'Enable this option will restrict WooCommerce catalog pages to include only those products throughout the website which match user searched terms until user resets it.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_remember_search_on',
						'label'							=> __( 'Enable on', 'wpce' ),
						'type'							=> 'radio',
						'opts'							=> array (
							'all'						=> __( 'All Shop / Catalog Pages [help]This option will enable <strong>Remember Search</strong> feature on all WooCommerce catalog pages. However, there are chances of conflict when you have created more than one fineders[/help]', 'wpce' ),
							'categories'				=> __( 'Category Pages Only [help]This option can be useful when you have created more than one finders, and each finder to work independently on their relative categories[/help]', 'wpce' ),
						),
						'default'						=> 'all'
					),
					
					array (
						'name'							=> 'wpce_reset_search',
						'label'							=> __( 'Enable Reset Search Button', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( "Enable <strong>Reset Search</strong> option and it will add a link next to submit button or below the form which will allow users to reset their performed search.", 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_reset_search_label',
						'label'							=> __( 'Reset Search Button Label', 'wpce' ),
						'type'							=> 'text',
						'default'						=> __( 'Reset', 'wpce' ),
						'desc'							=> __( 'This option helps you to change the label of reset search button.', 'wpce' ),
					),
				),
				
				'user_searches'							=> array (
					array (
						'name'							=> 'wpce_save_user_searches',
						'label'							=> __( 'Enable', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( "Enable this option will start storing user's most recent search history temporarily in browser cookies and will allow them to move selected searches from <strong>Search History</strong> to <strong>Saved Searches</strong> list. <strong>Search History</strong> and <strong>Saved Searches</strong> work together in order to enable users to quickly find the data they use most often.", 'wpce' )
					),
					
					array (
						'label'							=> __( 'Search History:', 'wpce' ),
						'type'							=> 'heading'
					),
					
					array (
						'name'							=> 'wpce_user_search_history_title',
						'label'							=> __( 'Title', 'wpce' ),
						'type'							=> 'text',
						'desc'							=> __( 'This option allows you to set a title for <strong>Search History</strong> section.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_user_search_history_description',
						'label'							=> __( 'Description', 'wpce' ),
						'type'							=> 'text',
						'class'							=> 'large-text',
						'desc'							=> __( 'This option allows you to show a short description after <strong>Search History</strong> title.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_user_search_history_limit',
						'label'							=> __( 'Limit', 'wpce' ),
						'type'							=> 'text',
						'default'						=> '5',
						'desc'							=> __( 'This option allows you to limit maximum number of searches in history per user.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_user_search_history_clear_text',
						'label'							=> __( 'Text: Clear', 'wpce' ),
						'type'							=> 'text',
						'default'						=> __( 'Clear Search History', 'wpce' ),
						'desc'							=> __( 'This option allows you to set text for the link which allows users to clear saved searches from <strong>Search History</strong> list.', 'wpce' ),
					),
					
					array (
						'label'							=> __( 'Saved Searches:', 'wpce' ),
						'type'							=> 'heading'
					),
					
					array (
						'name'							=> 'wpce_user_saved_searches_title',
						'label'							=> __( 'Title', 'wpce' ),
						'type'							=> 'text',
						'desc'							=> __( 'This option allows you to set a title for <strong>Saved Searches</strong> section.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_user_saved_searches_description',
						'label'							=> __( 'Description', 'wpce' ),
						'type'							=> 'text',
						'class'							=> 'large-text',
						'desc'							=> __( 'This option allows you to show a short description after <strong>Saved Searches</strong> title.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_user_saved_searches_limit',
						'label'							=> __( 'Limit', 'wpce' ),
						'type'							=> 'text',
						'default'						=> '5',
						'desc'							=> __( 'This option allows you to limit maximum number of searches to save per user.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_user_saved_searches_clear_text',
						'label'							=> __( 'Text: Clear', 'wpce' ),
						'type'							=> 'text',
						'default'						=> __( 'Clear Saved Searches', 'wpce' ),
						'desc'							=> __( 'This option allows you to set text for the link which allows users to clear saved searches from <strong>Saved Searches</strong> list.', 'wpce' ),
					),
					
					array (
						'label'							=> __( 'Quick Links Text:', 'wpce' ),
						'type'							=> 'heading'
					),
					
					array (
						'name'							=> 'wpce_user_search_go_text',
						'label'							=> __( 'Text: Go', 'wpce' ),
						'type'							=> 'text',
						'default'						=> __( 'Go', 'wpce' ),
						'desc'							=> __( 'This option allows you to set text for the link which allows users to go on search results page.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_user_search_save_text',
						'label'							=> __( 'Text: Save', 'wpce' ),
						'type'							=> 'text',
						'default'						=> __( 'Save', 'wpce' ),
						'desc'							=> __( 'This option allows you to set text for the link which allows users to save search from <strong>Search History</strong> to <strong>Saved Searches</strong> list.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_user_search_delete_text',
						'label'							=> __( 'Text: Delete', 'wpce' ),
						'type'							=> 'text',
						'default'						=> __( 'Delete', 'wpce' ),
						'desc'							=> __( 'This option allows you to set text for the link which allows users to delete search from <strong>Search History</strong> and <strong>Saved Searches</strong> lists.', 'wpce' ),
					),
					
					/*array (
						'name'							=> 'wpce_save_user_searched_terms_with_order',
						'label'							=> __( 'Save User Searched Terms', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'This option will save user searched terms through <strong>Search Form</strong> or <strong>Product Validator</strong> to WooCommerce database along with ordered products.', 'wpce' )
					),*/
					
					/*array (
						'name'							=> 'wpce_show_user_searched_terms_on',
						'label'							=> __( 'Enable on ', 'wpce' ),
						'type'							=> 'checkbox_group',
						'opts'							=> array (
							'cart'						=> __( 'Cart', 'wpce' ),
							'checkout'					=> __( 'Checkout', 'wpce' ),
							'user_order_details'		=> __( 'Frontend Order Detail Pages ( Thank You, My Account -> Orders )', 'wpce' ),
							'admin_order_details'		=> __( 'Backend Order Detail Pages ( View Order )', 'wpce' ),
							'email_templates'			=> __( 'Email Notifications', 'wpce' ),
						),
						'desc'							=> __( 'This option allows you to display user selected terms against each product on WooCommerce pages ( EG: Cart / Checkout / Order Details ).', 'wpce' )
					),*/
				),
				
				'product_tab'							=> array (
					array (
						'name'							=> 'wpce_tab',
						'label'							=> __( 'Enable', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'This option helps you to add a custom tab on product details page which lists current product associated all the terms from this finder.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_tab_ajax',
						'label'							=> __( 'Ajax', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( "Use this option while you have a long list of terms to show on the product details page and it's slowing down the speed. This option will force the terms to load via ajax once the page loads completely.", 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_tab_ajax_loading_text',
						'label'							=> __( 'Ajax Loading Text', 'wpce' ),
						'type'							=> 'text',
						'desc'							=> __( 'This option allows you to set a text which shows before the terms load via ajax. eg: Loading...', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_tab_priority',
						'label'							=> __( 'Priority', 'wpce' ),
						'type'							=> 'text',
						'default'						=> '50',
						'desc'							=> __( 'This option allows you to re-position the custom tab among multiple tabs.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_tab_title',
						'label'							=> __( 'Title', 'wpce' ),
						'type'							=> 'text',
						'desc'							=> __( 'This option allows you to set a title for custom tab. This is a required field in order to show custom tab on product details page.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_tab_heading',
						'label'							=> __( 'Heading', 'wpce' ),
						'type'							=> 'text',
						'desc'							=> __( 'This option allows you to show a heading before terms listing in content area.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_tab_description',
						'label'							=> __( 'Description', 'wpce' ),
						'type'							=> 'text',
						'class'							=> 'large-text',
						'desc'							=> __( 'This option allows you to show a short description before terms listing in content area.', 'wpce' ),
					),
				),
				
				'product_validator'						=> array (
					array (
						'name'							=> 'wpce_product_validator',
						'label'							=> __( 'Enable', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'This option allows you to place a validator on product details page which helps users to validate current product against their required specific terms from this finder.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_product_validator_disable_on_universal_products',
						'label'							=> __( 'Disable on Universal Products', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'By default, <strong>Product Validator</strong> shows on all products including <strong>Universal Products</strong>, but you can still disable it for <strong>Universal Products</strong> by enabling this option.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_product_validator_heading',
						'label'							=> __( 'Heading', 'wpce' ),
						'type'							=> 'text',
						'class'							=> 'large-text',
						'desc'							=> __( 'This option allows you to show a heading before validator.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_product_validator_hide_cart_button',
						'label'							=> __( 'Hide Cart Button', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'Enable this option will hide the <strong>Add to Cart</strong> button automatically if user selected terms are not associated to current product.', 'wpce' )
					),
					
					array (
						'name'							=> 'wpce_product_validator_success_message',
						'label'							=> __( 'Success Message', 'wpce' ),
						'type'							=> 'text',
						'class'							=> 'large-text',
						'desc'							=> __( 'This message will show just below the validator if user selected terms are associated to current product.', 'wpce' ),
					),
					
					array (
						'name'							=> 'wpce_product_validator_error_message',
						'label'							=> __( 'Error Message', 'wpce' ),
						'type'							=> 'text',
						'class'							=> 'large-text',
						'desc'							=> __( 'This message will show just below the validator if user selected terms are not associated to current product.', 'wpce' ),
					),
				),
				
				'show_searched_terms_with_order'		=> array (
					array (
						'name'							=> 'wpce_show_user_searched_terms_with_order',
						'label'							=> __( 'Enable', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'This option allows you to display user selected terms against each ordering / ordered product on WooCommerce pages ( EG: Cart / Checkout / Order Details / Email Notifications ).', 'wpce' )
					),
					
					/*array (
						'name'							=> 'wpce_save_user_searched_terms_with_order',
						'label'							=> __( 'Save User Searched Terms', 'wpce' ),
						'type'							=> 'checkbox',
						'desc'							=> __( 'This option will save user searched terms through <strong>Search Form</strong> or <strong>Product Validator</strong> to WooCommerce database along with ordered products.', 'wpce' )
					),*/
					
					/*array (
						'name'							=> 'wpce_show_user_searched_terms_on',
						'label'							=> __( 'Enable on ', 'wpce' ),
						'type'							=> 'checkbox_group',
						'opts'							=> array (
							'cart'						=> __( 'Cart', 'wpce' ),
							'checkout'					=> __( 'Checkout', 'wpce' ),
							'user_order_details'		=> __( 'Frontend Order Detail Pages ( Thank You, My Account -> Orders )', 'wpce' ),
							'admin_order_details'		=> __( 'Backend Order Detail Pages ( View Order )', 'wpce' ),
							'email_templates'			=> __( 'Email Notifications', 'wpce' ),
						),
						'desc'							=> __( 'This option allows you to display user selected terms against each product on WooCommerce pages ( EG: Cart / Checkout / Order Details ).', 'wpce' )
					),*/
				),
				
				/* 'style'								=> array (
					array (
						'label'							=> __( 'General Options:', 'wpce' ),
						'type'							=> 'heading'
					),
					
					array (
						'name'							=> 'wpce_border_colour',
						'label'							=> __( 'Border Colour', 'wpce' ),
						'type'							=> 'colour',
						'default'						=> '#c7c7c7',
					),
					
					array (
						'name'							=> 'wpce_keyword_font_colour',
						'label'							=> __( 'Keyword Font Colour', 'wpce' ),
						'type'							=> 'colour',
						'default'						=> '#333333'
					),
				) */
			);
		
			self::$settings = apply_filters( 'wpce_settings', $options );
		}
		
		if ( $type != '' ) {
			return self::$settings[ $type ];
		} else {
			return self::$settings;
		}
	}
	
	/**
	 * Get Categories
	 */
	public static function get_categories ( $parent = 0, $level = 0 ) {
		$terms = get_categories( array (
			'taxonomy'		=> 'product_cat',
			'hide_empty'	=> false,
			'orderby'		=> 'name',
			'order'			=> 'ASC',
			'parent'		=> $parent
		) );
		
		if ( ! empty ( $terms ) ) {
			$level = $level + 1;
			$categories = array ();
			
			foreach ( $terms as $term ) {
				$categories[ $term->term_id ] = str_pad( '', $level, '-' ) . $term->name;
				$child_categories = self::get_categories( $term->term_id, $level );
				if ( ! empty ( $child_categories ) ) {
					$categories = $categories + $child_categories;
				}
			}
			
			return $categories;
		}
	}
	
	/**
	 * Post List Column Headings
	 */
	public static function wpce_column_headings ( $columns ) {
		unset( $columns );
		
		$columns = array (
			'cb'		=> '<input type="checkbox" />',
			'title'		=> __( 'Title', 'wpce' ),
			'levels'	=> __( 'Levels', 'wpce' ),
			'shortcode'	=> __( 'Shortcode', 'wpce' ),
			'date'		=> __( 'Date', 'wpce' )
		);
		
		return $columns;
	}
	
	/**
	 * Post List Column Values
	 */
	public static function wpce_column_values ( $column, $post_id ) {
		switch ( $column ) {
			case 'levels' :
				$levels = wpce_get_levels ( $post_id );
				if ( ! empty ( $levels ) ) {
					$levels_title = array ();
					foreach ( $levels as $level ) {
						$levels_title[] = $level['title'];
					}
					
					echo implode ( ' / ' , $levels_title );
				}
			break;
			
			case 'shortcode' :
				echo '[wpce-filter finder="' . $post_id . '"]';
			break;
		}
	}
	
	/**
	 * Clicking on Count on WPCE Post Type Listing
	 * Filter Products accordingly
	 */
	public static function count_filter ( $query ) {
		if ( is_admin () && $query->is_main_query () ) {
			$screen			= get_current_screen ();
			$screen_id		= $screen ? $screen->id : '';
			
			if ( $screen_id == 'edit-product' ) {
				if ( isset ( $_REQUEST['wpce_id'] ) ) {
					$wpce_id = absint ( $_REQUEST['wpce_id'] );
					if ( $wpce_id > 0 ) {
						$product_ids = wpce_get_term_relationships ( $wpce_id );
						if ( empty ( $product_ids ) ) {
							$product_ids = array ( -1 );
						}
						
						$query->set ( 'post__in', $product_ids );
					}
				}
			}
		}
	}
	
	/**
	 * Add WPCE to WooCommerce Screen IDs
	 * for JS Libraries Support eg: Products Suggestion: wc-product-search
	 */
	public static function add_screen_id ( $screen_ids ) {
		$screen			= get_current_screen ();
		$screen_id		= $screen ? $screen->id : '';
		
		if ( $screen_id == 'wpce' ) {
			$screen_ids[] = 'wpce';
		}
		
		return $screen_ids;
	}
	
	/**
	 * Duplicate a Product, Duplicate its Terms alsoDuplicate Product Terms on Duplicate a Product
	 */
	public static function duplicate_product_terms ( $duplicate, $product ) {
		if ( empty ( $product ) ) {
			return;
		}

		if ( empty ( $duplicate ) ) {
			return;
		}
		
		$finders = wpce_get_finders ();
		
		if ( ! empty ( $finders ) ) {
			foreach ( $finders as $finder ) {
				// Universal Product?
				$universal_product_ids = get_post_meta ( $finder->ID, 'wpce_universal_products', true );
				
				if ( ! empty ( $universal_product_ids ) && in_array ( $product->get_id (), $universal_product_ids ) ) {
					$universal_product_ids[] = $duplicate->get_id ();
					update_post_meta ( $finder->ID, 'wpce_universal_products', $universal_product_ids );
				}
				
				// WPCE Terms
				$product_terms = wpce_get_product_term_relationships ( $finder->ID, $product->get_id (), array ( 'fields' => 'term_id' ) );
				
				if ( ! empty ( $product_terms ) ) {
					wpce_create_term_relationship ( $product_terms, $duplicate->get_id () );
				}
			}
		}
	}
}

new WPCE_Admin_Post_Types ();