<?php defined ( 'ABSPATH' ) || exit; ?>

<form class="wc-progress-form-content woocommerce-importer" enctype="multipart/form-data" method="post">
	<header>
		<h2><?php esc_html_e( 'Import terms from a CSV file', 'wpce' ); ?></h2>
		<p><?php esc_html_e( 'This tool allows you to import terms to your store from a CSV file.', 'wpce' ); ?></p>
	</header>
	
	<section>
		<table class="form-table woocommerce-importer-options">
			<tbody>
				<tr>
					<th scope="row">
						<label for="upload">
							<?php esc_html_e( 'Choose a CSV file from your computer:', 'wpce' ); ?>
						</label>
					</th>
					
					<td>
						<?php if ( ! empty ( $upload_dir['error'] ) ) { ?>
							<div class="inline error">
								<p><?php esc_html_e( 'Before you can upload your import file, you will need to fix the following error:', 'wpce' ); ?></p>
								<p><strong><?php echo esc_html( $upload_dir['error'] ); ?></strong></p>
							</div>
						<?php } else { ?>
							<input type="file" id="upload" name="import" size="25" />
							<input type="hidden" name="action" value="save" />
							<input type="hidden" name="max_file_size" value="<?php echo esc_attr( $bytes ); ?>" />
							<br/><small><?php printf ( esc_html__( 'Maximum size: %s', 'wpce' ), esc_html( $size ) ); ?></small>
						<?php } ?>
					</td>
				</tr>
				
				<tr>
					<th><label for="woocommerce-importer-delete-existing"><?php esc_html_e( 'Delete existing terms', 'wpce' ); ?></label><br/></th>
					<td>
						<input type="hidden" name="delete_existing" value="0" />
						<input type="checkbox" id="woocommerce-importer-delete-existing" name="delete_existing" value="1" />
						<label for="woocommerce-importer-delete-existing"><?php esc_html_e( 'All the existing terms for current finder will be deleted before importing new terms.', 'wpce' ); ?></label>
					</td>
				</tr>
				
				<tr class="woocommerce-importer-advanced hidden">
					<th>
						<label for="woocommerce-importer-file-url"><?php esc_html_e( 'Alternatively, enter the path to a CSV file on your server:', 'wpce' ); ?></label>
					</th>
					<td>
						<label for="woocommerce-importer-file-url" class="woocommerce-importer-file-url-field-wrapper">
							<code><?php echo esc_html( ABSPATH ) . ' '; ?></code><input type="text" id="woocommerce-importer-file-url" name="file_url" />
						</label>
					</td>
				</tr>
				
				<tr class="woocommerce-importer-advanced hidden">
					<th><label><?php esc_html_e( 'CSV Delimiter', 'wpce' ); ?></label><br/></th>
					<td><input type="text" name="delimiter" placeholder="," size="2" /></td>
				</tr>
			</tbody>
		</table>
	</section>
	
	<script type="text/javascript">
		jQuery(function($) {
			$( '.woocommerce-importer-toggle-advanced-options' ).on( 'click', function() {
				var elements = $( '.woocommerce-importer-advanced' );
				if ( elements.is( '.hidden' ) ) {
					elements.removeClass( 'hidden' );
					$( this ).text( $( this ).data( 'hidetext' ) );
				} else {
					elements.addClass( 'hidden' );
					$( this ).text( $( this ).data( 'showtext' ) );
				}
				return false;
			} );
		});
	</script>
	
	<div class="wc-actions">
		<a href="#" class="woocommerce-importer-toggle-advanced-options" data-hidetext="<?php esc_html_e( 'Hide advanced options', 'wpce' ); ?>" data-showtext="<?php esc_html_e( 'Hide advanced options', 'wpce' ); ?>"><?php esc_html_e( 'Show advanced options', 'wpce' ); ?></a>
		
		<button type="submit" class="button button-primary button-next" value="<?php esc_attr_e( 'Continue', 'wpce' ); ?>" name="save_step"><?php esc_html_e( 'Continue', 'wpce' ); ?></button>
		<?php wp_nonce_field ( 'wpce-csv-importer' ); ?>
	</div>
</form>
