<?php defined ( 'ABSPATH' ) || exit; ?>

<div class="wrap woocommerce">
	<?php if ( $this->finder_id ) { ?>
		<h1 class="wp-heading-inline"><?php printf ( __( '%s - Import Terms', 'wpce' ), $finder_title ); ?></h1>
		<a href="edit.php?post_type=<?php echo $post_type; ?>&page=wpce_manage_terms&finder_id=<?php echo $finder_id; ?>" class="page-title-action"><?php _e( 'Manage Terms', 'wpce' ); ?></a>
		<hr class="wp-header-end" />
		
		<div class="woocommerce-progress-form-wrapper">
	<?php } else { ?>
		<h1><?php _e( 'WPCE - Import Terms', 'wpce' ); ?></h1>
	<?php } ?>