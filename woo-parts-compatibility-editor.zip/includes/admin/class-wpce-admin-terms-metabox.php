<?php
/**
 * Terms Selection Metabox on Product Edit Screen
 */
 
defined ( 'ABSPATH' ) || exit;

class WPCE_Admin_Terms_Metabox {

	/**
	 * Constructor
	 */
	public function __construct () {
		add_action ( 'add_meta_boxes', array ( __CLASS__, 'add_terms_meta_box' ) );
		add_action ( 'save_post', array ( __CLASS__, 'save_terms_meta_box' ) );
	}
	
	/**
	 * Terms Metabox
	 */
	public static function add_terms_meta_box () {
		$finders = wpce_get_finders ();
		if ( ! empty ( $finders ) ) {
			foreach ( $finders as $finder ) {
				add_meta_box ( 'wpce_finder_' . $finder->ID, sprintf ( __( 'WPCE Terms - %s', 'wpce' ), $finder->post_title ), array ( __CLASS__, 'terms_meta_box' ), 'product', 'normal', 'high', array ( 'finder' => $finder ) );
			}
		}
	}
	
	/**
	 * Terms Metabox Callback
	 */
	public static function terms_meta_box ( $post, $callback_args ) {
		$finder = isset ( $callback_args['args']['finder'] ) ? $callback_args['args']['finder'] : '';
		if ( ! $finder ) {
			return;
		}
		
		wp_nonce_field ( 'wpce_metabox', 'wpce_metabox_nonce' );
		
		// Is Universal?
		$_universal = false;
		if ( ! empty( $post ) && isset ( $post->ID ) ) {
			$universal_products = get_post_meta ( $finder->ID, 'wpce_universal_products', true );
			
			if ( ! empty( $universal_products ) && in_array ( $post->ID, $universal_products ) ) {
				$_universal = true;
			}
		}
		
		?><div class="wpce-tables" data-finder-id="<?php echo $finder->ID; ?>">
			<table class="form-table">
				<tbody>
					<tr>
						<td>
							<label for="wpce_<?php echo $finder->ID; ?>_universal"><?php _e( 'Universal Product?', 'wpce' ); ?></label>
							
							&nbsp;&nbsp;&nbsp;
							
							<input type="checkbox" name="wpce[<?php echo $finder->ID; ?>][universal]" id="wpce_<?php echo $finder->ID; ?>_universal" class="wpce-universal" value="1" <?php checked ( $_universal, true ); ?> />
							
							<?php echo wc_help_tip ( __( 'Enable this to make product universal for all terms rather you manually associate all terms to this product.', 'wpce' ) ); ?>
						</td>
						
						<td class="terms-list-actions" align="right">
							<a href="javascript:" class="button button-primary remove-all-rows"><?php _e( 'Delete All Rows', 'wpce' ); ?></a>
							
							<a href="javascript:" class="button button-primary add-row"><?php _e( 'Add New Row', 'wpce' ); ?></a>
						</td>
					</tr>
				</tbody>
			</table>
			
			<?php
				// Product Terms Rows
				$product_terms_default	= array (
					array (
						'term_id'			=> -1,
						'title'				=> '',
						'parent_id'			=> ''
					)
				);
				
				$product_terms = wpce_get_product_term_relationships_hierarchy_rows ( $finder->ID, $post->ID );
				
				if ( empty ( $product_terms ) ) {
					$product_terms = array ();
				}
				
				$product_terms[] = $product_terms_default;
				
				// Product Terms Rows List
				$levels = wpce_get_levels ( $finder->ID );
				if ( ! empty ( $levels ) ) {
					?><div class="terms-list-table">
						<table class="form-table">
							<thead>
								<tr>
									<?php foreach ( $levels as $level ) { ?>
										<td><strong><?php echo $level['title']; ?></strong></td>
									<?php } ?>
									
									<td class="actions"><span class="dashicons dashicons-no">&nbsp;</span></td>
								</tr>
							</thead>
							
							<tbody>
								<?php foreach ( $product_terms as $product_term ) { ?>
									<?php $parent_id = 0; ?>
									
									<tr>
										<?php foreach ( $levels as $key => $level ) { ?>
											<td>
												<?php
													$multiple		= false;
													if ( isset ( $product_term[0] ) && $product_term[0]['term_id'] == -1 && $key == ( count ( $levels ) - 1 ) ) {
														$multiple	= true;
													}
												?>
												
												<select name="wpce[<?php echo $finder->ID; ?>][terms][]" data-level="<?php echo $key; ?>" <?php echo $multiple ? 'multiple': ''; ?>>
													<?php
														$term_id = isset ( $product_term[ $key ] ) ? $product_term[ $key ]['term_id'] : '';
														
														if ( apply_filters ( 'wpce_terms_metabox_load_selected_terms', true ) && isset ( $product_term[0] ) && $product_term[0]['term_id'] > 0 ) {
															if ( isset ( $product_term[ $key ] ) && $product_term[ $key ]['term_id'] > 0 ) {
																echo '<option value="' . $product_term[ $key ]['term_id'] . '" selected>' . $product_term[ $key ]['title'] . '</option>';
															} else {
																echo '<option value="">' . __( '-- Select --', 'wpce' ) . '</option>';
															}
														} else {
															echo '<option value="">' . __( '-- Select --', 'wpce' ) . '</option>';
															wpce_get_terms_options ( $finder->ID, $parent_id, array ( 'selected' => $term_id, 'show_empty' => true, 'order' => $level['order'] ) );
														}
														
														$parent_id = $term_id;
													?>
												</select>
											</td>
										<?php } ?>
										
										<td class="actions">
										
											<a href="javascript:" class="remove-row dashicons dashicons-no"><?php _e( 'Delete', 'wpce' ); ?></a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div><?php
				}
			?>
		</div><?php
	}
	
	/**
	 * Save Terms Metabox
	 */
	public static function save_terms_meta_box ( $post_id ) {
		
		if ( defined ( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		
		if ( wp_is_post_revision ( $post_id ) ) return;

		if( ! isset ( $_POST['wpce_metabox_nonce'] ) || ! wp_verify_nonce ( $_POST['wpce_metabox_nonce'], 'wpce_metabox' ) ) return;
		
		if ( isset ( $_POST['wpce'] ) && ! empty ( $_POST['wpce'] ) ) {
			foreach ( $_POST['wpce'] as $finder_id => $wpce ) {
				
				// Universal?
				$universal_products = get_post_meta ( $finder_id, 'wpce_universal_products', true );
				
				if ( isset ( $wpce['universal'] ) ) {
					if ( empty ( $universal_products ) ) {
						$universal_products		= array ( $post_id );
					} else if ( ! in_array ( $post_id, $universal_products ) ) {
						$universal_products[]	= $post_id;
					}
				} else {
					if ( ! empty ( $universal_products ) && ( $key = array_search ( $post_id, $universal_products ) ) !== false ) {
						unset ( $universal_products[ $key ] );
					}
				}
				
				update_post_meta ( $finder_id, 'wpce_universal_products', $universal_products );
				
				// Associate Terms to Products
				if ( isset ( $wpce['terms'] ) ) {
					
					$terms = $wpce['terms'];
					if ( ! empty ( $terms ) ) {
						$terms = array_filter ( $terms );
					}
					
					$product_terms = wpce_get_product_term_relationships ( $finder_id, $post_id, array ( 'fields' => 'term_id' ) );
					
					$term_relationships_to_remove	= array ();
					$term_relationships_to_add		= array ();
					
					if ( ! empty ( $terms ) && ! empty ( $product_terms ) ) {
						$term_relationships_to_remove = array_diff ( $product_terms, $terms );
						$term_relationships_to_add = array_diff ( $terms, $product_terms );
					} else if ( ! empty ( $terms ) ) {
						$term_relationships_to_add = $terms;
					} else if ( ! empty ( $product_terms ) ) {
						$term_relationships_to_remove = $product_terms;
					}
					
					if ( ! empty ( $term_relationships_to_remove ) ) {
						wpce_delete_term_relationship ( $term_relationships_to_remove, $post_id );
					}
					
					if ( ! empty ( $term_relationships_to_add ) ) {
						wpce_create_term_relationship ( $term_relationships_to_add, $post_id );
					}
				}
			}
		}
	}
}

new WPCE_Admin_Terms_Metabox ();