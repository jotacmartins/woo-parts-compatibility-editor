<?php
/**
 * Custom Tab
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Orders {
	
	/**
	 * Constructor
	 */
	public function __construct () {
		add_action ( 'init', array ( __CLASS__, 'show_user_searched_terms' ) );
	}
	
	/**
	 * Show User Selected Terms Callback
	 */
	public static function show_user_searched_terms () {
		add_filter ( 'woocommerce_add_cart_item_data', array ( __CLASS__, 'add_terms_to_woo_session' ), 1, 2 );
		add_filter ( 'woocommerce_get_cart_item_from_session', array ( __CLASS__, 'move_terms_from_woo_session_to_cart_object' ), 1, 3 );
		add_filter ( 'woocommerce_cart_item_name', array ( __CLASS__, 'display_terms_from_cart_object' ), 99, 2 );
		add_filter ( 'woocommerce_order_item_name', array ( __CLASS__, 'display_terms_from_cart_object' ), 99, 2 );
		add_action ( 'woocommerce_new_order_item', array ( __CLASS__, 'add_terms_from_cart_object_to_orders_table' ), 1, 3 );
		//add_action ( 'woocommerce_before_cart_item_quantity_zero', array ( __CLASS__, 'remove_terms_from_cart_object' ), 1, 1 );
		add_action ( 'woocommerce_after_order_itemmeta', array ( __CLASS__, 'display_terms_in_order_details' ), 1, 3 );
	}

	/**
	 * Add "Product Validator Terms" OR "Remembered Search Terms" to WooCommerce Session
	 */
	public static function add_terms_to_woo_session ( $cart_item_data, $product_id ) {
		$finders	= wpce_get_finders ();

		if ( ! empty ( $finders ) ) {
			foreach ( $finders as $finder ) {
				$show_user_searched_terms_with_order	= get_post_meta ( $finder->ID, 'wpce_show_user_searched_terms_with_order', true );
				
				if ( $show_user_searched_terms_with_order == 'yes' ) {
					if ( isset ( $_POST['wpce_product_validator'] ) && ! empty ( $_POST['wpce_product_validator'] ) && isset ( $_POST['wpce_product_validator'][ $finder->ID ] ) ) {
						$term_id = $_POST['wpce_product_validator'][ $finder->ID ];
						
						if ( $term_id ) {
							$term_ancestors	= self::get_term_ancestor_names ( $term_id, $finder->ID );
								
							if ( ! empty ( $term_ancestors ) ) {
								$cart_item_data['wpce'][ $finder->ID ] = $term_ancestors;
							}
						}
					} else {
						$remember_search	= get_post_meta ( $finder->ID, 'wpce_remember_search', true );
						
						if ( $remember_search == 'yes' ) {
							$term_id		= wpce_get_cookie ( $finder->ID, 'search_term_id' );
							
							if ( ! empty ( $term_id ) ) {
								$product_ids	= wpce_get_term_relationships_including_universal ( $term_id, $finder->ID );
								
								if ( ! empty ( $product_ids ) && in_array ( $product_id, $product_ids ) ) {
									$term_ancestors	= self::get_term_ancestor_names ( $term_id, $finder->ID );
									
									if ( ! empty ( $term_ancestors ) ) {
										$cart_item_data['wpce'][ $finder->ID ] = $term_ancestors;
									}
								}
							}
						}
					}
				}
			}
		}
		
		return $cart_item_data;
	}
	
	/**
	 * Move Terms from WooCommerce Session to Cart Object
	 */
	public static function move_terms_from_woo_session_to_cart_object ( $item, $values, $key ) {
		if ( array_key_exists ( 'wpce', $values ) ) {
			$item[ 'wpce' ] = $values['wpce'];
		}
		
		return $item;
	}
	
	/**
	 * Display Terms from Cart Object
	 */
	public static function display_terms_from_cart_object ( $product_name, $item ) {
		if ( isset ( $item['wpce'] ) && ! empty ( $item['wpce'] ) ) {
			$product_name			.= '</a>';
			
			foreach ( $item['wpce'] as $finder_id => $terms ) {
				$terms_html			= '';
				
				if ( ! empty ( $terms ) ) {
					$terms_html		.= '<dl class="variation wpce-variation"><table>';
						
						foreach ( $terms as $level => $term ) {
							$terms_html	.= '
								<tr>
									<th>' . $level . ': </th>
									<td>' . $term . '</td>
								</tr>
							';
						}
						
					$terms_html		.= '</table></dl>';
					
					$product_name	.= apply_filters ( 'wpce_cart_terms_html', $terms_html, $finder_id, $terms );
				}
			}
		}
		
		return $product_name;
	}
	
	/**
	 * Save Terms from Cart Object to Orders Database
	 */
	public static function add_terms_from_cart_object_to_orders_table ( $item_id, $item, $order_id ) {
		if ( empty ( $item ) ) {
			return;
		}
		
		if ( ! isset ( $item->legacy_values ) || empty ( $item->legacy_values ) || ! isset ( $item->legacy_values['wpce'] ) ) {
			return;
		}
		
		wc_add_order_item_meta ( $item_id, 'wpce', $item->legacy_values['wpce'] );
	}
	
	/**
	 * Remove Terms from Cart Object on Quantity Zero
	 */
	public static function remove_terms_from_cart_object ( $cart_item_key ) {
		global $woocommerce;
		
		$cart = $woocommerce->cart->get_cart ();
		if ( ! empty ( $cart ) && isset ( $cart[ $cart_item_key ] ) && isset ( $cart[ $cart_item_key ]['wpce'] ) ) {
			unset ( $woocommerce->cart->cart_contents[ $cart_item_key ] );
		}
	}
	
	/**
	 * Remove Terms from Cart Object on Quantity Zero
	 */
	public static function display_terms_in_order_details ( $item_id, $item, $product ) {
		$wpce = wc_get_order_item_meta ( $item_id, 'wpce' );
		
		if ( ! empty ( $wpce ) ) {
			foreach ( $wpce as $finder_id => $terms ) {
				$terms_html				= '';
				
				if ( ! empty ( $terms ) ) {
					$terms_html			.= '<dl class="variation wpce-variation"><table>';
						
						foreach ( $terms as $level => $term ) {
							$terms_html	.= '
								<tr>
									<th>' . $level . ': </th>
									<td>' . $term . '</td>
								</tr>
							';
						}
						
					$terms_html		.= '</table></dl>';
					
					echo apply_filters ( 'wpce_cart_terms_html', $terms_html, $finder_id, $terms );
				}
			}
		}
	}
	
	/**
	 * Get Term Parent Level Names Hierarchy
	 */
	public static function get_term_ancestor_names ( $term_id = '', $finder_id = '' ) {
		if ( empty ( $term_id ) ) {
			return;
		}
		
		if ( empty ( $finder_id ) ) {
			return;
		}
		
		$term_ancestors				= wpce_get_term_ancestors ( $term_id );
		if ( empty ( $term_ancestors ) ) {
			return;
		}
		
		$term_ancestor_names		= array ();
		$levels						= wpce_get_levels ( $finder_id );
		$term_ancestors				= array_reverse ( $term_ancestors );
		
		foreach ( $term_ancestors as $key => $term_ancestor ) {
			$term_ancestor_names[ $levels[ $key ]['title'] ] = $term_ancestor->title;
		}
		
		return $term_ancestor_names;
	}
}

$GLOBALS['wpce_orders'] = new WPCE_Orders ();

/*echo apply_filters( 'woocommerce_checkout_cart_item_quantity', ' <strong class="product-quantity">' . sprintf( '&times; %s', $cart_item['quantity'] ) . '</strong>', $cart_item, $cart_item_key ); ?>

<?php
	echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key ); // PHPCS: XSS ok.
?>

echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) . '&nbsp;' );

echo apply_filters( 'woocommerce_order_item_name', $product_permalink ? sprintf( '<a href="%s">%s</a>', $product_permalink, $item->get_name() ) : $item->get_name(), $item, $is_visible ); 

https://wisdmlabs.com/blog/add-custom-data-woocommerce-order/
http://thewebfosters.com/adding-custom-data-woocommerce-order-add-cart/
*/