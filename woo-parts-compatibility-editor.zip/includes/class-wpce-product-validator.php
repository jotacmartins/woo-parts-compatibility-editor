<?php
/**
 * Custom Tab
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Product_Validator {
	
	/**
	 * Constructor
	 */
	public function __construct () {
		add_action ( 'woocommerce_before_single_product', array ( __CLASS__, 'product_validator' ) );
	}

	/**
	 * Terms Selector on Product Details Page
	 */
	public static function product_validator () {
		if ( is_product () && apply_filters ( 'wpce_product_validator', true ) ) {
			global $post;
			$product_id	= $post->ID;
			
			$finders	= wpce_get_finders ();
			if ( ! empty ( $finders ) ) {
				foreach ( $finders as $finder ) {
					$product_validator				= get_post_meta ( $finder->ID, 'wpce_product_validator', true );
					
					if ( $product_validator == 'yes' ) {
						$is_validator_on			= false;
						
						$disable_on_universal_products	= get_post_meta ( $finder->ID, 'wpce_product_validator_disable_on_universal_products', true );
						$universal_product_ids			= wpce_get_finder_universal_relationships ( $finder->ID );
						
						if ( $disable_on_universal_products == 'yes' && ! empty ( $universal_product_ids ) && in_array ( $product_id, $universal_product_ids ) ) {
							//$is_validator_on	= false;
						} else {
							$categories					= wp_get_object_terms ( $product_id, 'product_cat', array ( 'fields' => 'ids' ) );
							$categories_to_include		= get_post_meta ( $finder->ID, 'wpce_categories_to_include', true );
							$categories_to_exclude		= get_post_meta ( $finder->ID, 'wpce_categories_to_exclude', true );
							
							if ( ! empty ( $categories_to_exclude ) && ! empty ( $categories ) && ! empty ( array_intersect ( $categories_to_exclude, $categories ) ) ) {
								//$is_validator_on	= false;
							} else if ( ! empty ( $categories_to_include ) ) {
								if ( ! empty ( $categories ) && ! empty ( array_intersect ( $categories_to_include, $categories ) ) ) {
									$is_validator_on	= true;
								}
							} else {
								$is_validator_on		= true;
							}
						}
						
						if ( $is_validator_on ) {
							$heading					= get_post_meta ( $finder->ID, 'wpce_product_validator_heading', true );
							
							wpce_filter_widget_template ( array (
								'product_validator'		=> true,
								'heading' => '<i class="klbth-icon-car-fix-sign style="font-size: 1.6em;"></i> ' . $heading,
								'finder_id'				=> $finder->ID,
								'finder'				=> $finder,
								'layout'				=> 'h'
							) );
						}
					}
				}
			}
		}
	}
}

$GLOBALS['wpce_product_validator'] = new WPCE_Product_Validator ();