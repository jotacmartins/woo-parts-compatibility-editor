<?php
/**
 * Ajax Request
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Ajax {

	/**
	 * Constructor
	 */
	public function __construct () {
		$ajax_events = array (
			'get_terms'						=> true,
			'reset_search'					=> true,
			'validate_product'				=> true,
			'get_product_tab_terms'			=> true,
			'save_user_search'				=> false,
			'delete_user_search_history'	=> true,
			'clear_user_search_history'		=> true,
			'delete_user_saved_search'		=> false,
			'clear_user_saved_searches'		=> false,
			'save_term'						=> false,
			'refresh_terms_count'			=> false
		);

		foreach ( $ajax_events as $ajax_event => $nopriv ) {
			add_action ( 'wp_ajax_wpce_' . $ajax_event, array ( __CLASS__, $ajax_event ) );

			if ( $nopriv ) {
				add_action ( 'wp_ajax_nopriv_wpce_' . $ajax_event, array( __CLASS__, $ajax_event ) );
			}
		}
	}
	
	/**
	 * Get Terms
	 */
	public static function get_terms () {
		$_REQUEST = array_map ( 'trim', $_REQUEST );
		
		$parent_id		= 0;
		if ( isset ( $_REQUEST['parent_id'] ) ) {
			$parent_id	= absint ( $_REQUEST['parent_id'] );
		}
		
		if ( $parent_id > 0 ) {
			$finder_id		= 0;
			if ( isset ( $_REQUEST['finder_id'] ) ) {
				$finder_id	= absint ( $_REQUEST['finder_id'] );
			}
			
			$level			= 0;
			if ( isset ( $_REQUEST['level'] ) ) {
				$level		= absint ( $_REQUEST['level'] );
			}
			$level			= $level + 1;
			
			$panel			= 'front';
			if ( isset ( $_REQUEST['panel'] ) ) {
				$panel		= $_REQUEST['panel'];
			}
			
			if ( $panel == 'admin' ) {
				$show_empty	= true;
			} else {
				$show_empty		= get_post_meta ( $finder_id, 'wpce_show_empty_terms', true );
				if ( $show_empty == 'yes' ) {
					$show_empty	= true;
				} else {
					$show_empty	= false;
				}
			}
			
			$order			= 'asc';
			$levels			= wpce_get_levels ( $finder_id );
			if ( ! empty ( $levels ) && isset ( $levels[ $level ] ) ) {
				$order		= $levels[ $level ]['order'];
			}
			
			wpce_get_terms_options ( '', $parent_id, array ( 'show_empty' => $show_empty, 'order' => $order ) );
		}
		
		die ();
	}
	
	/**
	 * Reset Search
	 */
	public static function reset_search () {
		$_REQUEST				= array_map ( 'trim', $_REQUEST );
		
		$finder_id				= 0;
		if ( isset ( $_REQUEST['finder_id'] ) ) {
			$finder_id			= absint ( $_REQUEST['finder_id'] );
		}
		
		if ( $finder_id > 0 ) {
			wpce_set_cookie ( $finder_id, 'search_term_id', '' );
		}
		
		die ();
	}
	
	/**
	 * Get Terms
	 */
	public static function validate_product () {
		$_REQUEST				= array_map ( 'trim', $_REQUEST );
		
		$product_id				= 0;
		if ( isset ( $_REQUEST['product_id'] ) ) {
			$product_id			= absint ( $_REQUEST['product_id'] );
		}
		
		$term_id				= 0;
		if ( isset ( $_REQUEST['term_id'] ) ) {
			$term_id			= absint ( $_REQUEST['term_id'] );
		}
		
		$finder_id				= 0;
		if ( isset ( $_REQUEST['finder_id'] ) ) {
			$finder_id			= absint ( $_REQUEST['finder_id'] );
		}
		
		if ( $product_id > 0 && $term_id > 0 && $finder_id > 0 ) {
			$error_message		= get_post_meta ( $finder_id, 'wpce_product_validator_error_message', true );
			$success_message	= get_post_meta ( $finder_id, 'wpce_product_validator_success_message', true );
			
			$return				= array (
				'success'		=> false,
				'message'		=> $error_message
			);
			
			// Check if Universl Product
			$universal_product_ids		= wpce_get_finder_universal_relationships ( $finder_id );
			if ( ! empty ( $universal_product_ids ) && in_array ( $product_id, $universal_product_ids ) ) {
				$return = array (
					'success'		=> true,
					'message'		=> $success_message
				);
			} else {
				// Check against Finder Terms
				$product_ids		= wpce_get_term_relationships ( $term_id );
				
				if ( ! empty ( $product_ids ) && in_array ( $product_id, $product_ids ) ) {
					$return = array (
						'success'		=> true,
						'message'		=> $success_message
					);
				}
			}
			
			echo json_encode ( $return );
		}
		
		die ();
	}
	
	/**
	 * Get Product Tab Terms
	 */
	public static function get_product_tab_terms () {
		wpce_get_product_tab_terms_list_table_rows ( $_REQUEST );
		die ();
	}
	
	/**
	 * Move User Search from Search History to Saved Searches
	 */
	public static function save_user_search () {
		$_REQUEST				= array_map ( 'trim', $_REQUEST );
		
		$search_term_id				= 0;
		if ( isset ( $_REQUEST['search_term_id'] ) ) {
			$search_term_id		= absint ( $_REQUEST['search_term_id'] );
		}
		
		$finder_id				= 0;
		if ( isset ( $_REQUEST['finder_id'] ) ) {
			$finder_id			= absint ( $_REQUEST['finder_id'] );
		}
		
		if ( $search_term_id > 0 && $finder_id > 0 ) {
			wpce_save_user_saved_search ( $finder_id, $search_term_id );
			wpce_user_searches_widget_template ( array ( 'finder_id' => $finder_id ) );
		}
		
		die ();
	}
	
	/**
	 * Delete User Search from Search History
	 */
	public static function delete_user_search_history () {
		$_REQUEST				= array_map ( 'trim', $_REQUEST );
		
		$search_term_id				= 0;
		if ( isset ( $_REQUEST['search_term_id'] ) ) {
			$search_term_id		= absint ( $_REQUEST['search_term_id'] );
		}
		
		$finder_id				= 0;
		if ( isset ( $_REQUEST['finder_id'] ) ) {
			$finder_id			= absint ( $_REQUEST['finder_id'] );
		}
		
		if ( $search_term_id > 0 && $finder_id > 0 ) {
			wpce_delete_user_search_history ( $finder_id, $search_term_id );
			wpce_user_searches_widget_template ( array ( 'finder_id' => $finder_id ) );
		}
		
		die ();
	}
	
	/**
	 * Clear User Search History
	 */
	public static function clear_user_search_history () {
		$_REQUEST				= array_map ( 'trim', $_REQUEST );
		
		$finder_id				= 0;
		if ( isset ( $_REQUEST['finder_id'] ) ) {
			$finder_id			= absint ( $_REQUEST['finder_id'] );
		}
		
		if ( $finder_id > 0 ) {
			wpce_clear_user_search_history ( $finder_id );
			wpce_user_searches_widget_template ( array ( 'finder_id' => $finder_id ) );
		}
		
		die ();
	}
	
	/**
	 * Delete User Saved Search
	 */
	public static function delete_user_saved_search () {
		$_REQUEST				= array_map ( 'trim', $_REQUEST );
		
		$search_term_id				= 0;
		if ( isset ( $_REQUEST['search_term_id'] ) ) {
			$search_term_id		= absint ( $_REQUEST['search_term_id'] );
		}
		
		$finder_id				= 0;
		if ( isset ( $_REQUEST['finder_id'] ) ) {
			$finder_id			= absint ( $_REQUEST['finder_id'] );
		}
		
		if ( $search_term_id > 0 && $finder_id > 0 ) {
			wpce_delete_user_saved_search ( $finder_id, $search_term_id );
			wpce_user_searches_widget_template ( array ( 'finder_id' => $finder_id ) );
		}
		
		die ();
	}
	
	/**
	 * Clear User Saved Searches
	 */
	public static function clear_user_saved_searches () {
		$_REQUEST				= array_map ( 'trim', $_REQUEST );
		
		$finder_id				= 0;
		if ( isset ( $_REQUEST['finder_id'] ) ) {
			$finder_id			= absint ( $_REQUEST['finder_id'] );
		}
		
		if ( $finder_id > 0 ) {
			wpce_clear_user_saved_search ( $finder_id );
			wpce_user_searches_widget_template ( array ( 'finder_id' => $finder_id ) );
		}
		
		die ();
	}
	
	/**
	 * Backend: Save Term
	 */
	public static function save_term () {
		$_REQUEST		= array_map ( 'trim', $_REQUEST );
		
		$term_id		= 0;
		if ( isset ( $_REQUEST['term_id'] ) ) {
			$term_id	= absint ( $_REQUEST['term_id'] );
		}
		
		$finder_id		= '';
		if ( isset ( $_REQUEST['finder_id'] ) ) {
			$finder_id	= absint ( $_REQUEST['finder_id'] );
		}
		
		$parent_id		= '';
		if ( isset ( $_REQUEST['parent_id'] ) ) {
			$parent_id	= absint ( $_REQUEST['parent_id'] );
		}
		
		$term_title		= '';
		if ( isset ( $_REQUEST['term_title'] ) ) {
			$term_title	= stripslashes ( $_REQUEST['term_title'] );
		}
		
		// Validation
		$error			= '';
		
		if ( $term_title == '' ) {
			$error		= __( 'A name is required for term.', 'wpce' );
		} else if ( ( $existing_term_id = wpce_term_exists ( $finder_id, $term_title, $parent_id ) ) && ( $existing_term_id != $term_id ) ) {
			$error		= __( 'A term with the name provided already exists with this parent.', 'wpce' );
		}
		
		// Proceed with Save Term
		$return = array ();
		
		if ( $error != '' ) {
			$return = array (
				'success'	=> false,
				'message'	=> $error
			);
		} else {
			if ( $term_id > 0 ) {
				wpce_update_term ( $term_id, $term_title );
				
				$return = array (
					'success'	=> true,
					'message'	=> __( 'Term has been successfully updated.', 'wpce' )
				);
			} else {
				wpce_create_term ( $finder_id, $term_title, $parent_id );
				
				$return = array (
					'success'	=> true,
					'message'	=> __( 'Term has been successfully created.', 'wpce' )
				);
			}
		}
		
		echo json_encode ( $return );
		die ();
	}

	/**
	 * Backend: Refresh Finder Terms Count
	 */
	public static function refresh_terms_count () {
		$_REQUEST = array_map ( 'trim', $_REQUEST );
		
		if ( isset ( $_REQUEST['finder_id'] ) ) {
			$finder_id = absint ( $_REQUEST['finder_id'] );
			if ( $finder_id > 0 ) {
				wpce_refresh_terms_count ( $finder_id );
				_e( 'Terms Count has been refreshed successfully.', 'wpce' );
			}
		}

		die ();
	}
}

$GLOBALS['wpce_ajax'] = new WPCE_Ajax ();