<?php
/**
 * Custom Post Types
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Post_Types {

	/**
	 * Constructor
	 */
	public function __construct () {
		add_action ( 'init', array ( __CLASS__, 'register_post_types' ) );
		//add_action ( 'admin_menu', array ( __CLASS__, 'modify_post_types_menu' ) );
		
		add_action ( 'before_delete_post', array ( __CLASS__, 'delete_finder_terms' ) );
		add_action ( 'before_delete_post', array ( __CLASS__, 'delete_product_term_relationships' ) );
	}

	/**
	 * Register Post Types
	 */
	public static function register_post_types () {
		
		// Post Type: wpce
		$labels = apply_filters ( 'wpce_post_type_wpce_labels', array (
			'name'						=> _x( 'WPCE Finders', 'post type general name', 'wpce' ),
			'singular_name'				=> _x( 'WPCE Finder', 'post type singular name', 'wpce' ),
			'menu_name'					=> _x( 'WPCE', 'admin menu', 'wpce' ),
			'name_admin_bar'			=> _x( 'WPCE Finder', 'add new on admin bar', 'wpce' ),
			'add_new'					=> _x( 'Add New Finder', 'wpce', 'wpce' ),
			'add_new_item'				=> __( 'Add New Finder', 'wpce' ),
			'new_item'					=> __( 'New Finder', 'wpce' ),
			'edit_item'					=> __( 'Edit Finder', 'wpce' ),
			'view_item'					=> __( 'View Finder', 'wpce' ),
			'all_items'					=> __( 'Manage Finders', 'wpce' ),
			'search_items'				=> __( 'Search Finders', 'wpce' ),
			'parent_item_colon'			=> __( 'Parent Finder:', 'wpce' ),
			'not_found'					=> __( 'No finders found.', 'wpce' ),
			'not_found_in_trash'		=> __( 'No finders found in Trash.', 'wpce' ),
			/* // Didn't work so updated through admin/class-wpce-admin-post-types.php file with hooks
			'item_published'			=> __( 'Finder published.', 'wpce' ),
			'item_published_privately'	=> __( 'Finder published privately.', 'wpce' ),
			'item_reverted_to_draft'	=> __( 'Finder reverted to draft.', 'wpce' ),
			'item_scheduled'			=> __( 'Finder scheduled.', 'wpce' ),
			'item_updated'				=> __( 'Finder updated.', 'wpce' ),*/
		) );
		
		$args = apply_filters ( 'wpce_post_type_wpce_args', array (
			'labels'					=> $labels,
			'description'				=> __( 'Description.', 'wpce' ),
			'menu_icon'					=> 'dashicons-search',
			'capability_type'			=> 'post',
			'rewrite'					=> false,
			'public'					=> false,
			'publicly_queryable'		=> false,
			'show_ui'					=> true,
			'show_in_nav_menus'			=> false,
			'show_in_menu'				=> true,
			'query_var'					=> false,
			'has_archive'				=> false,
			'exclude_from_search'		=> true,
			'hierarchical'				=> false,
			'menu_position'				=> 58,
			'supports'					=> array ( 'title' )
		) );

		register_post_type ( 'wpce', $args );
	}
	
	/**
	 * Modify Menu: Remove 'Add New' Sub Menu
	 */
	public static function modify_post_types_menu () {
		global $submenu;
		unset ( $submenu['edit.php?post_type=wpce'][10] );
	}
	
	/**
	 * Deleting Finder, Auto Delete Finder Terms As Well
	 */
	public static function delete_finder_terms ( $finder_id ) {
		$finder = get_post ( $finder_id );
		
		if ( ! empty ( $finder ) ) {
			if ( $finder->post_type == 'wpce' ) {
				$term_ids			= wpce_get_terms ( array (
					'fields'		=> 'term_id',
					'finder_id'		=> $finder_id
				) );
				
				if ( ! empty ( $term_ids ) ) {
					wpce_delete_terms ( $term_ids );
				}
			}
		}
	}
	
	/**
	 * Deleting Product, Auto Delete Product-Terms Relationships As Well
	 */
	public static function delete_product_term_relationships ( $product_id ) {
		$product = get_post ( $product_id );
		
		if ( ! empty ( $product ) ) {
			if ( $product->post_type == 'product' ) {
				wpce_delete_product_term_relationships ( $product_id );
			}
		}
	}
}

$GLOBALS['wpce_post_types'] = new WPCE_Post_Types ();