<?php
/**
 * Custom Tab
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Product_Tab {
	
	/**
	 * Constructor
	 */
	public function __construct () {
		add_filter ( 'woocommerce_product_tabs', array ( __CLASS__, 'register_product_tab' ) );
	}

	/**
	 * Register Product Custom Tab
	 */
	public static function register_product_tab ( $tabs ) {
		$finders = wpce_get_finders ();
		
		if ( ! empty ( $finders ) ) {
			foreach ( $finders as $finder ) {
				$tab										= get_post_meta ( $finder->ID, 'wpce_tab', true );
				
				if ( $tab == 'yes' ) {
					$tab_title								= get_post_meta ( $finder->ID, 'wpce_tab_title', true );
					
					if ( $tab_title != '' ) {
						global $post;
						$product_terms						= wpce_get_product_term_relationships ( $finder->ID, $post->ID, array ( 'parent_id' => 0, 'limit' => 1 ) );
						
						if ( ! empty ( $product_terms ) ) {
							$tab_priority					= get_post_meta ( $finder->ID, 'wpce_tab_priority', true );
							
							$tabs['wpce_' . $finder->ID]	= array (
								'title'						=> $tab_title,
								'priority'					=> $tab_priority,
								'callback'					=> array ( __CLASS__, 'product_tab_content' ),
								'callback_parameters'		=> array (
									'finder_id'				=> $finder->ID
								)
							);
						}
					}
				}
			}
		}
		
		return $tabs;
	}
	
	/**
	 * Register Product Custom Tab
	 */
	public static function product_tab_content ( $tab_name, $tab ) {
		$finder_id	= $tab['callback_parameters']['finder_id'];
		
		if ( empty ( $finder_id ) ) {
			return;
		}
		
		?><div class="wpce-product-tab">
			<?php
				do_action ( 'wpce_product_tab_before_content', $finder_id );
				
					$tab_heading		= get_post_meta ( $finder_id, 'wpce_tab_heading', true );
					if ( ! empty ( $tab_heading ) ) {
						echo apply_filters ( 'wpce_product_tab_heading_container_start', '<h2>' );
							echo $tab_heading;
						echo apply_filters ( 'wpce_product_tab_heading_container_end', '</h2>' );
					}
					
					$tab_description	= get_post_meta ( $finder_id, 'wpce_tab_description', true );
					if ( ! empty ( $tab_description ) ) {
						echo apply_filters ( 'wpce_product_tab_description_container_start', '<p>' );
							echo $tab_description;
						echo apply_filters ( 'wpce_product_tab_description_container_end', '</p>' );
					}
					
					wpce_get_product_tab_terms_list_table ( array (
						'finder_id'	=> $finder_id
					) );
				
				do_action ( 'wpce_product_tab_after_content', $finder_id );
			?>
		</div><?php
	}
}

$GLOBALS['wpce_product_tab'] = new WPCE_Product_Tab ();