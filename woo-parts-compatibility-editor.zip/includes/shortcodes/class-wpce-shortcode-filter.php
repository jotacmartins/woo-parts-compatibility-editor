<?php
/**
 * Shortcode: Filter
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Shortcode_Filter {

	/**
	 * Constructor
	 */
	public function __construct () {
		add_shortcode ( 'wpce-filter', array ( __CLASS__, 'shortcode_callback' ) );
	}
	
	/**
	 * Shortcode Callback
	 */
	public static function shortcode_callback ( $args ) {
		$args			= shortcode_atts( array (
			'finder'	=> '',
			'levels'	=> '',
			'layout'	=> 'v'
		), $args );
		extract( $args );
		
		$finder_id		= ! empty ( $args['finder'] ) ? absint ( $args['finder'] ) : '';
		if ( ! $finder_id ) {
			return;
		}
		
		$no_of_levels	= ! empty ( $args['levels'] ) ? absint ( $args['levels'] ) : '';
		$layout			= ! empty ( $args['layout'] ) ? $args['layout'] : '';
		
		ob_start ();
		
			$template_args		= array (
				'finder_id'		=> $finder_id,
				'no_of_levels'	=> $no_of_levels,
				'layout'		=> $layout
			);

			wpce_filter_widget_template ( $template_args );
		
		$content = ob_get_clean ();
		
		return $content;
	}
}

new WPCE_Shortcode_Filter ();