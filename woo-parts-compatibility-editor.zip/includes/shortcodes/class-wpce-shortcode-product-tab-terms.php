<?php
/**
 * Shortcode: Product Tab Terms List
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Shortcode_Product_Tab_Terms {

	/**
	 * Constructor
	 */
	public function __construct () {
		add_shortcode ( 'wpce-product-tab-terms', array ( __CLASS__, 'shortcode_callback' ) );
	}
	
	/**
	 * Shortcode Callback
	 */
	public static function shortcode_callback ( $args ) {
		$args			= shortcode_atts( array (
			'finder'	=> '',
			'product'	=> ''
		), $args );
		extract( $args );
		
		$finder_id		= ! empty ( $args['finder'] ) ? absint ( $args['finder'] ) : '';
		if ( ! $finder_id ) {
			return;
		}
		
		$product_id		= ! empty ( $args['product'] ) ? absint ( $args['product'] ) : '';
		if ( ! $product_id && is_product () ) {
			global $post;
			$product_id	= $post->ID;
		}
		
		if ( ! $product_id ) {
			return;
		}
		
		ob_start ();
		
			wpce_get_product_tab_terms_list_table ( array (
				'finder_id'		=> $finder_id,
				'product_id'	=> $product_id
			) );
		
		$content = ob_get_clean ();
		
		return $content;
	}
}

new WPCE_Shortcode_Product_Tab_Terms ();