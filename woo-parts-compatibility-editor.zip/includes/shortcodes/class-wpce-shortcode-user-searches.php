<?php
/**
 * Shortcode: User Searches ( History / Saved )
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Shortcode_User_Searches {

	/**
	 * Constructor
	 */
	public function __construct () {
		add_shortcode ( 'wpce-user-searches', array ( __CLASS__, 'shortcode_callback' ) );
	}
	
	/**
	 * Shortcode Callback
	 */
	public static function shortcode_callback ( $args ) {
		$args			= shortcode_atts( array (
			'finder'	=> ''
		), $args );
		extract( $args );
		
		$finder_id		= ! empty ( $args['finder'] ) ? absint ( $args['finder'] ) : '';
		if ( ! $finder_id ) {
			return;
		}
		
		ob_start ();
		
			$template_args		= array (
				'finder_id'		=> $finder_id
			);

			wpce_user_searches_widget_template ( $template_args );
		
		$content = ob_get_clean ();
		
		return $content;
	}
}

new WPCE_Shortcode_User_Searches ();