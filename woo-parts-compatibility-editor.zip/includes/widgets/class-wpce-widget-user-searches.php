<?php
/**
 * WPCE Widget: User Searches ( History / Saved )
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Widget_User_Searches extends WC_Widget {
	
	/**
	 * Constructor.
	 */
	public function __construct () {
		$this->widget_cssclass		= 'woocommerce wpce wpce-widget wpce-widget-user-searches';
		$this->widget_description	= __( "Display a list of user's most recent search history and saved searches.", 'wpce' );
		$this->widget_id			= 'wpce-widget-user-searches';
		$this->widget_name			= __( 'WPCE: User Searches', 'wpce' );
		
		$this->settings				= array (
			'title'					=> array (
				'type'				=> 'text',
				'std'				=> __( 'My Searches', 'wpce' ),
				'label'				=> __( 'Title', 'wpce' ),
			),
			
			'finder'				=> array (
				'type'				=> 'select',
				'std'				=> '',
				'label'				=> __( 'Finder', 'wpce' ),
				'options'			=> wpce_get_finders_opts (),
			)
		);

		parent::__construct ();
	}
	
	/**
	 * Widget - Output
	 */
	public function widget ( $args, $instance ) {

		if ( $this->get_cached_widget ( $args ) ) {
			return;
		}

		$finder_id		= ! empty ( $instance['finder'] ) ? absint ( $instance['finder'] ) : $this->settings['finder']['std'];
		if ( ! $finder_id ) {
			return;
		}
		
		ob_start ();
		
			$template_args		= array (
				'finder_id'		=> $finder_id
			);

			wpce_user_searches_widget_template ( $template_args );
		
		$content = ob_get_clean ();
		
		if ( ! empty ( $content ) ) {
			
			ob_start ();
			
				$this->widget_start ( $args, $instance );
				
					echo $content;
				
				$this->widget_end ( $args );

			$content = ob_get_clean ();
			
		}

		echo $content;

		$this->cache_widget ( $args, $content );
	}
}

/**
 * Register Widgets
 */
function wpce_register_user_searches_widget () {
	register_widget ( 'WPCE_Widget_User_Searches' );
}
add_action ( 'widgets_init', 'wpce_register_user_searches_widget' );