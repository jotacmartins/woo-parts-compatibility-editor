<?php
/**
 * WPCE Widget: Filter
 */

defined ( 'ABSPATH' ) || exit;

class WPCE_Widget_Filter extends WC_Widget {
	
	/**
	 * Constructor.
	 */
	public function __construct () {
		$this->widget_cssclass		= 'woocommerce wpce wpce-widget wpce-widget-filter';
		$this->widget_description	= __( 'A search form to filter products in your store.', 'wpce' );
		$this->widget_id			= 'wpce-widget-filter';
		$this->widget_name			= __( 'WPCE: Filter', 'wpce' );
		
		$this->settings				= array (
			'title'					=> array (
				'type'				=> 'text',
				'std'				=> __( 'Product Parts Finder', 'wpce' ),
				'label'				=> __( 'Title', 'wpce' ),
			),
			
			'finder'				=> array (
				'type'				=> 'select',
				'std'				=> '',
				'label'				=> __( 'Finder', 'wpce' ),
				'options'			=> wpce_get_finders_opts (),
			),
			
			'levels'				=> array (
				'type'				=> 'number',
				'step'				=> 1,
				'min'				=> 0,
				'max'				=> '',
				'std'				=> 0,
				'label'				=> sprintf ( __( 'Number of levels to show ( Enter %s or leave empty for all )', 'wpce' ), '<strong>0</strong>' ),
			),
			
			'layout'				=> array (
				'type'				=> 'select',
				'std'				=> 'v',
				'label'				=> __( 'Layout', 'wpce' ),
				'options'			=> array (
					'v'				=>	__( 'Vertical', 'wpce' ),
					'h'				=>	__( 'Horizontal', 'wpce' )
				),
			)
		);

		parent::__construct ();
	}
	
	/**
	 * Widget - Output
	 */
	public function widget ( $args, $instance ) {

		if ( $this->get_cached_widget ( $args ) ) {
			return;
		}

		$finder_id		= ! empty ( $instance['finder'] ) ? absint ( $instance['finder'] ) : $this->settings['finder']['std'];
		if ( ! $finder_id ) {
			return;
		}
		
		$no_of_levels	= ! empty ( $instance['levels'] ) ? absint ( $instance['levels'] ) : $this->settings['levels']['std'];
		$layout			= ! empty ( $instance['layout'] ) ? $instance['layout'] : $this->settings['layout']['std'];
		
		ob_start ();
		
			$template_args		= array (
				'finder_id'		=> $finder_id,
				'no_of_levels'	=> $no_of_levels,
				'layout'		=> $layout
			);

			wpce_filter_widget_template ( $template_args );
		
		$content = ob_get_clean ();
		
		if ( ! empty ( $content ) ) {
			
			ob_start ();
			
				$this->widget_start ( $args, $instance );
				
					echo $content;
				
				$this->widget_end ( $args );

			$content = ob_get_clean ();
			
		}

		echo $content;

		$this->cache_widget ( $args, $content );
	}
}

/**
 * Register Widgets
 */
function wpce_register_filter_widget () {
	register_widget ( 'WPCE_Widget_Filter' );
}
add_action ( 'widgets_init', 'wpce_register_filter_widget' );