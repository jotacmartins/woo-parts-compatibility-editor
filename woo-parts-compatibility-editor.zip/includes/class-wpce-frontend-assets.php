<?php
/**
 * Enqueue CSS/JS Files
 */
 
defined ( 'ABSPATH' ) || exit;

class WPCE_Frontend_Assets {

	/**
	 * Constructor
	 */
	public function __construct () {
		// Priority 11 so loads after WooCommerce ( For selectWoo Library )
		add_action ( 'wp_enqueue_scripts', array ( __CLASS__, 'register_assets' ), 11 );
		add_action ( 'wp_enqueue_scripts', array ( __CLASS__, 'load_assets' ), 11 );
	}

	/**
	 * Register Assets
	 */
	public static function register_assets () {
		wp_register_style ( 'wpce-main-style', WPCE_PLUGIN_URL . '/assets/css/style.css', array(), WPCE_PLUGIN_VERSION );
		wp_register_script ( 'wpce-main-script', WPCE_PLUGIN_URL . '/assets/js/scripts.js', array ( 'jquery' ), WPCE_PLUGIN_VERSION );
	}
	
	/**
	 * Enqueue Assets
	 */
	public static function load_assets () {
		// Main Scripts
		wp_enqueue_style ( 'wpce-main-style' );		
		wp_enqueue_script ( 'wpce-main-script' );
		
		// WooCommerce Scripts
		if ( wp_script_is ( 'selectWoo', 'registered' ) && wp_style_is ( 'select2', 'registered' ) ) {
			$finders	= wpce_get_finders ();
			if ( ! empty ( $finders ) ) {
				foreach ( $finders as $finder ) {
					$user_friendly_dropdowns	= get_post_meta ( $finder->ID, 'wpce_user_friendly_dropdowns', true );
					
					if ( $user_friendly_dropdowns == 'yes' ) {
						if ( ! wp_script_is ( 'selectWoo', 'enqueued' ) ) {
							wp_enqueue_script ( 'selectWoo' );
						}
					   
						if ( ! wp_style_is ( 'select2', 'enqueued' ) ) {
							wp_enqueue_style ( 'select2' );
						}
						
						break;
					}
				}
			}
		}
		
		// Localize Vars
		wp_localize_script ( 'wpce-main-script', 'wpce', array (
			'ajax_url'					=> admin_url ('admin-ajax.php'),
			'preloader_finder_terms'	=> wpce_get_preloader_finder_terms ( array ( 'json' => true ) ),
		) );
	}
}

$GLOBALS['wpce_frontend_assets'] = new WPCE_Frontend_Assets ();