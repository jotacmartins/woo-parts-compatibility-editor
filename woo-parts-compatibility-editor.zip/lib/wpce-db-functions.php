<?php
/**
 * DB Functions
 */

defined ( 'ABSPATH' ) || exit;

/**
 * Finder Functions
 */
 
function wpce_get_finders () {
	$finders			= get_posts ( array (
		'post_type'		=> 'wpce',
		'post_status'	=> 'publish',
		'orderby'		=> 'title',
		'order'			=> 'asc',
		'numberposts'	=> -1
	) );
	
	return apply_filters ( 'wpce_get_finders', $finders );
}

function wpce_get_finder ( $finder_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	$finders			= get_posts ( array (
		'post_type'		=> 'wpce',
		'post_status'	=> 'publish',
		'numberposts'	=> 1,
		'post__in'		=> array ( $finder_id )
	) );
	
	$finder		= '';
	if ( ! empty ( $finders ) ) {
		$finder	= $finders[0];
	}
	
	return apply_filters ( 'wpce_get_finder', $finder );
}

function wpce_get_finders_opts () {
	$finders_opts		= array (
		''				=>	__( '-- Select Finder --', 'wpce' )
	);
	
	$finders			= wpce_get_finders ();
	
	if ( ! empty ( $finders ) ) {
		foreach ( $finders as $finder ) {
			$finders_opts[ $finder->ID ] = $finder->post_title;
		}
	}
	
	return apply_filters ( 'wpce_get_finders_opts', $finders_opts );
}

/**
 * Finder Level Functions
 */
 
function wpce_get_levels ( $finder_id = '', $no_of_levels = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	$levels = get_post_meta ( $finder_id, 'wpce_levels', true );
	
	if ( ! empty ( $levels ) && $no_of_levels > 0 && count ( $levels ) > $no_of_levels ) {
		$levels = array_slice ( $levels, 0, $no_of_levels );
	}
	
	return apply_filters ( 'wpce_get_levels', $levels );
}

/**
 * Finder Term Functions
 */
 
function wpce_get_terms ( $args = array () ) {
	
	// Fields
	$fields = '*';
	
	if ( isset ( $args['fields'] ) && ! empty ( $args['fields'] ) ) {
		$fields = $args['fields'];
	}
	
	if ( is_array ( $fields ) ) {
		$fields = implode ( ',', $fields );
	}
	
	// Where Condition
	$where = '';
	
	if ( isset ( $args['finder_id'] ) && absint ( $args['finder_id'] ) > 0 ) {
		$finder_id = absint ( $args['finder_id'] );
		$where .= " AND finder_id='{$finder_id}'";
	}
	
	if ( isset ( $args['parent_id'] ) && $args['parent_id'] !== '' ) {
		$parent_id = $args['parent_id'];
		$where .= " AND parent_id='{$parent_id}'";
	}
	
	if ( isset ( $args['show_empty'] ) && $args['show_empty'] == false ) {
		$where .= " AND count > 0";
	}
	
	$order		= 'asc';
	if ( isset ( $args['order'] ) && ! empty ( $args['order'] ) ) {
		$order	= $args['order'];
	}
	
	// Query
	global $wpdb;
	$query = "SELECT {$fields} FROM {$wpdb->prefix}wpce_terms WHERE 1 {$where} ORDER BY title {$order}";
	
	// Single Col?
	$single_col = false;
	if ( $fields != '*' ) {
		$fields = explode ( ',', $fields );
		if ( count ( $fields) == 1 ) {
			$single_col = true;
		}
	}
	
	if ( $single_col ) {
		$terms = $wpdb->get_col ( $query );
	} else {
		$terms = $wpdb->get_results ( $query );
	}
	
	// Hack: Sometimes, sorting doesn't work for AlphaNumeric strings
	if ( ! empty ( $terms ) ) {
		if ( isset ( $terms[ array_key_first ( $terms ) ]->title ) ) {
			usort ( $terms, function ( $a, $b ) use ( $order ) {
				if ( $order == 'asc' ) {
					return strnatcasecmp ( $a->title, $b->title );
				} else {
					return strnatcasecmp ( $b->title, $a->title );
				}
			});
		}
	}
	
	return apply_filters ( 'wpce_get_terms', $terms, $args );
}

function wpce_get_term ( $term_id = '' ) {
	if ( empty ( $term_id ) ) {
		return;
	}
	
	global $wpdb;
	$term = $wpdb->get_row ( $wpdb->prepare ( "SELECT * FROM {$wpdb->prefix}wpce_terms WHERE term_id = %d LIMIT 1", $term_id ) );
	
	return apply_filters ( 'wpce_get_term', $term );
}

function wpce_term_exists ( $finder_id = '', $title = '', $parent_id = 0 ) {
	if ( empty ( $finder_id ) || empty ( $title ) ) {
		return;
	}
	
	global $wpdb;
	$term_id = $wpdb->get_var ( $wpdb->prepare ( "SELECT term_id FROM {$wpdb->prefix}wpce_terms WHERE title = %s AND finder_id = %d AND parent_id = %d LIMIT 1", $title, $finder_id, $parent_id ) );
	
	if ( $term_id ) {
		return $term_id;
	}
	
	return false;
}

function wpce_create_term ( $finder_id = '', $title = '', $parent_id = 0 ) {
	if ( empty ( $finder_id ) || empty ( $title ) ) {
		return;
	}
	
	// Check if term already exists?
	$term_id = wpce_term_exists ( $finder_id, $title, $parent_id );
	
	// Create new term
	if ( ! $term_id ) {
		global $wpdb;
		$wpdb->query ( $wpdb->prepare ( "INSERT INTO {$wpdb->prefix}wpce_terms SET finder_id = %d, title = %s, parent_id = %d", $finder_id, $title, $parent_id ) );
		$term_id = $wpdb->insert_id;
		do_action ( 'wpce_after_create_term', $term_id );
	}
	
	return $term_id;
}

function wpce_update_term ( $term_id = '', $title = '' ) {
	if ( empty ( $term_id ) || empty ( $title ) ) {
		return;
	}
	
	$term = wpce_get_term ( $term_id );
	
	if ( ! empty ( $term ) ) {
		if ( ! ( ( $existing_term_id = wpce_term_exists ( $term->finder_id, $title, $term->parent_id ) ) && ( $existing_term_id != $term_id ) ) ) {
			global $wpdb;
			$wpdb->query ( $wpdb->prepare ( "UPDATE {$wpdb->prefix}wpce_terms SET title = %s WHERE term_id = %d", $title, $term_id ) );
			do_action ( 'wpce_after_update_term', $term_id );
		}
	}
	
	return $term_id;
}

function wpce_delete_terms ( $term_ids = '' ) {
	if ( empty ( $term_ids ) ) {
		return;
	}
	
	if ( ! is_array ( $term_ids ) ) {
		$term_ids = array ( $term_ids );
	}
	
	$term_ids_string = implode ( ',', $term_ids );
	
	global $wpdb;
	do_action ( 'wpce_before_delete_terms', $term_ids );
	$wpdb->query ( "DELETE FROM {$wpdb->prefix}wpce_terms WHERE term_id IN ({$term_ids_string})" );
	do_action ( 'wpce_after_delete_terms', $term_ids );
}

function wpce_get_term_ancestors ( $term_id = '', $ancestors = array () ) {
	if ( empty ( $term_id ) ) {
		return;
	}
	
	$parent = wpce_get_term_parent ( $term_id );
	$ancestors[] = $parent;
	if ( ! empty ( $parent ) && $parent->parent_id > 0 ) {
		$ancestors = wpce_get_term_ancestors ( $parent->parent_id, $ancestors );
	}
	
	return $ancestors;
}

function wpce_get_term_parent ( $term_id = '' ) {
	if ( empty ( $term_id ) ) {
		return;
	}
	
	global $wpdb;
	$parent = $wpdb->get_row ( $wpdb->prepare ( "SELECT term_id, title, parent_id FROM {$wpdb->prefix}wpce_terms WHERE term_id = %d LIMIT 1", $term_id ) );
	
	return $parent;
}

function wpce_increment_term_count ( $term_id = '' ) {
	if ( empty ( $term_id ) ) {
		return;
	}
	
	global $wpdb;
	$wpdb->query ( $wpdb->prepare ( "UPDATE {$wpdb->prefix}wpce_terms SET count = count + 1 WHERE term_id = %d", $term_id ) );
}

function wpce_decrement_term_count ( $term_id = '' ) {
	if ( empty ( $term_id ) ) {
		return;
	}
	
	global $wpdb;
	$wpdb->query ( $wpdb->prepare ( "UPDATE {$wpdb->prefix}wpce_terms SET count = count - 1 WHERE term_id = %d", $term_id ) );
}

function wpce_refresh_terms_count ( $finder_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	global $wpdb;
	$terms = $wpdb->get_results ( $wpdb->prepare ( "SELECT wtr.term_id, count( wtr.product_id ) as active_products_count, wt.count FROM {$wpdb->prefix}wpce_term_relationships wtr LEFT JOIN {$wpdb->prefix}wpce_terms wt ON ( wtr.term_id = wt.term_id ) LEFT JOIN {$wpdb->prefix}posts wp ON ( wtr.product_id = wp.ID ) WHERE wt.finder_id = %d AND ( wp.post_status = 'publish' AND wp.ID IS NOT NULL ) GROUP BY wtr.term_id", $finder_id ) );
	
	if ( ! empty ( $terms ) ) {
		foreach ( $terms as $term ) {
			if ( $term->count != $term->active_products_count ) {
				$wpdb->query ( $wpdb->prepare ( "UPDATE {$wpdb->prefix}wpce_terms SET count = %d WHERE term_id = %d", $term->active_products_count, $term->term_id ) );
			}
		}
	}
}

function wpce_get_terms_options ( $finder_id = '', $parent_id = 0, $args = array () ) {
	if ( $parent_id === '' ) {
		return;
	}
	
	if ( empty ( $finder_id ) && empty ( $parent_id ) ) {
		return;
	}
	
	$selected			= '';
	if ( isset ( $args['selected'] ) && ! empty ( $args['selected'] ) ) {
		$selected		= $args['selected'];
	}
	
	$show_empty			= false;
	if ( isset ( $args['show_empty'] ) && $args['show_empty'] != '' ) {
		$show_empty		= $args['show_empty'];
	}
	
	$order				= 'asc';
	if ( isset ( $args['order'] ) && ! empty ( $args['order'] ) ) {
		$order			= $args['order'];
	}
	
	$terms				= wpce_get_terms ( array (
		'fields'		=> array ( 'term_id', 'title' ),
		'finder_id'		=> $finder_id,
		'parent_id'		=> $parent_id,
		'show_empty'	=> $show_empty,
		'order'			=> $order
	) );
	
	if ( ! empty ( $terms ) ) {
		$terms_options = '';
		
		foreach ( $terms as $term ) {
			$terms_options .= '<option value="' . $term->term_id . '" ' . selected ( $selected, $term->term_id, false ) . ' >' . $term->title . '</option>';
		}
		
		echo apply_filters ( 'wpce_get_terms_options', $terms_options, $finder_id, $parent_id, $args );
	}
}

function wpce_get_terms_hierarchy ( $args = array () ) {

	$finder_id		= '';
	if ( isset ( $args['finder_id'] ) && absint ( $args['finder_id'] ) > 0 ) {
		$finder_id	= absint ( $args['finder_id'] );
	}
	
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	$parent_id		= 0;
	if ( isset ( $args['parent_id'] ) && absint ( $args['parent_id'] ) > 0 ) {
		$parent_id	= absint ( $args['parent_id'] );
	}
	
	$json			= false;
	if ( isset ( $args['json'] ) && $args['json'] != '' ) {
		$json		= $args['json'];
	}
	
	$level			= 0;
	if ( isset ( $args['level'] ) && absint ( $args['level'] ) > 0 ) {
		$level		= $args['level'];
	}
	
	$order			= 'asc';
	$levels			= wpce_get_levels ( $finder_id );
	if ( ! empty ( $levels ) && isset ( $levels[ $level ] ) ) {
		$order		= $levels[ $level ]['order'];
	}
	
	if ( isset ( $args['show_empty'] ) && $args['show_empty'] != '' ) {
		$show_empty		= $args['show_empty'];
	} else {
		$show_empty		= get_post_meta ( $finder_id, 'wpce_show_empty_terms', true );
		if ( $show_empty == 'yes' ) {
			$show_empty	= true;
		} else {
			$show_empty	= false;
		}
	}
	
	$terms_hierarchy = array ();
	
	$terms				= wpce_get_terms (  array (
		'fields'		=> array ( 'term_id', 'title' ),
		'finder_id'		=> $finder_id,
		'parent_id'		=> $parent_id,
		'show_empty'	=> $show_empty,
		'order'			=> $order
	) );
	
	if ( ! empty ( $terms ) ) {
		$level = $level + 1;
		
		foreach ( $terms as $term ) {
			
			$key		= $term->term_id;
			if ( $json ) {
				$key	= 'prefix_id_' . $key; // 'Prefix' trick to force jquery not to auto sort by numeric key
			}
			
			$terms_hierarchy[ $key ] = ( array ) $term;
			$terms_hierarchy[ $key ]['children'] = wpce_get_terms_hierarchy ( array (
				'finder_id'		=> $finder_id,
				'parent_id'		=> $term->term_id,
				'level'			=> $level,
				'show_empty'	=> $show_empty,
				'json'			=> $json,
				'order'			=> $order
			) );
		}
	}
	
	return $terms_hierarchy;
}

function wpce_get_preloader_finder_terms ( $args = array () ) {
	$finders = wpce_get_finders ();
	if ( ! empty ( $finders ) ) {
		
		$show_empty		= '';
		if ( isset ( $args['show_empty'] ) && $args['show_empty'] != '' ) {
			$show_empty	= $args['show_empty'];
		}
		
		$json			= false;
		if ( isset ( $args['json'] ) && $args['json'] != '' ) {
			$json		= $args['json'];
		}
		
		$terms = array();
		
		foreach ( $finders as $finder ) {
			$terms_load_method = get_post_meta ( $finder->ID, 'wpce_terms_load_method', true );
			if ( $terms_load_method != 'json' ) {
				continue;
			}
			
			$terms[ $finder->ID ] = wpce_get_terms_hierarchy ( array (
				'finder_id'		=> $finder->ID,
				'show_empty'	=> $show_empty,
				'json'			=> $json
			) );
		}
		
		return apply_filters ( 'wpce_get_preloader_finder_terms', $terms );
	}
}

/**
 * Finder Term Relationship Functions
 */

function wpce_get_term_relationships ( $term_id = '' ) {
	if ( empty ( $term_id ) ) {
		return;
	}
	
	global $wpdb;
	$product_ids = $wpdb->get_col ( $wpdb->prepare ( "SELECT product_id FROM {$wpdb->prefix}wpce_term_relationships WHERE term_id = %d", $term_id ) );
	
	return apply_filters ( 'wpce_get_term_relationships', $product_ids, $term_id );
}

function wpce_get_term_relationships_including_universal ( $term_id = '', $finder_id = '' ) {
	if ( empty ( $term_id ) || empty ( $finder_id ) ) {
		return;
	}
	
	$product_ids				= array ();
	
	$term_product_ids			= wpce_get_term_relationships ( $term_id );
	if ( ! empty ( $term_product_ids ) ) {
		$product_ids			= array_merge ( $product_ids, $term_product_ids );
	}
	
	$term_universal_product_ids	= wpce_get_finder_universal_relationships ( $finder_id );
	if ( ! empty ( $term_universal_product_ids ) ) {
		$product_ids			= array_merge ( $product_ids, $term_universal_product_ids );
	}
	
	return apply_filters ( 'wpce_get_term_relationships_including_universal', $product_ids, $term_id, $finder_id );
}

function wpce_get_finder_universal_relationships ( $finder_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	$universal_products = get_post_meta ( $finder_id, 'wpce_universal_products', true );
	
	return apply_filters ( 'wpce_get_finder_universal_relationships', $universal_products, $finder_id );
}

function wpce_term_relationship_exists ( $term_id = '', $product_id = '' ) {
	if ( empty ( $term_id ) || empty ( $product_id ) ) {
		return;
	}
	
	global $wpdb;
	$term_relationship_exists = $wpdb->get_var ( $wpdb->prepare ( "SELECT term_id FROM {$wpdb->prefix}wpce_term_relationships WHERE term_id = %d AND product_id = %d LIMIT 1", $term_id, $product_id ) );
	
	if ( $term_relationship_exists ) {
		return true;
	}
	
	return false;
}

function wpce_create_term_relationship ( $term_ids = '', $product_id = '' ) {
	if ( empty ( $term_ids ) || empty ( $product_id ) ) {
		return;
	}
	
	$product = wc_get_product ( $product_id );
	
	if ( empty ( $product ) ) {
		return;
	}
	
	if ( ! is_array ( $term_ids ) ) {
		$term_ids = array ( $term_ids );
	}
	
	foreach ( $term_ids as $term_id ) {
		// Check if term relationship already exists?
		$term_relationship_exists = wpce_term_relationship_exists ( $term_id, $product_id );
		
		// Create new term relationship
		if ( ! $term_relationship_exists ) {
			global $wpdb;
			$wpdb->query ( $wpdb->prepare ( "INSERT INTO {$wpdb->prefix}wpce_term_relationships SET term_id = %d, product_id = %d", $term_id, $product_id ) );
			do_action ( 'wpce_after_create_term_relationship', $term_id, $product_id, $product );
		}
	}
	
	return true;
}

function wpce_delete_term_relationship ( $term_ids = '', $product_id = '' ) {
	if ( empty ( $term_ids ) ) {
		return;
	}
	
	if ( ! is_array ( $term_ids ) ) {
		$term_ids = array ( $term_ids );
	}
	
	$term_ids_string = implode ( ',', $term_ids );
	
	// Where Condition
	$where = '';
	
	if ( ! empty ( $product_id ) ) {
		$where .= " AND product_id='{$product_id}'";
	}
	
	global $wpdb;
	do_action ( 'wpce_before_delete_terms_relationship', $term_ids );
	$wpdb->query ( "DELETE FROM {$wpdb->prefix}wpce_term_relationships WHERE term_id IN ({$term_ids_string}) {$where}" );
	do_action ( 'wpce_after_delete_terms_relationship', $term_ids );
}
add_action ( 'wpce_before_delete_terms', 'wpce_delete_term_relationship' );

/**
 * Finder Term and Term Relationship Functions
 */

/* function wpce_get_product_term_relationships_hierarchy ( $finder_id = '', $product_id = '', $parent_id = 0 ) {
	if ( empty ( $finder_id ) || empty ( $product_id ) ) {
		return;
	}
	
	$product_terms	= wpce_get_product_term_relationships ( $finder_id, $product_id, array ( 'parent_id' => $parent_id ) );
	
	if ( ! empty ( $product_terms ) ) {
		foreach ( $product_terms as $key => $product_term ) {
			$product_terms[ $key ]['children'] = wpce_get_product_term_relationships_hierarchy ( $finder_id, $product_id, $product_term['term_id'] );
		}
	}
	
	return $product_terms;
} */

function wpce_get_product_term_relationships_hierarchy_rows ( $finder_id = '', $product_id = '', $parent_id = 0, $current_row = array (), $rows = array () ) {
	if ( empty ( $finder_id ) || empty ( $product_id ) ) {
		return;
	}
	
	$product_terms	= wpce_get_product_term_relationships ( $finder_id, $product_id, array ( 'parent_id' => $parent_id ) );
	
	if ( ! empty ( $product_terms ) ) {
		foreach ( $product_terms as $key => $product_term ) {
			$row	= $current_row;
			$row[]	= $product_term;
			$rows	= wpce_get_product_term_relationships_hierarchy_rows ( $finder_id, $product_id, $product_term['term_id'], $row, $rows );
		}
	} else if ( ! empty ( $current_row ) ) {
		$rows[]		= $current_row;
	}
	
	return $rows;
}

function wpce_get_product_term_relationships ( $finder_id = '', $product_id = '', $args = array () ) {
	if ( empty ( $finder_id ) || empty ( $product_id ) ) {
		return;
	}
	
	// Fields
	$fields = 'term_id, title, parent_id';
	
	if ( isset ( $args['fields'] ) && ! empty ( $args['fields'] ) ) {
		$fields = $args['fields'];
	}
	
	if ( ! is_array ( $fields ) ) {
		$fields = explode ( ',', $fields );
		foreach ( $fields as $key => $field ) {
			if ( strpos ( $field, '.' ) === false ) {
				$fields[ $key ] = 'wt.' . $field;
			}
		}
	}
	
	if ( is_array ( $fields ) ) {
		$fields = implode ( ',', $fields );
	}
	
	// Where Condition
	$where = '';
	
	if ( isset ( $args['parent_id'] ) && $args['parent_id'] !== '' ) {
		$parent_id = $args['parent_id'];
		$where .= " AND wt.parent_id='{$parent_id}'";
	}
	
	// Limit
	$limit = '';
	
	if ( isset ( $args['limit'] ) && $args['limit'] > 0 ) {
		$limit .= " LIMIT " . $args['limit'];
	}
	
	// Query
	global $wpdb;
	$query = $wpdb->prepare ( "SELECT {$fields} FROM {$wpdb->prefix}wpce_terms wt LEFT JOIN {$wpdb->prefix}wpce_term_relationships wtr ON ( wt.term_id = wtr.term_id ) WHERE wt.finder_id = %d AND wtr.product_id = %d {$where} ORDER BY title ASC {$limit}", $finder_id, $product_id );
	
	// Single Col?
	$single_col = false;
	if ( $fields != '*' ) {
		$fields = explode ( ',', $fields );
		if ( count ( $fields) == 1 ) {
			$single_col = true;
		}
	}
	
	if ( $single_col ) {
		$product_terms = $wpdb->get_col ( $query );
	} else {
		$product_terms = $wpdb->get_results ( $query, ARRAY_A );
	}
	
	return $product_terms;
}

function wpce_delete_product_term_relationships ( $product_id = '' ) {
	if ( empty ( $product_id ) ) {
		return;
	}
	
	global $wpdb;
	do_action ( 'wpce_before_delete_product_term_relationships', $product_id );
	$wpdb->query ( $wpdb->prepare ( "DELETE FROM {$wpdb->prefix}wpce_term_relationships WHERE product_id = %d", $product_id ) );
	do_action ( 'wpce_after_delete_product_term_relationships', $product_id );
}

/**
 * Default Filters
 */

function wpce_delete_child_terms ( $term_ids = '' ) {
	if ( empty ( $term_ids ) ) {
		return;
	}
	
	if ( ! is_array ( $term_ids ) ) {
		$term_ids = array ( $term_ids );
	}
	
	$term_ids_string = implode ( ',', $term_ids );
	
	global $wpdb;
	$term_ids = $wpdb->get_col ( "SELECT term_id FROM {$wpdb->prefix}wpce_terms WHERE parent_id IN ({$term_ids_string})" );
	if ( ! empty ( $term_ids ) ) {
		wpce_delete_terms ( $term_ids );
	}
}
add_action ( 'wpce_before_delete_terms', 'wpce_delete_child_terms' );

function wpce_update_term_count ( $term_id = '', $product_id = '', $product = '' ) {
	if ( empty ( $term_id ) || empty ( $product_id ) || empty ( $product ) ) {
		return;
	}
	
	/*$product = wc_get_product ( $product_id );
	
	if ( empty ( $product ) ) {
		return;
	}*/
	
	if ( $product->get_status() == 'publish' ) {
		wpce_increment_term_count ( $term_id );
	}
}
add_action ( 'wpce_after_create_term_relationship', 'wpce_update_term_count', 10, 3 );

function wpce_update_terms_count ( $new_status, $old_status, $post ) {
	global $wpdb;
	
	if ( 
		( $old_status != 'publish' && $new_status == 'publish' )
		||
		( $old_status == 'publish' && $new_status != 'publish' )
	) {
		$product_id	= $post->ID;
		$term_ids	= $wpdb->get_col ( $wpdb->prepare ( "SELECT term_id FROM {$wpdb->prefix}wpce_term_relationships WHERE product_id = %d", $product_id ) );
		if ( ! empty ( $term_ids ) ) {
			if ( $old_status != 'publish' && $new_status == 'publish' ) {
				foreach ( $term_ids as $term_id ) {
					wpce_increment_term_count ( $term_id );
				}
			} else if ( $old_status == 'publish' && $new_status != 'publish' ) {
				foreach ( $term_ids as $term_id ) {
					wpce_decrement_term_count ( $term_id );
				}
			}
		}
	}
}
add_action ( 'transition_post_status', 'wpce_update_terms_count', 10, 3 );