<?php
/**
 * Core Functions
 */

defined ( 'ABSPATH' ) || exit;

/**
 * Search: Is on Search Results Page?
 */
function is_wpce_search () {
	$search_term			= false;
	
	if ( isset ( $_REQUEST['wpce_search'] ) && $_REQUEST['wpce_search'] > 0 ) {
		$search_term_id 	= ( int ) $_REQUEST['wpce_search'];
		
		if ( $search_term_id ) {
			$search_term	= wpce_get_term ( $search_term_id );
			
			if ( isset ( $_REQUEST['category'] ) && $_REQUEST['category'] > 0 ) {
				$category	= get_term ( $_REQUEST['category'], 'product_cat' );
				
				if ( ! empty ( $category ) ) {
					$search_term->category_id	= $category->term_id;
					$search_term->category_name	= $category->name;
				}
			}
		}
	}
	
	return apply_filters ( 'is_wpce_search', $search_term );
}

/**
 * Form: Form Field Template
 */
function wpce_form_field ( $option, $value, $custom_attributes='' ) {
	if ( empty ( $option ) ) {
		return;
	}
	
	if ( ! isset ( $option['id'] ) ) {
		$option['id'] = $option['name'];
		$option['id'] = str_replace ( '[', ' ', $option['id'] );
		$option['id'] = str_replace ( ']', ' ', $option['id'] );
		$option['id'] = trim ( $option['id'] );
		$option['id'] = str_replace ( ' ', '_', $option['id'] );
	}

	switch ( $option['type'] ) {
		
		case 'levels':
			if ( $option['name'] == 'wpce_levels' ) {
				if ( empty ( $value ) ) {
					$value = array (
						array (
							'title'				=> '',
							'dropdown_label'	=> '',
							'dropdown_title'	=> '',
							'order'				=> '',
							'required'			=> '',
							'required_message'	=> '',
							'range'				=> ''
						)
					);
				}
			}
			
			foreach ( $value as $index => $level ) {
				?><div class="field-level closed">
					<h3><?php printf ( __( 'Level #%s', 'wpce' ), '<span class="level-no">' . ( $index + 1 ) . '</span>' ); ?></h3>
					
					<div class="field-content">
						<table>
							<tbody>
								<tr>
									<td width="50%">
										<?php $option_id = $option['id'] . '_title_' . $index; ?>
										
										<label for="<?php echo $option_id; ?>"><?php _e( 'Title', 'wpce' ); ?></label>
										
										<?php
											$option_level				= $option;
											$option_level['name']		= $option['name'] . '[title][]';
											$option_level['id']			= $option_id;
											$option_level['type']		= 'text';
											$option_level['desc']		= __( 'This is the name of level for your reference. eg: <br>Make', 'wpce' );
											$option_level['desc_tip']	= true;
											$value						= $level['title'];
											wpce_form_field ( $option_level, $value );
										?>
									</td>
									
									<td width="50%">&nbsp;</td>
								</tr>
								
								<tr>
									<td>
										<?php $option_id = $option['id'] . '_dropdown_label_' . $index; ?>
										
										<label for="<?php echo $option_id; ?>"><?php _e( 'Dropdown Label', 'wpce' ); ?></label>
										
										<?php
											$option_level				= $option;
											$option_level['name']		= $option['name'] . '[dropdown_label][]';
											$option_level['id']			= $option_id;
											$option_level['type']		= 'text';
											$option_level['desc']		= __( 'This shows before/above dropdown based on the selected template. eg: <br>Select Make', 'wpce' );
											$option_level['desc_tip']	= true;
											$value						= $level['dropdown_label'];
											wpce_form_field ( $option_level, $value );
										?>
									</td>
									
									<td>
										<?php $option_id = $option['id'] . '_dropdown_title_' . $index; ?>
										
										<label for="<?php echo $option_id; ?>"><?php _e( 'Dropdown Title', 'wpce' ); ?></label>
										
										<?php
											$option_level				= $option;
											$option_level['name']		= $option['name'] . '[dropdown_title][]';
											$option_level['id']			= $option_id;
											$option_level['type']		= 'text';
											$option_level['desc']		= __( 'This option allows you to set a title for first option from dropdown. eg: <br>-- Select Make --', 'wpce' );
											$option_level['desc_tip']	= true;
											$value						= $level['dropdown_title'];
											wpce_form_field ( $option_level, $value );
										?>
									</td>
								</tr>
								
								<tr>
									<td>
										<?php $option_id = $option['id'] . '_order_' . $index; ?>
										
										<label for="<?php echo $option_id; ?>"><?php _e( 'Sort Order', 'wpce' ); ?></label>
										
										<?php
											$option_level				= $option;
											$option_level['name']		= $option['name'] . '[order][]';
											$option_level['id']			= $option_id;
											$option_level['type']		= 'select';
											$option_level['opts']		= apply_filters ( 'wpce_setting_levels_order', array ( 'asc' => __( 'Ascending', 'wpce' ), 'desc' => __( 'Descending', 'wpce' ) ) );
											$option_level['desc']		= __( 'By default, its dropdown loads terms in ascending order of terms title. You can change it to ascending / descending order as per your need. eg: <br>You have a dropdown for years and you want to show recent year on top.', 'wpce' );
											$option_level['desc_tip']	= true;
											$value						= $level['order'];
											wpce_form_field ( $option_level, $value );
										?>
									</td>
									
									<td>
										<?php $option_id = $option['id'] . '_range_' . $index; ?>
										
										<label for="<?php echo $option_id; ?>"><?php _e( 'Range', 'wpce' ); ?></label>
										
										<?php
											$option_level				= $option;
											$option_level['name']		= $option['name'] . '[range][]';
											$option_level['id']			= $option_id;
											$option_level['type']		= 'select';
											$option_level['opts']		= apply_filters ( 'wpce_setting_levels_range', array ( 'no' => __( 'No', 'wpce' ), 'yes' => __( 'Yes', 'wpce' ) ) );
											$option_level['desc']		= __( 'Few levels with numeric terms require an extra support so you can import / show terms in range rather having individual row per term. eg: <br>2004-2008.', 'wpce' );
											$option_level['desc_tip']	= true;
											$value						= $level['range'];
											wpce_form_field ( $option_level, $value );
										?>
									</td>
								</tr>
								
								<tr>
									<td>
										<?php $option_id = $option['id'] . '_required_' . $index; ?>
										
										<label for="<?php echo $option_id; ?>"><?php _e( 'Required', 'wpce' ); ?></label>
										
										<?php
											$option_level				= $option;
											$option_level['name']		= $option['name'] . '[required][]';
											$option_level['id']			= $option_id;
											$option_level['type']		= 'select';
											$option_level['opts']		= apply_filters ( 'wpce_setting_levels_required', array ( 'no' => __( 'No', 'wpce' ), 'yes' => __( 'Yes', 'wpce' ) ) );
											$option_level['desc']		= __( 'This option makes it compulsory for users to select a term from its dropdown before search.', 'wpce' );
											$option_level['desc_tip']	= true;
											$value						= $level['required'];
											wpce_form_field ( $option_level, $value );
										?>
									</td>
									
									<td>
										<?php $option_id = $option['id'] . '_required_message_' . $index; ?>
										
										<label for="<?php echo $option_id; ?>"><?php _e( 'Required Message', 'wpce' ); ?></label>
										
										<?php
											$option_level				= $option;
											$option_level['name']		= $option['name'] . '[required_message][]';
											$option_level['id']			= $option_id;
											$option_level['type']		= 'text';
											$option_level['desc']		= __( 'A prompt message which shows if one tries to submit a search without selecting a term from its dropdown.', 'wpce' );
											$option_level['desc_tip']	= true;
											$value						= $level['required_message'];
											wpce_form_field ( $option_level, $value );
										?>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div><?php
			}
		break;
													
		case 'select':
		case 'multiselect':
		case 'products':
			echo '
				<select name="' . esc_attr ( $option['name'] ) . ( in_array ( $option['type'], array ( 'multiselect', 'products' ) ) ? '[]' : '' ) . '" id="' . esc_attr ( $option['id'] ) .'" class="' . ( $option['type'] == 'products' ? 'wc-product-search' : 'regular-text' ) . '" ' . $custom_attributes . ' ' . ( in_array ( $option['type'], array ( 'multiselect', 'products' ) ) ? 'multiple="multiple"' : '' ) . ' ' . ( $option['type'] == 'products' ? 'data-placeholder="' . esc_attr ( 'Choose Products&hellip;', 'wpce' ) . '" data-action="woocommerce_json_search_products" style="width:100%;"' : '' ) . '>';
				
					if ( $option['type'] == 'products' ) {
						echo '<option></option>';
						
						if ( ! empty ( $value ) ) {
							foreach ( $value as $id ) {
								$product = wc_get_product( $id );
								if ( is_object( $product ) ) {
									echo '<option value="' . esc_attr ( $id ) . '"' . selected ( true, true, false ) . '>' . wp_kses_post ( $product->get_formatted_name () ) . '</option>';
								}
							}
						}
					} else if ( isset ( $option['opts'] ) && ! empty ( $option['opts'] ) ) {
						foreach ( $option['opts'] as $key => $opt ) {
							if ( is_array ( $value ) ) {
								$selected = selected ( in_array ( $key, $value ), true, false );
							} else {
								$selected = selected ( $value, $key, false );
							}
							
							$opt_attributes = '';
							if ( $option['type'] == 'select_taxonomy' ) {
								$opt_arr = explode ( '{SEPARATOR}', $opt );
								$opt = trim ( $opt_arr[0] );
								
								if ( isset ( $opt_arr[1] ) ) {
									$opt_attributes .= ' data-object-types="' . $opt_arr[1] . '"';
								}
							}
				
							echo '<option value="' . esc_attr ( $key ) . '" ' . $selected . $opt_attributes . '>' . esc_attr ( $opt ) . '</option>';
						}
					}
		
					echo '
				</select>
			';
		break;

		case 'textarea':
			echo '
				<textarea name="' . esc_attr ( $option['name'] ) . '" id="' . esc_attr ( $option['id'] ) .'" class="' . ( isset ( $option['class'] ) ? $option['class'] : 'large-text' ) . '" ' . $custom_attributes . ' placeholder="' . esc_attr ( $option['placeholder'] ) . '" rows="5" cols="50">' . esc_textarea ( $value  ) . '</textarea>
			';
		break;

		case 'checkbox':
			echo '
				<fieldset>
					<legend class="screen-reader-text"><span>' . $option['label'] . '</span></legend>
		
					<label for="' . $option['name'] . '">
						<input type="checkbox" name="' . esc_attr ( $option['name'] ) . '" id="' . esc_attr ( $option['id'] ) .'" ' . $custom_attributes . ' value="1" ' . checked ( $value, 'yes', false ) . ' /> 
					</label>
				</fieldset>
			';
		break;
	
		case 'checkbox_group':
			echo '
				<fieldset>
					<legend class="screen-reader-text"><span>' . $option['label'] . '</span></legend>';
		
					if ( isset ( $option['opts'] ) && ! empty ( $option['opts'] ) ) {
			
						foreach ( $option['opts'] as $key => $opt ) {
							
							$opt = str_replace ( '[help]', '<p class="description">( ', $opt );
							$opt = str_replace ( '[/help]', ' )</p>', $opt );
				
							if ( is_array ( $value ) ) {
								$checked = checked ( in_array ( $key, $value ), true, false );
							} else {
								$checked = checked ( $value, $key, false );
							}
				
							echo '
								<label for="' . esc_attr ( $option['name'] . '_' . $key ) . '">
									<input type="checkbox" name="' . esc_attr ( $option['name'] ) . '[]" id="' . esc_attr ( $option['id'] . '_' . $key ) .'" ' . $custom_attributes . ' value="' . esc_attr ( $key ) . '" ' . $checked . ' /> ' . $opt . '
								</label><br />
							';
						}
					}
		
					echo '
				</fieldset>
			';
		break;

		case 'radio':
			echo '
				<fieldset>
					<legend class="screen-reader-text"><span>' . $option['label'] . '</span></legend>';
		
					if ( isset ( $option['opts'] ) && ! empty ( $option['opts'] ) ) {
			
						foreach ( $option['opts'] as $key => $opt ) {
							
							$opt = str_replace ( '[help]', '<p class="description">( ', $opt );
							$opt = str_replace ( '[/help]', ' )</p>', $opt );
				
							echo '
								<label for="' . esc_attr ( $option['name'] . '_' . $key ) . '">
									<input type="radio" name="' . esc_attr ( $option['name'] ) . '" id="' . esc_attr ( $option['id'] . '_' . $key ) .'" ' . $custom_attributes . ' value="' . esc_attr ( $key ) . '" ' . checked ( $value, $key, false ) . ' /> ' . $opt . '
								</label><br />
							';
						}
					}
		
					echo '
				</fieldset>
			';
		break;
	
		case 'colour':
			echo '
				<input type="text" name="' . esc_attr ( $option['name'] ) . '" id="' . esc_attr ( $option['id'] ) .'" class="wpce-cpick" ' . $custom_attributes . ' placeholder="' . esc_attr ( $option['placeholder'] ) . '" value="' . esc_attr ( $value ) . '" />
			';
		break;

		default:
			echo '
				<input type="' . esc_attr ( $option['type'] ) . '" name="' . esc_attr ( $option['name'] ) . '" id="' . esc_attr ( $option['id'] ) .'" class="' . ( isset ( $option['class'] ) ? $option['class'] : 'regular-text' ) . '" ' . $custom_attributes . ' placeholder="' . esc_attr ( $option['placeholder'] ) . '" value="' . esc_attr ( $value ) . '" />
			';

	}

	if ( isset ( $option['desc'] ) && ! empty ( $option['desc'] ) ) {
		if ( isset ( $option['desc_tip'] ) && $option['desc_tip'] == true ) {
			// echo wc_help_tip ( $option['desc'], true ); // Conflicts with jQuery add more levels
			$tip = wc_sanitize_tooltip ( $option['desc'] );
			echo '<span class="woocommerce-help-tip" data-tip="' . $tip . '" data-duplicate-tip="' . $tip . '"></span>'; // data-duplicate-tip to avoid conflict with jQuery add more levels
		} else {
			echo '<p class="description">' . $option['desc'] . '</p>';
		}
	}
}

/**
 * Form: Form Field Format Before Save
 */
function wpce_format_form_field ( $option ) {
	if ( empty ( $option ) ) {
		return;
	}
	
	// Get posted value
	if ( strstr( $option['name'], '[' ) ) {
		parse_str ( $option['name'], $option_name_array );
		$option_name	= current ( array_keys( $option_name_array ) );
		$setting_name	= key ( $option_name_array[ $option_name ] );
		$raw_value		= isset ( $_POST[ $option_name ][ $setting_name ] ) ? wp_unslash ( $_POST[ $option_name ][ $setting_name ] ) : null;
	} else {
		$option_name	= $option['name'];
		$setting_name	= '';
		$raw_value		= isset ( $_POST[ $option['name'] ] ) ? wp_unslash ( $_POST[ $option['name'] ] ) : null;
	}
	
	// Format the Value based on Option Type
	switch( $option['type'] ) {
		case 'checkbox' :
			$value = is_null ( $raw_value ) ? 'no' : 'yes';
		break;

		case 'textarea' :
			$value = wp_kses_post ( trim ( $raw_value ) );
		break;
		
		case 'levels' :
			$value = array ();
			if ( isset ( $raw_value['title'] ) ) {
				foreach ( $raw_value['title'] as $key => $val ) {
					$value[]				= array (
						'title'				=> trim ( $raw_value['title'][ $key ] ),
						'dropdown_label'	=> trim ( $raw_value['dropdown_label'][ $key ] ),
						'dropdown_title'	=> trim ( $raw_value['dropdown_title'][ $key ] ),
						'order'				=> trim ( $raw_value['order'][ $key ] ),
						'required'			=> trim ( $raw_value['required'][ $key ] ),
						'required_message'	=> trim ( $raw_value['required_message'][ $key ] ),
						'range'				=> trim ( $raw_value['range'][ $key ] ),
					);
				}
			}
		break;

		default :
			$value = is_array ( $raw_value ) ? array_map ( 'sanitize_text_field', $raw_value ) : sanitize_text_field ( $raw_value );
		break;
	}

	return array ( $option_name, $setting_name, $value );
}

function wpce_get_finder_url ( $finder_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	$finder_url						= get_post_meta ( $finder_id, 'wpce_custom_url', true );
	if ( ! empty ( $finder_url ) ) {
		$finder_url					= esc_url ( home_url () ) . $finder_url;
	} else {
		$shop_page_id				= wc_get_page_id ( 'shop' );
		if ( $shop_page_id > 0 ) {
			$finder_url				= esc_url ( get_permalink ( $shop_page_id ) );
		} else {
			$finder_url				= esc_url ( home_url () );
		}
	}
	
	return apply_filters ( 'wpce_filter_form_action', $finder_url, $finder_id );
}

/**
 * Filter Form Template
 */
function wpce_filter_widget_template ( $args ) {
	if ( empty ( $args ) ) {
		return;
	}
	
	// Finder
	$finder_id						= ( isset ( $args['finder_id'] ) && ! empty ( $args['finder_id'] ) ) ? absint ( $args['finder_id'] ) : '';
	if ( ! $finder_id ) {
		return;
	}
	
	if ( ! isset ( $args['finder'] ) ) {
		$args['finder']				= wpce_get_finder ( $finder_id );
	}
	
	$finder							= ( isset ( $args['finder'] ) && ! empty ( $args['finder'] ) ) ? $args['finder'] : '';
	if ( empty ( $finder ) ) {
		return;
	}
	
	// Levels
	if ( ! isset ( $args['no_of_levels'] ) ) {
		$args['no_of_levels']		= '';
	}
	
	if ( ! isset ( $args['levels'] ) ) {
		$args['levels']				= wpce_get_levels ( $finder_id, $args['no_of_levels'] );
	}
	
	$levels							= ( isset ( $args['levels'] ) && ! empty ( $args['levels'] ) ) ? $args['levels'] : '';
	if ( empty ( $levels ) ) {
		return;
	}
	
	// Categories Level
	$product_validator				= ( isset ( $args['product_validator'] ) ) ? $args['product_validator'] : false;
	
	if ( ! $product_validator && apply_filters ( 'wpce_show_categories_level', true ) ) {
		$categories_level				= get_post_meta ( $finder_id, 'wpce_categories_level', true );
		
		if ( $categories_level == 'yes' ) {
			$level						= array (
				'type'					=> 'category',
				'dropdown_label'		=> get_post_meta ( $finder_id, 'wpce_categories_level_dropdown_label', true ),
				'dropdown_title'		=> get_post_meta ( $finder_id, 'wpce_categories_level_dropdown_title', true ),
				'required'				=> get_post_meta ( $finder_id, 'wpce_categories_level_required', true ),
				'required_message'		=> get_post_meta ( $finder_id, 'wpce_categories_level_required_message', true )
			);
			
			$categories_level_position	= get_post_meta ( $finder_id, 'wpce_categories_level_position', true );
			
			if ( $categories_level_position == 'first' ) {
				$levels[-1]				= $level;
			} else {
				$levels[]				= $level;
			}
			
			ksort ( $levels );
		}
	}
	
	$no_of_levels					= count ( $levels );
	
	// Others
	$layout							= ( isset ( $args['layout'] ) && ! empty ( $args['layout'] ) ) ? $args['layout'] : 'v';
	//$product_validator				= ( isset ( $args['product_validator'] ) ) ? $args['product_validator'] : false;
	$heading						= ( isset ( $args['heading'] ) ) ? $args['heading'] : '';
	
	$finder_url						= wpce_get_finder_url ( $finder_id );
	
	$show_empty						= get_post_meta ( $finder_id, 'wpce_show_empty_terms', true );
	if ( $show_empty == 'yes' ) {
		$show_empty					= true;
	} else {
		$show_empty					= false;
	}
	
	$search_term					= $is_search_results_page = is_wpce_search ();
	if ( $search_term ) {
		$search_term_id				= $search_term->term_id;
	} else {
		$search_term_id				= wpce_get_cookie ( $finder_id, 'search_term_id' );
	}
	
	$user_friendly_dropdowns		= get_post_meta ( $finder_id, 'wpce_user_friendly_dropdowns', true );
	$disable_dependent_dropdowns	= get_post_meta ( $finder_id, 'wpce_disable_dependent_dropdowns', true );
	$validation_border				= get_post_meta ( $finder_id, 'wpce_validation_border', true );
	$auto_submit					= get_post_meta ( $finder_id, 'wpce_auto_submit', true );
	
	// Submit Button?
	$hide_submit_button				= 'yes';
	$submit_label					= '';
	
	if ( ! $product_validator ) {
		$hide_submit_button			= get_post_meta ( $finder_id, 'wpce_hide_submit_button', true );
		$submit_label				= get_post_meta ( $finder_id, 'wpce_submit_label', true );
		
		if ( $hide_submit_button != 'yes' && $submit_label == '' ) {
			$hide_submit_button		= 'yes';
		}
	}
	
	// Reset Search Button?
	$reset_search					= 'no';
	$reset_search_label				= '';
	
	if ( ! $product_validator ) {
		$reset_search				= get_post_meta ( $finder_id, 'wpce_reset_search', true );
		
		if ( $reset_search == 'yes' ) {
			$remember_search		= get_post_meta ( $finder_id, 'wpce_remember_search', true );
			
			if ( $remember_search == 'yes' && ! empty ( $search_term_id ) ) {
				$reset_search_label	= get_post_meta ( $finder_id, 'wpce_reset_search_label', true );
				
				if ( $reset_search_label == '' ) {
					$reset_search	= 'no';
				}
			} else {
				$reset_search		= 'no';
			}
		}
	}
	
	// Total Buttons ( Eg: Submit and Reset )
	$no_of_buttons					= 0;
	
	if ( $hide_submit_button != 'yes' ) {
		$no_of_buttons				= $no_of_buttons + 1;
	}
	
	if ( $reset_search == 'yes' ) {
		$no_of_buttons				= $no_of_buttons + 1;
	}
	
	$search_ancestors				= array ();
	if ( $search_term_id ) {
		$search_ancestors			= wpce_get_term_ancestors ( $search_term_id );
		
		if ( ! empty ( $search_ancestors ) ) {
			$search_ancestors		= array_reverse ( $search_ancestors );
		}
	}
	?>
	
	<?php
		if ( $product_validator ) {
			global $post;
			$product_validator_hide_cart_button	= get_post_meta ( $finder_id, 'wpce_product_validator_hide_cart_button', true );
			
			echo apply_filters ( 'wpce_product_validator_wrapper_start', '<div class="wpce-product-validator" data-product-id="' . $post->ID . '" data-hide-cart-button="' . $product_validator_hide_cart_button . '">', $args );
		}
	?>
	
		<?php echo apply_filters ( 'wpce_filter_widget_wrapper_start', '<div class="wpce-filter-widget-inner wpce-widget-layout-' . $layout . ' wpce-widget-levels-' . $no_of_levels . ' wpce-widget-buttons-' . $no_of_buttons . '" data-finder-id="' . $finder_id . '" data-auto-submit="' . $auto_submit . '" data-validation-border="' . $validation_border . '"  data-user-friendly-dropdowns="' . $user_friendly_dropdowns . '" data-disable-dependent-dropdowns="' . $disable_dependent_dropdowns . '">', $args ); ?>
		
			<?php do_action ( 'wpce_before_filter_widget', $args ); ?>
			
				<?php
					if ( ! empty ( $heading ) ) {
						echo apply_filters ( 'wpce_filter_widget_heading_container_start', '<h2>' );
							echo $heading;
						echo apply_filters ( 'wpce_filter_widget_heading_container_end', '</h2>' );
					}
				?>
			
				<?php if ( ! $product_validator ) { ?><form action="<?php echo $finder_url; ?>" method="get"><?php } ?>
				
					<?php do_action ( 'wpce_before_filter_widget_form', $args ); ?>
						
						<?php $parent_id = 0; ?>
						
						<?php foreach ( $levels as $key => $level ) { ?>
						
							<?php echo apply_filters ( 'wpce_filter_widget_field_wrapper_start', '<div class="wpce-field">', $args ); ?>
							
								<?php if ( apply_filters ( 'wpce_show_filter_widget_dropdown_labels', true ) && ! empty ( $level['dropdown_label'] ) ) { ?>
									
									<label for="wpce-<?php echo $key; ?>"><?php echo $level['dropdown_label']; ?></label>
									
								<?php } ?>
							
								<select class="wpce-field-term" id="wpce-<?php echo $key; ?>" <?php if ( isset ( $level['type'] ) && $level['type'] == 'category' ) { echo 'name="category"'; } ?> data-level="<?php echo $key; ?>" data-required="<?php echo $level['required']; ?>" data-required-message="<?php echo esc_attr ( $level['required_message'] ); ?>" data-type="<?php echo isset ( $level['type'] ) ? $level['type'] : 'term'; ?>">
								
									<option value=""><?php echo $level['dropdown_title']; ?></option>
									
									<?php
										if ( isset ( $level['type'] ) && $level['type'] == 'category' ) {
											$categories_to_include	= get_post_meta ( $finder_id, 'wpce_categories_to_include', true );
											$categories_to_exclude	= get_post_meta ( $finder_id, 'wpce_categories_to_exclude', true );
											
											$terms					= get_categories ( apply_filters ( 'wpce_categories_level_terms_args', array (
												'taxonomy'			=> 'product_cat',
												'hide_empty'		=> true,
												'orderby'			=> 'name',
												'order'				=> 'ASC',
												'include'			=> $categories_to_include,
												'exclude'			=> $categories_to_exclude
											) ) );
											
											if ( ! empty ( $terms ) ) {
												$selected			= isset ( $_GET['category'] ) ? $_GET['category'] : '';
												
												include_once WC()->plugin_path() . '/includes/walkers/class-wc-product-cat-dropdown-walker.php';
												echo wc_walk_category_dropdown_tree ( $terms, 0, apply_filters ( 'wpce_categories_level_terms_tree_args', array (
													'selected'		=> absint ( $selected ),
													'hierarchical'	=> 1,
													'pad_counts'	=> 1,
													'value'			=> 'id',
													'show_count'	=> false
												) ) );
												
												/*echo walk_category_dropdown_tree ( $terms, '', apply_filters ( 'wpce_categories_level_terms_tree_args', array (
													'selected'		=> $selected,
													'show_count'	=> false
												) ) );*/
												
												/*foreach ( $terms as $term ) {
													echo '<option value="' . $term->term_id . '" ' . selected ( $selected, $term->term_id, false ) . ' >' . $term->name . '</option>';
												}*/
											}
										} else {
											$selected		= '';
											if ( ! empty ( $search_ancestors ) && isset ( $search_ancestors[ $key ] ) ) {
												$selected	= $search_ancestors[ $key ]->term_id;
											}
										
											wpce_get_terms_options ( $finder_id, $parent_id, array ( 'selected' => $selected, 'show_empty' => $show_empty, 'order' => $level['order'] ) );
											
											$parent_id		= $selected;
										}
									?>
									
								</select>
								
							<?php echo apply_filters ( 'wpce_filter_widget_field_wrapper_end', '</div>', $args ); ?>
							
						<?php } ?>
						
						<?php if ( $hide_submit_button != 'yes' || $reset_search == 'yes' ) { ?>
								
							<?php echo apply_filters ( 'wpce_filter_widget_field_wrapper_start', '<div class="wpce-field wpce-field-buttons">', $args ); ?>
							
								<?php if ( $hide_submit_button != 'yes' ) { ?>
					
									<input type="submit" value="<?php echo $submit_label; ?>" />
									
								<?php } ?>
								
								<?php if ( $reset_search == 'yes' ) { ?>
								
									<?php
										$reset_url		= '';
										
										if ( $is_search_results_page ) {
											$reset_url		= $finder_url;
										}
									?>
					
									<input type="button" value="<?php echo $reset_search_label; ?>" class="wpce-reset-search" data-href="<?php echo $reset_url; ?>" />
									
								<?php } ?>
							
							<?php echo apply_filters ( 'wpce_filter_widget_field_wrapper_end', '</div>', $args ); ?>
							
						<?php } ?>
						
					<?php do_action ( 'wpce_after_filter_widget_form', $args ); ?>
					
					<?php if ( $product_validator ) { ?>
						
						<input type="hidden" name="wpce_product_validator[<?php echo $finder_id; ?>]" value="" />
						
					<?php } else { ?>
						
						<input type="hidden" name="wpce_search" value="" />
						
					<?php } ?>
					
					<input type="hidden" name="post_type" value="product" />
					
					<div class="wpce-clearfix"></div>
					
				<?php if ( ! $product_validator ) { ?></form><?php } ?>
			
			<?php do_action ( 'wpce_after_filter_widget', $args ); ?>
			
		<?php echo apply_filters ( 'wpce_filter_widget_wrapper_end', '</div>', $args ); ?>
		
	<?php
		if ( $product_validator ) {
			echo apply_filters ( 'wpce_product_validator_wrapper_end', '</div>', $args );
		}
	?>
	
	<?php
}

/**
 * User Searches Widget Template
 */
function wpce_user_searches_widget_template ( $args ) {
	if ( empty ( $args ) ) {
		return;
	}
	
	// Finder
	$finder_id		= ( isset ( $args['finder_id'] ) && ! empty ( $args['finder_id'] ) ) ? absint ( $args['finder_id'] ) : '';
	if ( ! $finder_id ) {
		return;
	}
	
	$finder			= wpce_get_finder ( $finder_id );
	if ( empty ( $finder ) ) {
		return;
	}
	
	// Levels
	$levels			= wpce_get_levels ( $finder_id );
	if ( empty ( $levels ) ) {
		return;
	}
	
	$no_of_levels	= count ( $levels );
	
	ob_start ();
	
		// Saved Searches
		if ( apply_filters ( 'wpce_show_saved_searches', true, $args ) ) {
			wpce_user_searches_template ( $finder_id, 'saved_searches' );
		}
		
		// Search History
		if ( apply_filters ( 'wpce_show_search_history', true, $args ) ) {
			wpce_user_searches_template ( $finder_id, 'search_history' );
		}
		
	$template		= ob_get_clean ();
	
	if ( ! empty ( $template ) ) {
		echo apply_filters ( 'wpce_user_searches_widget_wrapper_start', '<div class="wpce-user-searches-widget-inner" data-finder-id="' . $finder_id . '">', $args, $finder_id ) . $template . apply_filters ( 'wpce_user_searches_widget_wrapper_end', '</div>', $args, $finder_id );
	}
}

/**
 * User Searches Template
 */
function wpce_user_searches_template ( $finder_id = '', $type = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	if ( empty ( $type ) ) {
		return;
	}
	
	$searches	= array ();
	
	if ( $type == 'search_history' ) {
		$searches	= wpce_get_user_search_history ( $finder_id );
	} else if ( $type == 'saved_searches' ) {
		$searches	= wpce_get_user_saved_searches ( $finder_id );
	}
	
	if ( ! empty ( $searches ) ) {
		
		echo apply_filters ( 'wpce_user_searches_template_start', '<div class="wpce-user-searches wpce-user-' . $type . '">', $finder_id, $type );
		
			do_action ( 'wpce_before_user_searches', $finder_id, $type );
				$title				= get_post_meta ( $finder_id, 'wpce_user_' . $type . '_title', true );
				
				if ( ! empty ( $title ) ) {
					echo apply_filters ( 'wpce_user_searches_title_start', '<h3 class="wpce-user-searches-title wpce-user-' . $type . '-title">', $finder_id, $type );
						
						do_action ( 'wpce_before_user_searches_title', $finder_id, $type );
						
							echo $title;
						
						do_action ( 'wpce_after_user_searches_title', $finder_id, $type );
						
					echo apply_filters ( 'wpce_user_searches_title_end', '</h3>', $finder_id, $type );
				}
				
				$description		= get_post_meta ( $finder_id, 'wpce_user_' . $type . '_description', true );
				
				if ( ! empty ( $description ) ) {
					echo apply_filters ( 'wpce_user_searches_description_start', '<p class="wpce-user-searches-description wpce-user-' . $type . '-description">', $finder_id, $type );
						
						do_action ( 'wpce_before_user_searches_description', $finder_id, $type );
						
							echo $description;
						
						do_action ( 'wpce_after_user_searches_description', $finder_id, $type );
						
					echo apply_filters ( 'wpce_user_searches_description_end', '</p>', $finder_id, $type );
				}
				
				$go_text			= get_post_meta ( $finder_id, 'wpce_user_search_go_text', true );
				$save_text			= get_post_meta ( $finder_id, 'wpce_user_search_save_text', true );
				$delete_text		= get_post_meta ( $finder_id, 'wpce_user_search_delete_text', true );
				
				$finder_url			= wpce_get_finder_url ( $finder_id );
				?>
				
				<ul>
					<?php
						foreach ( $searches as $search_term_id ) {
							$search_ancestors	= wpce_get_term_ancestors ( $search_term_id );
							
							if ( empty ( $search_ancestors ) ) {
								/*
								 * Delete Term if Term ID nomore exists
								 * ( Doesn't work within Widget because 'headers already sent' error
								 *
								wpce_set_cookie ( $finder_id, 'user_searches', $search_term_id, 'delete' ); */
								
								continue;
							}
							
							$search_ancestors	= array_reverse ( $search_ancestors );
							
							$search_title		= array ();
							foreach ( $search_ancestors as $search_ancestor ) {
								if ( ! empty ( $search_ancestor ) ) {
									$search_title[]	= $search_ancestor->title;
								}
							}
							$search_title		= implode ( ' ', $search_title );
							
							$finder_url			= add_query_arg ( 'wpce_search', $search_term_id, $finder_url );
							$finder_url			= add_query_arg ( 'post_type', 'product', $finder_url );
							
							?>
							<li data-finder-id="<?php echo $finder_id; ?>" data-search-term-id="<?php echo $search_term_id; ?>">
								<span class="wpce-user-search-title"><?php echo $search_title; ?></span>
								
								<div class="wpce-user-search-actions">
									<span>
										<a href="<?php echo $finder_url; ?>" class="wpce-go-user-search"><i></i><?php echo $go_text; ?></a>
										
										<?php if ( $type == 'search_history' && is_user_logged_in () ) { ?>
											<a href="#" class="wpce-save-user-search"><i></i><?php echo $save_text; ?></a>
										<?php } ?>
										
										<a href="#" class="wpce-delete-user-search"><i></i><?php echo $delete_text; ?></a>
									</span>
								</div>
							</li>
							<?php
						}
					?>
				</ul>
				
				<?php
				$clear_text			= get_post_meta ( $finder_id, 'wpce_user_' . $type . '_clear_text', true );
				if ( ! empty ( $clear_text ) ) {
					?><div class="wpce-user-searches-actions">
						<a href="#" class="wpce-clear-user-searches"><i></i><?php echo $clear_text; ?></a>
					</div><?php
				}
			
			do_action ( 'wpce_after_user_searches', $finder_id, $type );
			
		echo apply_filters ( 'wpce_user_searches_template_end', '</div>', $finder_id, $type );
		
	}
}

/**
 * Search History: Get Searches
 */
function wpce_get_user_search_history ( $finder_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	$search_history		= wpce_get_cookie ( $finder_id, 'user_searches' );
	
	// Reverse Array and Maintain Keys
	if ( ! empty ( $search_history ) ) {
		$search_history	= array_combine ( array_reverse ( array_keys ( $search_history ) ), array_reverse ( array_values ( $search_history ) ) );
	}
	
	return $search_history;
}

/**
 * Search History: Save Search
 */
function wpce_save_user_search_history ( $finder_id = '', $search_term_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	if ( empty ( $search_term_id ) ) {
		return;
	}
	
	if ( is_user_logged_in () ) {
		$saved_searches	= wpce_get_user_saved_searches ( $finder_id );
		
		if ( ! empty ( $saved_searches ) && in_array ( $search_term_id, $saved_searches ) ) {
			return;
		}
	}
	
	wpce_set_cookie ( $finder_id, 'user_searches', $search_term_id, 'append' );
}

/**
 * Search History: Delete Search
 */
function wpce_delete_user_search_history ( $finder_id = '', $search_term_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	if ( empty ( $search_term_id ) ) {
		return;
	}
	
	wpce_set_cookie ( $finder_id, 'user_searches', $search_term_id, 'delete' );
}

/**
 * Search History: Clear Search
 */
function wpce_clear_user_search_history ( $finder_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	wpce_set_cookie ( $finder_id, 'user_searches', '' );
}

/**
 * Saved Searches: Get Searches
 */
function wpce_get_user_saved_searches ( $finder_id = '', $reverse = true ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	if ( ! is_user_logged_in () ) {
		return;
	}
	
	$saved_searches		= get_user_meta ( get_current_user_id (), 'wpce_saved_searches_' . $finder_id, true );
	
	// Reverse Array and Maintain Keys
	if ( $reverse && ! empty ( $saved_searches ) ) {
		$saved_searches	= array_reverse ( $saved_searches );
	}
	
	return $saved_searches;
}

/**
 * Saved Searches: Save Search
 */
function wpce_save_user_saved_search ( $finder_id = '', $search_term_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	if ( empty ( $search_term_id ) ) {
		return;
	}
	
	if ( ! is_user_logged_in () ) {
		return;
	}
	
	$saved_searches		= wpce_get_user_saved_searches ( $finder_id, false );
	
	if ( empty ( $saved_searches ) ) {
		$saved_searches	= array ();
	}
	
	// Delete Item or Reset Latest Item on Top
	if ( ! empty ( $saved_searches ) && in_array ( $search_term_id, $saved_searches ) ) {
		$item_key		= array_search ( $search_term_id, $saved_searches );
		
		if ( $item_key !== false ) {
			unset ( $saved_searches[ $item_key ] );
		}
	}
	
	$saved_searches[]	= $search_term_id;
	$saved_searches		= array_values ( $saved_searches );
	
	// Limit User Searches
	$user_saved_searches_limit				= get_post_meta ( $finder_id, 'wpce_user_saved_searches_limit', true );
		
	if ( $user_saved_searches_limit > 0 ) {
		$saved_searches	= array_slice ( $saved_searches, -$user_saved_searches_limit, $user_saved_searches_limit );
	}
	
	//delete_user_meta ( get_current_user_id (), 'wpce_saved_searches_' . $finder_id );
	update_user_meta ( get_current_user_id (), 'wpce_saved_searches_' . $finder_id, $saved_searches );
	
	// Delete Term from Search History
	wpce_set_cookie ( $finder_id, 'user_searches', $search_term_id, 'delete' );
}

/**
 * Saved Searches: Delete Search
 */
function wpce_delete_user_saved_search ( $finder_id = '', $search_term_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	if ( empty ( $search_term_id ) ) {
		return;
	}
	
	if ( ! is_user_logged_in () ) {
		return;
	}
	
	$saved_searches		= wpce_get_user_saved_searches ( $finder_id, false );
	
	if ( ! empty ( $saved_searches ) && in_array ( $search_term_id, $saved_searches ) ) {
		$item_key		= array_search ( $search_term_id, $saved_searches );
		
		if ( $item_key !== false ) {
			unset ( $saved_searches[ $item_key ] );
		}
	}
	
	update_user_meta ( get_current_user_id (), 'wpce_saved_searches_' . $finder_id, $saved_searches );
}

/**
 * Saved Searches: Clear Searches
 */
function wpce_clear_user_saved_search ( $finder_id = '' ) {
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	if ( ! is_user_logged_in () ) {
		return;
	}
	
	delete_user_meta ( get_current_user_id (), 'wpce_saved_searches_' . $finder_id );
}

/**
 * Product Tab: Get Product Terms List Table
 */
function wpce_get_product_tab_terms_list_table ( $args = array () ) {
	if ( empty ( $args ) ) {
		return;
	}
	
	extract ( $args );
	
	if ( ! isset ( $finder_id ) || empty ( $finder_id ) ) {
		return;
	}
	
	if ( ! isset ( $product_id ) || empty ( $product_id ) ) {
		if ( is_product () ) {
			global $post;
			$product_id	= $post->ID;
		}
	}
	
	if ( ! isset ( $product_id ) || empty ( $product_id ) ) {
		return;
	}
	
	if ( ! isset ( $levels ) || empty ( $levels ) ) {
		$number_of_levels	= get_post_meta ( $finder_id, 'wpce_number_of_levels', true );
		if ( ! $number_of_levels ) {
			return;
		}
		
		$levels				= wpce_get_levels ( $finder_id, $number_of_levels );
	}
	
	if ( ! isset ( $levels ) || empty ( $levels ) ) {
		return;
	}
	
	$tab_ajax			= get_post_meta ( $finder_id, 'wpce_tab_ajax', true );
	
	do_action ( 'wpce_product_tab_before_list', $finder_id );
		?><table class="wpce-product-terms-list-table" border="0" <?php if ( $tab_ajax == 'yes' ) { echo 'data-finder-id="' . $finder_id . '" data-product-id="' . $product_id . '"'; } ?>>
			<thead>
				<tr>
					<?php foreach ( $levels as $level ) { ?>
						<th><?php echo $level['title']; ?></th>
					<?php } ?>
				</tr>
			</thead>
		
			<tfoot>
				<tr>
					<?php foreach ( $levels as $level ) { ?>
						<th><?php echo $level['title']; ?></th>
					<?php } ?>
				</tr>
			</tfoot>
			
			<tbody>
				<?php
					if ( $tab_ajax == 'yes' ) {
						$tab_ajax_loading_text	= get_post_meta ( $finder_id, 'wpce_tab_ajax_loading_text', true );
						
						?><tr>
							<td colspan="<?php echo count ( $levels ); ?>" class="wpce-product-terms-loading">
								<?php echo $tab_ajax_loading_text; ?>
							</td>
						</tr><?php
					} else {
						wpce_get_product_tab_terms_list_table_rows ( array (
							'finder_id'		=> $finder_id,
							'product_id'	=> $product_id,
							'levels'		=> $levels
						) );
					}
				?>
			</tbody>
		</table><?php
		
	do_action ( 'wpce_product_tab_after_list', $finder_id );
}

/**
 * Product Tab: Get Product Terms List Table Rows
 */
function wpce_get_product_tab_terms_list_table_rows ( $args = array () ) {
	if ( empty ( $args ) ) {
		return;
	}
	
	extract ( $args );
	
	if ( ! isset ( $finder_id ) || empty ( $finder_id ) ) {
		return;
	}
	
	if ( ! isset ( $product_id ) || empty ( $product_id ) ) {
		return;
	}
	
	if ( ! isset ( $levels ) || empty ( $levels ) ) {
		$number_of_levels	= get_post_meta ( $finder_id, 'wpce_number_of_levels', true );
		if ( ! $number_of_levels ) {
			return;
		}
		
		$levels				= wpce_get_levels ( $finder_id, $number_of_levels );
	}
	
	if ( ! isset ( $levels ) || empty ( $levels ) ) {
		return;
	}
	
	$product_terms	= wpce_get_product_term_relationships_hierarchy_rows ( $finder_id, $product_id );
	
	if ( ! empty ( $product_terms ) ) {
		foreach ( $product_terms as $product_term ) {
			?><tr>
				<?php foreach ( $levels as $key => $level ) { ?>
					<td><?php echo isset ( $product_term[ $key ] ) ? $product_term[ $key ]['title'] : ''; ?></td>
				<?php } ?>
			</tr><?php
		}
	}
}