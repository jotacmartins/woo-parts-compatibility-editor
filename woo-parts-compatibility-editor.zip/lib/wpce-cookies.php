<?php
/**
 * Cookies Manager
 */

defined ( 'ABSPATH' ) || exit;

/**
 * Set Cookie
 */
function wpce_set_cookie ( $finder_id = '', $identifier = '', $item = '', $type = ''/*, $sub_identifier = ''*/ ) { // $type is for array $item only
	if ( empty ( $finder_id ) ) {
		return;
	}
	
	if ( empty ( $identifier ) ) {
		return;
	}
	
	$expiry		= 0;
	
	//setcookie ( 'wpce', '', time() - 3600, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN ); exit;
	
	$wpce		= array ();
	
	if ( isset ( $_COOKIE['wpce'] ) ) {
		$wpce	= wpce_get_cookie ();
	}
	
	if ( $type != '' ) { // append or delete
		if ( ! isset ( $wpce[ $finder_id ][ $identifier ] ) || empty ( $wpce[ $finder_id ][ $identifier ] ) ) {
			$wpce[ $finder_id ][ $identifier ]	= array ();
		}
		
		/*// Using $sub_identifier or empty [] means extend, not append ( but for the time taking as 'append'
		if ( $sub_identifier != '' ) {
			
			// Unset so Recent Search Moves on Top
			if ( isset ( $wpce[ $finder_id ][ $identifier ][ $sub_identifier ] ) ) {
				unset ( $wpce[ $finder_id ][ $identifier ][ $sub_identifier ] );
			}
			
			$wpce[ $finder_id ][ $identifier ][ $sub_identifier ]	= ( array ) $item;
		} else {
			$wpce[ $finder_id ][ $identifier ][]					= ( array ) $item;
		}*/
		
		// Delete Item for Reset Latest Item on Top
		if ( ! empty ( $wpce[ $finder_id ][ $identifier ] ) && in_array ( $item, $wpce[ $finder_id ][ $identifier ] ) ) {
			$item_key							= array_search ( $item, $wpce[ $finder_id ][ $identifier ] );
			
			if ( $item_key !== false ) {
				unset ( $wpce[ $finder_id ][ $identifier ][ $item_key ] );
			}
		}
		
		if ( $type == 'append' && ! empty ( $item ) ) {
			$wpce[ $finder_id ][ $identifier ][]	= $item;
		}
		
		// Reset Array Keys from Zero
		if ( ! empty ( $wpce[ $finder_id ][ $identifier ] ) ) {
			
			// Limit User Searches
			if ( $identifier == 'user_searches' ) {
				$user_search_history_limit				= get_post_meta ( $finder_id, 'wpce_user_search_history_limit', true );
				
				if ( $user_search_history_limit > 0 ) {
					$wpce[ $finder_id ][ $identifier ]	= array_slice ( $wpce[ $finder_id ][ $identifier ], -$user_search_history_limit, $user_search_history_limit );
				}
			}
			
			$wpce[ $finder_id ][ $identifier ]		= array_values ( $wpce[ $finder_id ][ $identifier ] );
		}
	} else {
		if ( empty ( $item ) ) {
			if ( isset ( $wpce[ $finder_id ][ $identifier ] ) ) {
				unset ( $wpce[ $finder_id ][ $identifier ] );
			}
		} else {
			$wpce[ $finder_id ][ $identifier ]		= $item;
		}

		if ( empty ( $wpce[ $finder_id ] ) ) {
			$expiry	= time() - 3600;
		}
	}
	
	$wpce				= maybe_serialize ( $wpce );
	setcookie ( 'wpce', $wpce, $expiry, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN );
	$_COOKIE['wpce']	= $wpce;
}

/**
 * Get Cookie
 */
function wpce_get_cookie ( $finder_id = '', $identifier = '' ) {
	$wpce				= '';
	
	if ( isset ( $_COOKIE['wpce'] ) && ! empty ( $_COOKIE['wpce'] ) ) {
		$wpce			= maybe_unserialize ( wp_unslash ( $_COOKIE['wpce'] ) );
		
		if ( ! empty ( $identifier ) ) {
			$wpce		= isset ( $wpce[ $finder_id ][ $identifier ] ) ? $wpce[ $finder_id ][ $identifier ] : '';
		}
	}
	
	return $wpce;
}