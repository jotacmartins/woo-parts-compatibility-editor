"use strict";

jQuery(document).ready(function ($) {
    // Mostrar/Esconder Lista de Termos
    function wpce_toggle_term_list($field) {
        var $elem = $field.closest('.wpce-tables');

        if ($field.is(':checked')) {
            $elem.find('.terms-list-table').hide();
            $elem.find('.terms-list-actions').css('visibility', 'hidden');
        } else {
            $elem.find('.terms-list-table').show();
            $elem.find('.terms-list-actions').css('visibility', 'visible');
        }
    }

    $(document).on('change', '.wpce-tables .wpce-universal', function () {
        var $field = $(this);
        wpce_toggle_term_list($field);
    });

    $('.wpce-tables .wpce-universal').each(function () {
        var $field = $(this);
        wpce_toggle_term_list($field);
    });

    // Carregar Termos Filhos
    $(document).on('change', '.wpce-tables .terms-list-table select', function () {
        var $elem = $(this);
        var $next_elem = $elem.closest('td').next('td').find('select');
        var $container = $elem.closest('.wpce-tables');

        if ($next_elem.length) {
            var $parent_id = $elem.val();

            $elem.closest('td').nextAll('td').each(function () {
                $(this).find('select').val('').find('option').not(':first').remove();
            });

            if ($parent_id > 0) {
                $container.addClass('wpce-processing');

                var $finder_id = $container.data('finder-id');
                var $level = $elem.data('level');

                if (typeof wpce_tm.preloader_finder_terms[$finder_id] !== 'undefined') {

                    var $parent_ids = [];
                    $parent_ids.push($parent_id);
                    $elem.closest('td').prevAll('td').each(function () {
                        $parent_ids.push($(this).find('select').val());
                    });
                    $parent_ids.reverse();

                    var $terms = wpce_tm.preloader_finder_terms[$finder_id];
                    $.each($parent_ids, function ($index, $parent_id) {
                        $terms = $terms['prefix_id_' + $parent_id]['children'];
                    });

                    $.each($terms, function ($index, $term) {
                        $next_elem.append($('<option></option>').val($term.term_id).html($term.title));
                    });

                    $container.removeClass('wpce-processing');
                } else {
                    $.post(wpce_tm.ajax_url, {
                        'parent_id': $parent_id,
                        'finder_id': $finder_id,
                        'level': $level,
                        'panel': 'admin',
                        'action': 'wpce_get_terms'
                    }, function (response) {
                        if (response != '') {
                            $next_elem.append(response);
                        }

                        $container.removeClass('wpce-processing');
                    });
                }
            }
        }
    });

    // Remover todas as linhas
    $(document).on('click', '.wpce-tables .remove-all-rows', function (e) {
        e.preventDefault();

        if (confirm(wpce_tm.msg_delete_all_rows)) {
            $(this).closest('.wpce-tables').find('.terms-list-table tbody tr:not(:last)').remove();
        }
    });

    // Remover uma linha específica
    $(document).on('click', '.wpce-tables .remove-row', function (e) {
        e.preventDefault();

        if (confirm(wpce_tm.msg_delete_row)) {
            $(this).closest('tr').fadeOut('slow', function () {
                $(this).remove();
            });
        }
    });

   
});
