"use strict";

jQuery( document ).ready(function($) {
	
	/* ***** COMMON JS ***** */
	
	// Color Picker
	if ( $('.wpce-cpick').length ) {
		$('.wpce-cpick').wpColorPicker();
	}
	
	/* ***** FINDER ADD/EDIT PAGE ***** */
	
	// Add/Remove Levels
	$(document).on('focusout', '#wpce_number_of_levels', function() {
		var $container = $(this).closest('table');
		
		var $current_number_of_levels = $container.find('.field-levels .field-level').length;
		var $required_number_of_levels = $(this).val();
		
		if ( $current_number_of_levels > $required_number_of_levels ) {
			var $old_levels_to_remove = $current_number_of_levels - $required_number_of_levels;
			
			for ( var $i=$old_levels_to_remove; $i>=1; $i-- ) {
				if ( $container.find('.field-levels .field-level').length > 1 ) {
					$container.find('.field-levels .field-level:last').remove();
				}
			}
		} else if ( $current_number_of_levels < $required_number_of_levels ) {
			var $new_levels_to_add = $required_number_of_levels - $current_number_of_levels;
			var $sno = parseInt( $container.find('.field-levels .field-level:last .level-no:first').text() );
			
			for ( var $i=1; $i<=$new_levels_to_add; $i++ ) {
				$sno = $sno + 1;
				
				var $clonned_row = $container.find('.field-levels .field-level:first').clone();
				$clonned_row.addClass('closed').find('.field-content').hide();
				$clonned_row.find('input').val('');
				$clonned_row.find('select').prop( 'selectedIndex', 0 );
				$clonned_row.find('.level-no').text( $sno );
				$container.find('.field-levels .field-level:last').after( $clonned_row );
				
				$container.find('.field-levels .field-level:first').find('.woocommerce-help-tip').each(function(index) {
					var $tip_text = $(this).data('duplicate-tip');
					$container.find('.field-levels .field-level:last').find('.woocommerce-help-tip:eq('+index+')').attr('data-tip', $tip_text);
				});
			}
			$( document.body ).trigger( 'init_tooltips' );
		}
	});
	$('#wpce_number_of_levels').trigger('focusout');
	
	// Extend/Collapse Levels
	$(document).on('click', '.field-levels .field-level > h3', function() {
		var $container = $(this).closest('.field-level');
		
		if ( $container.hasClass('closed') ) {
			$container.siblings('.field-level:not(.closed)').addClass('closed').find('.field-content').hide();
			
			$container.find('.field-content').slideDown();
			$container.removeClass('closed');
		} else {
			$container.find('.field-content').slideUp();
			$container.addClass('closed');
		}
	});
	
	// All Categories to include in Filter
	$(document).on('change', '#wpce_categories_to_include', function() {
		if ( $(this).find( 'option[value=""]:selected' ).length > 0 ) {
			$(this).val('');
		}
	});
	
	/* ***** FINDER TERMS LIST PAGE ***** */
	
	// Refresh Terms Count
	$(document).on('click', 'a.wpce-refresh-terms-count', function(e) {
		e.preventDefault();
		
		if ( confirm ( wpce.msg_refresh_terms_count ) ) {
			var $finder_id = $(this).data('finder-id');
			
			if ( $finder_id > 0 ) {
				$('.wrap').addClass('wpce-processing');
				
				$.post( wpce.ajax_url, {'finder_id':$finder_id, 'action':'wpce_refresh_terms_count'}, function( response ) {
					if ( response != '' ) {
						alert ( response );
						window.location.href = window.location.href;
					}
					
					$('.wrap').removeClass('wpce-processing');
				});
			}
		}
	});
	
	// Confirm before Delete
	$(document).on('click', '.row-actions .delete a', function() {
		if ( confirm ( wpce.msg_delete_item ) ) {
			return true;
		}
		
		return false;
	});
	
	// Add/Edit Term Form Functions
	function wpce_save_term() {
		var $finder_id = $('#wpce-list-table').find('input[name="finder_id"]').val();
		
		var $parent_id = 0;
		if ( $('#wpce-list-table').find('input[name="parent_id"]').length ) {
			$parent_id = $('#wpce-list-table').find('input[name="parent_id"]').val();
		}
		
		var $data = $('.wpce-forms .term-box :input').serializeArray();
		$data.push({ name: 'finder_id', value: $finder_id });
		$data.push({ name: 'parent_id', value: $parent_id });
		$data.push({ name: 'action', value: 'wpce_save_term' });
		
		$('.wrap').addClass('wpce-processing');
		
		$.post( wpce.ajax_url, $data, function( response ) {
			if ( response != '' ) {
				response = JSON.parse( response );
				
				if ( typeof response.message != 'undefined' ) {
					alert ( response.message );
				}
				
				if ( response.success == '1' ) {
					window.location.href = window.location.href;
				}
			}
			
			$('.wrap').removeClass('wpce-processing');
		});
	}
	
	function wpce_reset_term() {
		$('.wpce-forms .term-box input:text').val('');
		$('.wpce-forms .term-box input:hidden').val('');
	}
	
	// Add/Edit Term Form
	wpce_reset_term();
	
	$(document).on('click', '.wpce-forms .term-box #term-submit', function(e) {
		e.preventDefault();
		wpce_save_term();
	});
	
	$(document).on('keypress', '.wpce-forms .term-box input:text', function(e) {
		if ( e.keyCode == 13 ) {
			e.preventDefault();
			wpce_save_term();
		}
	});
	
	// Edit Term
	$(document).on('click', '.row-actions .edit a', function() {
		var $term_id	= $(this).data('id');
		var $term_title	= $(this).data('title');
		
		$('.wpce-forms .term-box input[name="term_id"]').val( $term_id );
		$('.wpce-forms .term-box input[name="term_title"]').val( $term_title );
		
		$('.wpce-forms .term-box .label-edit').removeClass('hidden');
		$('.wpce-forms .term-box .label-add').addClass('hidden');
		
		$('html, body').animate({
			scrollTop: $('.wpce-forms .term-box').offset().top - 60
		}, 500, function() {
			$('.wpce-forms .term-box input[name="term_title"]').focus();
		});
		
		return false;
	});
	
	$(document).on('click', '.wpce-forms .term-box .label-edit .cancel', function(e) {
		e.preventDefault();
		
		wpce_reset_term();
		$('.wpce-forms .term-box .label-add').removeClass('hidden');
		$('.wpce-forms .term-box .label-edit').addClass('hidden');
	});
});