"use strict";

jQuery( document ).ready(function($) {
	
	// Search Form: Reset on Page Load
	$('.wpce-filter-widget-inner form').each(function() {
		$(this)[0].reset();
	});
	
	// Search Form: Load Child Level Terms
	$(document).on('change', '.wpce-filter-widget-inner select[data-type="term"]', function(e) {
		var $elem		= $(this);
		var $next_elem	= $elem.closest('.wpce-field').next('.wpce-field').find('select[data-type="term"]');
		var $container	= $elem.closest('.wpce-filter-widget-inner');
		var $finder_id	= $container.data('finder-id');
		var $level		= $elem.data('level');
				
		if ( $next_elem.length ) {
			var $parent_id = $elem.val();
			
			$elem.closest('.wpce-field').nextAll('.wpce-field').each(function() {
				$(this).find('select[data-type="term"]').val('').find('option').not(':first').remove();
			});
			$( document.body ).trigger( 'wpce_dropdown_terms_updating', [ $finder_id, $level, $elem, $next_elem ] );
			
			if ( $parent_id > 0 ) {
				$container.addClass('wpce-processing');
				
				if ( typeof wpce.preloader_finder_terms[$finder_id] !== 'undefined' ) {
					var $parent_ids = [];
					$parent_ids.push ( $parent_id );
					$elem.closest('.wpce-field').prevAll('.wpce-field').each(function() {
						if ( $(this).find('select[data-type="term"]').length ) {
							$parent_ids.push( $(this).find('select[data-type="term"]').val() );
						}
					});
					$parent_ids.reverse();
					
					var $terms = wpce.preloader_finder_terms[$finder_id];
					$.each( $parent_ids, function( $index, $parent_id ) {
						$terms = $terms['prefix_id_' + $parent_id]['children'];
					});
					
					$.each( $terms, function( $index, $term ) {
						$next_elem.append( $('<option></option>').val( $term.term_id ).html( $term.title ) );
					});
					
					$( document.body ).trigger( 'wpce_dropdown_terms_updated', [ $finder_id, $level, $elem, $next_elem ] );
					$container.removeClass('wpce-processing');
				} else {
					$.post( wpce.ajax_url, {'parent_id':$parent_id, 'finder_id':$finder_id, 'level':$level, 'panel':'front', 'action':'wpce_get_terms'}, function( response ) {
						if ( response != '' ) {
							$next_elem.append( response );
						}
						
						$( document.body ).trigger( 'wpce_dropdown_terms_updated', [ $finder_id, $level, $elem, $next_elem ] );
						$container.removeClass('wpce-processing');
					});
				}
			}
		}
	});
	
	// Search Form: Validate on Form Submit
	$(document).on('submit', '.wpce-filter-widget-inner form', function(e) {
		var $form				= $(this);
		var $container			= $form.closest('.wpce-filter-widget-inner');
		
		var $error				= false;
		var $error_msg			= '';
		var $validation_border	= $container.data('validation-border');
		
		$form.find('[data-required="yes"]').each(function() {
			var $elem			= $(this);
			
			if ( $elem.val() == '' ) {
				if ( ! $error ) {
					$error		= true;
					$error_msg	= $elem.data('required-message');
				}
				
				if ( $validation_border == 'yes' ) {
					$elem.closest('.wpce-field').addClass('wpce-error');
				}
			} else {
				$elem.closest('.wpce-error').removeClass('wpce-error');
			}
		});
		
		if ( $error ) {
			if ( typeof $error_msg !== 'undefined' && $error_msg != '' ) {
				alert ( $error_msg );
			}
			
			return false;
		}
		
		var $term_id			= '';
		$form.find('.wpce-field-term[data-type="term"]').each(function() {
			if ( $(this).val() != '' ) {
				$term_id		= $(this).val();
			}
		});
		$form.find('input[name="wpce_search"]').val( $term_id );
		
		return true;
	});
	
	/*// Search Form: Validate on Field Change
	$(document).on('change', '.wpce-filter-widget-inner select, .wpce-filter-widget-inner input', function(e) {
		var $elem			= $(this);
		var $form			= $elem.closest('form');
		var $container		= $form.closest('.wpce-filter-widget-inner');
		
		var $validation_border	= $container.data('validation-border');
		
		if ( $validation_border == 'yes' ) {
			if ( $elem.val() == '' ) {
				$elem.closest('.wpce-field').addClass('wpce-error');
			} else {
				$elem.closest('.wpce-error').removeClass('wpce-error');
			}
		}
	});*/
	
	// Search Form: Auto Submit
	$(document).on('change', '.wpce-filter-widget-inner[data-auto-submit="yes"] form select', function(e) {
		var $elem			= $(this);
		var $form			= $elem.closest('form');
		
		if ( ( ! $elem.closest('.wpce-field').next('.wpce-field').find('select').length ) && $(this).val() != '' ) {
			//$form[0].submit();
			$form.trigger('submit');
		}
	});
	
	// Search Form: Reset Search
	$(document).on('click', '.wpce-filter-widget-inner form .wpce-reset-search', function(e) {
		e.preventDefault();
		
		var $elem			= $(this);
		var $href			= $elem.attr('data-href');
		var $form			= $elem.closest('form');
		var $container		= $elem.closest('.wpce-filter-widget-inner');
		var $finder_id		= $container.data('finder-id');
		
		if ( $finder_id > 0 ) {
			$container.addClass('wpce-processing');
			
			$.post( wpce.ajax_url, {'finder_id':$finder_id, 'action':'wpce_reset_search'}, function( response ) {
				if( typeof $href !== 'undefined' && $href != '' ) {
					window.location.href = $href;
				} else {
					window.location.href = window.location.href;
				}
				
				$container.removeClass('wpce-processing');
			});
		}
	});
	
	// Search Form: User Friendly Dropdowns
	if ( $().selectWoo ) {
		var select2_args = {
			//width: '100%'
		};
		
		$(document).find('.wpce-filter-widget-inner[data-user-friendly-dropdowns="yes"]').each(function() {
			$(this).find('select').selectWoo( select2_args );
		});
	}
	
	// Search Form: Disable Dependent Dropdowns
	$(document).find('.wpce-filter-widget-inner[data-disable-dependent-dropdowns="yes"]').each(function() {
		var $container		= $(this);
		wpce_disable_dependent_dropdowns( $container );
	});
	
	$(document).on('change', '.wpce-filter-widget-inner[data-disable-dependent-dropdowns="yes"] select[data-type="term"]', function(e) {
		var $container		= $(this).closest('.wpce-filter-widget-inner');
		wpce_disable_dependent_dropdowns( $container );
	});
	
	function wpce_disable_dependent_dropdowns( $container ) {
		$container.find('.wpce-field').each(function() {
			if ( $(this).find('select[data-type="term"]').length ) {
				if ( ! ( $(this).find('select[data-type="term"]').val() > 0 ) ) {
					$(this).nextAll('.wpce-field').each(function() {
						$(this).find('select[data-type="term"]').attr( 'disabled', 'disabled' );
					});
					
					return false;
				} else {
					$(this).next('.wpce-field').find('select[data-type="term"]').removeAttr( 'disabled' );
				}
			}
		});
	}
	
	// Product Validator Form: Reset on Page Load
	$('.wpce-product-validator option').prop('selected', function() {
		return this.defaultSelected;
	});
	
	// Product Validator Form: Triggers on Page Load EG: Hide Cart Button / Reset Text Values
	$('.wpce-product-validator').each(function(e) {
		var $container			= $(this);
		var $form				= $container.closest('form');
		var $hide_cart_button	= $container.data('hide-cart-button');
		
		var $finder_id			= $container.find('.wpce-filter-widget-inner').data('finder-id');
		$container.find('input[name="wpce_product_validator[' + $finder_id + ']"]').val( '' );
		
		if ( $hide_cart_button == 'yes' ) {
			$form.find('.single_add_to_cart_button, .add_to_cart_button').addClass('wpce-invisible');
		}
	});
	
	// Product Validator Form: Validate Product
	$(document).on('change', '.wpce-product-validator select', function(e) {
		var $elem				= $(this);
		var $next_elem			= $elem.closest('.wpce-field').next('.wpce-field').find('select');
		var $container			= $elem.closest('.wpce-filter-widget-inner');
		var $form				= $container.closest('form');
		var $finder_id			= $container.data('finder-id');
		var $product_id			= $container.closest('.wpce-product-validator').data('product-id');
		var $hide_cart_button	= $container.closest('.wpce-product-validator').data('hide-cart-button');
		var $level				= $elem.data('level');
		var $term_id			= $elem.val();
		
		$container.find('input[name="wpce_product_validator[' + $finder_id + ']"]').val( '' );
		
		if ( ! $next_elem.length && $term_id > 0 ) {
			$container.addClass('wpce-processing');
			
			$.post( wpce.ajax_url, {'product_id':$product_id, 'term_id':$term_id, 'finder_id':$finder_id, 'action':'wpce_validate_product'}, function( response ) {
				if ( response != '' ) {
					response = JSON.parse ( response );
					
					if ( response.success ) {
						$container.find('input[name="wpce_product_validator[' + $finder_id + ']"]').val( $term_id );
					}
					
					if ( $hide_cart_button == 'yes' ) {
						if ( response.success ) {
							$form.find('.single_add_to_cart_button, .add_to_cart_button').removeClass('wpce-invisible');
						} else {
							$form.find('.single_add_to_cart_button, .add_to_cart_button').addClass('wpce-invisible');
						}
					}
					
					if ( response.message != '' ) {
						if ( ! $container.find('.wpce-message').length ) {
							$container.append( '<div class="wpce-message"></div>' );
						}
						
						$container.find('.wpce-message').html( response.message );
						
						if ( response.success ) {
							$container.find('.wpce-message').removeClass('wpce-error').addClass('wpce-success');
						} else {
							$container.find('.wpce-message').removeClass('wpce-success').addClass('wpce-error');
						}
					} else {
						if ( $container.find('.wpce-message').length ) {
							$container.find('.wpce-message').remove();
						}
					}
				}
				
				$container.removeClass('wpce-processing');
			});
		} else {
			if ( $hide_cart_button == 'yes' ) {
				$form.find('.single_add_to_cart_button, .add_to_cart_button').addClass('wpce-invisible');
			}
			
			if ( $container.find('.wpce-message').length ) {
				$container.find('.wpce-message').remove();
			}
		}
	});
	
	// Product Validator Form: Trigger Change Hook if Pre-selected Dropdowns
	$('.wpce-product-validator').each(function(e) {
		var $container	= $(this);
		
		if ( $container.find('select:last').val() > 0 ) {
			$container.find('select:last').trigger('change');
		}
	});
	
	// Product Tab: Terms via Ajax
	if ( $( '.wpce-product-terms-list-table[data-finder-id]' ).length ) {
		$( '.wpce-product-terms-list-table[data-finder-id]' ).each(function() {
			var $table			= $(this);
			var $finder_id		= $table.data( 'finder-id' );
			var $product_id		= $table.data( 'product-id' );
		   
			if ( $finder_id > 0 && $product_id > 0 ) {
				$table.addClass( 'wpce-processing' );
				
				$.post( wpce.ajax_url, {'finder_id':$finder_id, 'product_id':$product_id, 'action':'wpce_get_product_tab_terms'}, function( response ) {
					$table.find( 'tbody' ).html( response );
					$table.removeClass( 'wpce-processing' );
				});
			}
		});
	}
	
	// Search History: Move Search from Search History to Saved Searches
	$(document).on('click', '.wpce-user-search_history .wpce-save-user-search', function(e) {
		e.preventDefault();
		
		var $elem			= $(this);
		var $row			= $elem.closest('li');
		var $container		= $elem.closest('.wpce-user-searches');
		var $finder_id		= $elem.closest('li').attr('data-finder-id');
		var $search_term_id	= $elem.closest('li').attr('data-search-term-id');
		
		if ( $search_term_id > 0 && $finder_id > 0 ) {
			$container.addClass('wpce-processing');
			$row.addClass('active');
			
			$.post( wpce.ajax_url, {'search_term_id':$search_term_id, 'finder_id':$finder_id, 'action':'wpce_save_user_search'}, function( response ) {
				wpce_reload_user_searches_template( $finder_id, response );
				$container.removeClass('wpce-processing');
				$row.removeClass('active');
			});
		}
	});
	
	// Search History: Delete Search
	$(document).on('click', '.wpce-user-search_history .wpce-delete-user-search', function(e) {
		e.preventDefault();
		
		var $elem			= $(this);
		var $row			= $elem.closest('li');
		var $container		= $elem.closest('.wpce-user-searches');
		var $finder_id		= $elem.closest('li').attr('data-finder-id');
		var $search_term_id	= $elem.closest('li').attr('data-search-term-id');
		
		if ( $search_term_id > 0 && $finder_id > 0 ) {
			$container.addClass('wpce-processing');
			$row.addClass('active');
			
			$.post( wpce.ajax_url, {'search_term_id':$search_term_id, 'finder_id':$finder_id, 'action':'wpce_delete_user_search_history'}, function( response ) {
				wpce_reload_user_searches_template( $finder_id, response );
				$container.removeClass('wpce-processing');
				$row.removeClass('active');
			});
		}
	});
	
	// Search History: Clear Searches
	$(document).on('click', '.wpce-user-search_history .wpce-clear-user-searches', function(e) {
		e.preventDefault();
		
		var $elem			= $(this);
		var $container		= $elem.closest('.wpce-user-searches');
		var $finder_id		= $elem.closest('.wpce-user-searches-widget-inner').attr('data-finder-id');
		
		if ( $finder_id > 0 ) {
			$container.addClass('wpce-processing');
			
			$.post( wpce.ajax_url, {'finder_id':$finder_id, 'action':'wpce_clear_user_search_history'}, function( response ) {
				wpce_reload_user_searches_template( $finder_id, response );
				$container.removeClass('wpce-processing');
			});
		}
	});
	
	// Saved Searches: Delete Search
	$(document).on('click', '.wpce-user-saved_searches .wpce-delete-user-search', function(e) {
		e.preventDefault();
		
		var $elem			= $(this);
		var $row			= $elem.closest('li');
		var $container		= $elem.closest('.wpce-user-searches');
		var $finder_id		= $elem.closest('li').attr('data-finder-id');
		var $search_term_id	= $elem.closest('li').attr('data-search-term-id');
		
		if ( $search_term_id > 0 && $finder_id > 0 ) {
			$container.addClass('wpce-processing');
			$row.addClass('active');
			
			$.post( wpce.ajax_url, {'search_term_id':$search_term_id, 'finder_id':$finder_id, 'action':'wpce_delete_user_saved_search'}, function( response ) {
				wpce_reload_user_searches_template( $finder_id, response );
				$container.removeClass('wpce-processing');
				$row.removeClass('active');
			});
		}
	});
	
	// Saved Searches: Clear Searches
	$(document).on('click', '.wpce-user-saved_searches .wpce-clear-user-searches', function(e) {
		e.preventDefault();
		
		var $elem			= $(this);
		var $container		= $elem.closest('.wpce-user-searches');
		var $finder_id		= $elem.closest('.wpce-user-searches-widget-inner').attr('data-finder-id');
		
		if ( $finder_id > 0 ) {
			$container.addClass('wpce-processing');
			
			$.post( wpce.ajax_url, {'finder_id':$finder_id, 'action':'wpce_clear_user_saved_searches'}, function( response ) {
				wpce_reload_user_searches_template( $finder_id, response );
				$container.removeClass('wpce-processing');
			});
		}
	});
	
	// User Searches: Show Quick Links
	$(document).on('click', '.wpce-user-searches-widget-inner .wpce-user-searches li .wpce-user-search-title', function(e) {
		e.preventDefault();
		
		var $elem			= $(this).closest('li');
		
		$('.wpce-user-searches-widget-inner .wpce-user-searches li.active').removeClass('active');
		$elem.addClass('active');
	});
	
	// User Searches: Hide Quick Links
	$(document).on('mouseup touchend', function(e) {
		if ( $(e.target).closest('.wpce-user-searches-widget-inner .wpce-user-searches li.active').length === 0 ) {
			$('.wpce-user-searches-widget-inner .wpce-user-searches li.active').removeClass('active');
		}
	});
	
	// User Seaches: Reload User Searches Template
	function wpce_reload_user_searches_template( $finder_id, $response ) {
		var $html	= '';
		
		if ( $response != '' ) {
			$html	= $($response).html();
		}
		
		$('.wpce-user-searches-widget-inner[data-finder-id="'+$finder_id+'"]').html( $html );
	}
});